# Campus Bus — Identification and Management System

    frontend/   React + Vite + Tailwind + Leaflet + Recharts
    backend/    FastAPI + SQLAlchemy + PostgreSQL + WebSocket + scikit-learn
    docker-compose.yml   PostgreSQL 16

The database is the source of truth. Sample data exists only if you opt in with `VITE_USE_MOCK=true`.

## First run
1. `docker compose up -d db`
2. Backend
   ```
   cd backend && python -m venv .venv && source .venv/bin/activate
   pip install -r requirements.txt
   cp .env.example .env            # set JWT_SECRET (python -c "import secrets; print(secrets.token_urlsafe(48))")
   python -m app.seed              # stops, routes (R-101..), buses, schedules, and DEMO accounts (development only)
   python -m app.create_admin --email you@your-college.edu --name "Transport Office"   # a real admin; asks for a password
   uvicorn app.main:app --reload
   ```
3. Frontend: `cd frontend && cp .env.example .env && npm install && npm run dev`

Demo accounts from the seed (admin@college.edu / admin123, student@college.edu / student123) exist for development only. The seed refuses to run when `ENVIRONMENT=production`. Do not rely on them: use Sign Up for students and `create_admin` for administrators.

**Upgrading an existing database:** nothing is wiped. On start-up the server adds the new columns (route codes, phone, theme, token versions, speed...) and gives your existing routes codes `R-101, R-102, ...`. Existing accounts count as email-verified.

## What was changed in this update
| Area | Result |
|---|---|
| Persistence | `VITE_USE_MOCK` now defaults to **off**. Routes, stops, buses, schedules, profiles and passwords all live in PostgreSQL. (Routes/stops "disappearing" came from the old default of sample-data mode.) Student stop dropdowns also read the database now. |
| Route numbers | Routes have a real, editable **route code** (R-101). Searching "R-101", "r101" or "r 101" finds it. |
| Welcome / Login / Sign Up | One full-screen welcome page. Login and Sign Up slide the brand panel to the left and the form in from the right (CSS transitions, no reload). Also forgot-password, reset-password and email-confirmation screens. |
| Accounts | Real sign-up (hashed password, student role forced), login by email or Student ID, profile edit (name, phone, department, default stop, email), password change, password reset by email, email confirmation, "sign out of all devices". Changing a password signs out other devices. |
| Settings (both roles) | Profile, Theme (Light / Dark / System, saved to the account), Password & Security, About, Sign out. Admins also get **Campus** (college and front-gate location). |
| Search | Global search in the navbar for both roles (pages, settings, "Change password", "Sign out"), keyboard friendly, works on mobile. Admin Live Monitoring has a bus search by bus number, route code, route name, **number plate**, location or status. |
| Student dashboard | Full-width grid: bus status + ETA, service overview, big live map, route information, quick actions, and a **notifications panel on the right** that scrolls on its own and drops below the content on small screens. |
| Bus Locations (student) | Every bus on one map with coordinates, status, speed, last-updated (ticking), next stop, **distance from the college front gate** and ETA to college. Idle buses show where they were last seen. |
| Live data honesty | If the WebSocket drops, pages show "Showing the last known positions" instead of "Live", and each bus shows "updated 42 s ago". After 2 minutes without a fix a bus is Offline. |
| Admin Live Monitoring | Plate, speed, ETA, last-updated columns; the table, markers and times change as positions arrive. |

## Email (real)
Set in `backend/.env`: `EMAIL_HOST, EMAIL_PORT, EMAIL_USERNAME, EMAIL_PASSWORD, EMAIL_FROM, FRONTEND_URL` (and `EMAIL_VERIFICATION_REQUIRED=true` to block sign-in until confirmed, `ALLOWED_EMAIL_DOMAINS=college.edu` to accept only college addresses). With `EMAIL_HOST` empty (development), confirmation and reset links are **printed in the server log** instead of sent. Reset links are single-use, expire in 30 minutes, and only a hash of each token is stored. The forgot-password form answers identically whether or not an account exists, and sign-in, sign-up and reset are rate limited. Nothing secret is in the frontend; only `VITE_*` values are.

## Live GPS test (no phone needed)
Admin > Trip Control > pick a bus > tick "Simulate movement" > START TRIP. Watch Student > Bus Locations, Live Tracking, or Admin > Live Monitoring. Real phones need the app served over HTTPS. Positions, speed and stop visits are saved; the ETA model (Admin > Analytics) trains from them.

## Tests
`cd backend && for t in tests/test_*.py; do python $t; done` (needs numpy, pandas, scikit-learn, joblib, PyJWT; bcrypt/dotenv optional for the tests). The frontend logic checks (search, live data, password rules) are plain Node scripts described in the change notes.

## Known limits
- Roads: straight lines between stops. No traffic data.
- Live state lives in one server process: run one worker, or add Redis (Phase 11).
- The in-memory rate limiter is per process; production should also limit at the reverse proxy.
- Behind a proxy, make sure the real client IP reaches the app (rate limits are per IP).
- Schema upgrades are handled by a small start-up migration (`app/migrate.py`); full Alembic migrations are still to do.
