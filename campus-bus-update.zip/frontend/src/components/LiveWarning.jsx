import { WifiOff } from 'lucide-react';

// Shown instead of a "Live" badge when the real-time connection is down, so old positions are never presented as live.
export default function LiveWarning({ status }) {
  if (status === 'open' || status === 'mock') return null;
  return (
    <p role="status" className="flex items-start gap-2 rounded-lg bg-amber-50 p-3 text-sm text-amber-800">
      <WifiOff size={16} className="mt-0.5 shrink-0" aria-hidden />
      {status === 'connecting' ? 'Connecting to live updates…' : 'The live connection was lost. Showing the last known positions, which may be out of date. Reconnecting automatically.'}
    </p>
  );
}
