import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Menu, LogOut, Settings, User } from 'lucide-react';
import useAuth from '../hooks/useAuth';
import Logo from './Logo';
import GlobalSearch from './GlobalSearch';
import { initials } from '../utils/helpers';

export default function Navbar({ onMenu }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [menu, setMenu] = useState(false);
  const ref = useRef(null);
  const base = user?.role === 'admin' ? '/admin' : '/student';

  useEffect(() => {
    const away = (e) => { if (ref.current && !ref.current.contains(e.target)) setMenu(false); };
    const esc = (e) => e.key === 'Escape' && setMenu(false);
    document.addEventListener('mousedown', away); document.addEventListener('keydown', esc);
    return () => { document.removeEventListener('mousedown', away); document.removeEventListener('keydown', esc); };
  }, []);

  const signOut = () => { logout(); navigate('/'); };
  const item = 'flex min-h-[44px] w-full items-center gap-2 rounded-lg px-3 text-left text-sm text-slate-700 hover:bg-slate-100';

  return (
    <header className="sticky top-0 z-30 flex h-14 items-center justify-between gap-3 border-b border-slate-200 bg-white px-3 sm:px-5" style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}>
      <div className="flex min-w-0 items-center gap-2">
        <button onClick={onMenu} aria-label="Open menu" className="rounded-md p-2 text-slate-600 hover:bg-slate-100 lg:hidden"><Menu size={22} /></button>
        <Logo compact className="lg:hidden" />
        <p className="truncate text-sm font-bold text-brand-900 lg:hidden">Campus Bus</p>
        <p className="hidden shrink-0 text-sm text-slate-500 xl:block">Campus Bus · Identification and Management System</p>
      </div>
      <div className="flex items-center gap-2">
        <GlobalSearch />
        <div ref={ref} className="relative">
          <button onClick={() => setMenu((m) => !m)} aria-haspopup="menu" aria-expanded={menu} aria-label="Account menu" className="flex items-center gap-2 rounded-lg p-1 hover:bg-slate-100">
            <div className="hidden text-right leading-tight sm:block">
              <p className="max-w-[10rem] truncate text-sm font-semibold text-slate-800">{user?.name}</p>
              <p className="text-xs capitalize text-slate-500">{user?.role}</p>
            </div>
            <span className="grid h-9 w-9 place-items-center rounded-full bg-brand-100 text-sm font-bold text-brand-700">{initials(user?.name)}</span>
          </button>
          {menu && (
            <div role="menu" className="absolute right-0 top-full z-50 mt-1 w-56 rounded-xl border border-slate-200 bg-white p-1 shadow-lg">
              <p className="truncate px-3 py-2 text-xs text-slate-500">{user?.email}</p>
              <Link role="menuitem" to={`${base}/profile`} onClick={() => setMenu(false)} className={item}><User size={16} aria-hidden /> Profile</Link>
              <Link role="menuitem" to={`${base}/settings`} onClick={() => setMenu(false)} className={item}><Settings size={16} aria-hidden /> Settings</Link>
              <button role="menuitem" onClick={signOut} className={`${item} text-red-600`}><LogOut size={16} aria-hidden /> Sign out</button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
