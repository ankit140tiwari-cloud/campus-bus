import { Search, X, Loader2 } from 'lucide-react';

// Search field used across the app: icon, clear button, optional loading spinner, Escape clears.
export default function SearchBox({ value, onChange, placeholder = 'Search', label, loading = false, className = '' }) {
  return (
    <div className={`relative ${className}`}>
      <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" aria-hidden />
      <input type="search" value={value} onChange={(e) => onChange(e.target.value)} onKeyDown={(e) => e.key === 'Escape' && onChange('')} placeholder={placeholder} aria-label={label || placeholder}
        className="min-h-[44px] w-full rounded-lg border border-slate-300 bg-white py-2 pl-9 pr-10 text-sm placeholder:text-slate-400 [&::-webkit-search-cancel-button]:hidden" />
      {loading ? <Loader2 size={16} className="absolute right-3 top-1/2 -translate-y-1/2 animate-spin text-slate-400" aria-hidden />
        : value && <button type="button" onClick={() => onChange('')} aria-label="Clear search" className="absolute right-1.5 top-1/2 grid h-8 w-8 -translate-y-1/2 place-items-center rounded-md text-slate-500 hover:bg-slate-100"><X size={16} /></button>}
    </div>
  );
}
