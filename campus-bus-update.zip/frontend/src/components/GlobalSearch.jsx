import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import * as Icons from 'lucide-react';
import { Search, X, SearchX } from 'lucide-react';
import useAuth from '../hooks/useAuth';
import { ADMIN_NAV, STUDENT_NAV, SEARCH_EXTRAS } from '../utils/constants';
import { searchItems } from '../utils/search';
import { cx } from '../utils/helpers';

// Searches every page and the settings people look for by name. Arrow keys move, Enter opens, Esc closes.
export default function GlobalSearch() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const role = user?.role === 'admin' ? 'admin' : 'student';
  const items = useMemo(() => [...(role === 'admin' ? ADMIN_NAV : STUDENT_NAV), ...SEARCH_EXTRAS[role]], [role]);
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);      // dropdown
  const [sheet, setSheet] = useState(false);    // full-width bar on small screens
  const [active, setActive] = useState(0);
  const input = useRef(null);
  const box = useRef(null);
  const results = useMemo(() => searchItems(items, q).slice(0, 8), [items, q]);
  const trimmed = q.trim();

  useEffect(() => setActive(0), [q]);
  useEffect(() => {
    const away = (e) => { if (box.current && !box.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', away);
    return () => document.removeEventListener('mousedown', away);
  }, []);
  useEffect(() => { if (sheet) input.current?.focus(); }, [sheet]);

  const choose = (it) => {
    setQ(''); setOpen(false); setSheet(false);
    if (it.action === 'logout') { logout(); navigate('/'); } else navigate(it.to);
  };
  const onKey = (e) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setOpen(true); setActive((a) => Math.min(a + 1, results.length - 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActive((a) => Math.max(a - 1, 0)); }
    else if (e.key === 'Enter' && results[active]) { e.preventDefault(); choose(results[active]); }
    else if (e.key === 'Escape') { setOpen(false); setSheet(false); input.current?.blur(); }
  };

  const field = (
    <div className="relative">
      <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" aria-hidden />
      <input ref={input} value={q} onChange={(e) => { setQ(e.target.value); setOpen(true); }} onFocus={() => setOpen(true)} onKeyDown={onKey}
        role="combobox" aria-expanded={open && !!trimmed} aria-controls="global-search-list" aria-activedescendant={results[active] ? `gs-${active}` : undefined} aria-label="Search pages and settings"
        placeholder="Search pages and settings…" autoComplete="off"
        className="min-h-[40px] w-full rounded-lg border border-slate-300 bg-white py-2 pl-9 pr-9 text-sm placeholder:text-slate-400" />
      {q && <button onClick={() => { setQ(''); input.current?.focus(); }} aria-label="Clear search" className="absolute right-1.5 top-1/2 grid h-8 w-8 -translate-y-1/2 place-items-center rounded-md text-slate-500 hover:bg-slate-100"><X size={16} /></button>}
      {open && trimmed && (
        <ul id="global-search-list" role="listbox" className="absolute left-0 right-0 top-full z-50 mt-1 max-h-80 overflow-y-auto rounded-xl border border-slate-200 bg-white p-1 shadow-lg">
          {results.length ? results.map((it, i) => {
            const Icon = Icons[it.icon] || Search;
            return (
              <li key={it.to || it.action} id={`gs-${i}`} role="option" aria-selected={i === active} onMouseEnter={() => setActive(i)} onMouseDown={(e) => { e.preventDefault(); choose(it); }}
                className={cx('flex min-h-[44px] cursor-pointer items-center gap-3 rounded-lg px-3 text-sm', i === active ? 'bg-brand-50 text-brand-700' : 'text-slate-700')}>
                <Icon size={16} aria-hidden /><span className="font-medium">{it.label}</span>
              </li>
            );
          }) : (
            <li role="option" aria-selected="false" className="flex items-center gap-2 px-3 py-4 text-sm text-slate-500"><SearchX size={16} aria-hidden />No results found for “{trimmed}”</li>
          )}
        </ul>
      )}
    </div>
  );

  return (
    <div ref={box} className="min-w-0">
      <div className="hidden w-64 md:block lg:w-80">{field}</div>
      <button onClick={() => setSheet(true)} aria-label="Search" className="grid h-10 w-10 place-items-center rounded-md text-slate-600 hover:bg-slate-100 md:hidden"><Search size={20} /></button>
      {sheet && (
        <div className="fixed inset-x-0 top-0 z-50 flex items-center gap-2 border-b border-slate-200 bg-white p-3 md:hidden">
          <div className="flex-1">{field}</div>
          <button onClick={() => { setSheet(false); setQ(''); }} className="min-h-[40px] rounded-md px-3 text-sm font-medium text-slate-600">Cancel</button>
        </div>
      )}
    </div>
  );
}
