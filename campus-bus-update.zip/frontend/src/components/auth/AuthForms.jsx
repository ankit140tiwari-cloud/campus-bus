import { useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { CheckCircle2, Check, Circle, TriangleAlert, Loader2 } from 'lucide-react';
import useAuth from '../../hooks/useAuth';
import { register, forgotPassword, resetPassword, verifyEmail } from '../../services/authService';
import { HOME_BY_ROLE } from '../../utils/constants';
import { USE_MOCK } from '../../utils/config';
import { passwordChecks, passwordProblem } from '../../utils/passwordRules';
import Input from '../Input';
import Button from '../Button';
import { cx } from '../../utils/helpers';

const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
const Notice = ({ tone = 'error', children }) => (
  <p role={tone === 'error' ? 'alert' : 'status'} className={cx('rounded-lg p-3 text-sm', tone === 'error' ? 'bg-red-50 text-red-700' : 'bg-brand-50 text-brand-700')}>{children}</p>
);
const Heading = ({ title, text }) => (<div className="mb-6"><h2 className="text-2xl font-bold text-slate-900">{title}</h2><p className="mt-1 text-sm text-slate-500">{text}</p></div>);

function PasswordHints({ value }) {
  return (
    <ul className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs" aria-label="Password requirements">
      {passwordChecks(value).map((c) => <li key={c.label} className={cx('flex items-center gap-1', c.ok ? 'text-green-600' : 'text-slate-500')}>{c.ok ? <Check size={12} /> : <Circle size={10} />}{c.label}</li>)}
    </ul>
  );
}

export function LoginForm() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [f, setF] = useState({ identifier: '', password: '', remember: false });
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    const x = {};
    if (!f.identifier.trim()) x.identifier = 'Enter your email or Student ID.';
    if (!f.password) x.password = 'Enter your password.';
    setErrors(x);
    if (Object.keys(x).length) return;
    setBusy(true);
    try { const u = await login(f); navigate(HOME_BY_ROLE[u.role], { replace: true }); }
    catch (ex) { setErrors({ form: ex.message }); } finally { setBusy(false); }
  };

  return (
    <>
      <Heading title="Welcome back" text="Sign in with your college email or Student ID." />
      <form onSubmit={submit} className="space-y-4" noValidate>
        {errors.form && <Notice>{errors.form}</Notice>}
        <Input label="Email / Student ID" autoComplete="username" value={f.identifier} onChange={set('identifier')} error={errors.identifier} />
        <Input label="Password" type="password" autoComplete="current-password" value={f.password} onChange={set('password')} error={errors.password} />
        <div className="flex items-center justify-between text-sm">
          <label className="flex min-h-[44px] items-center gap-2 text-slate-600"><input type="checkbox" checked={f.remember} onChange={set('remember')} className="h-4 w-4 rounded border-slate-300" />Remember me</label>
          <Link to="/forgot-password" className="font-medium text-brand-600 hover:underline">Forgot password?</Link>
        </div>
        <Button type="submit" loading={busy} className="w-full">Sign in</Button>
      </form>
      <p className="mt-6 text-center text-sm text-slate-500">New here? <Link to="/signup" className="font-medium text-brand-600 hover:underline">Create an account</Link></p>
      {USE_MOCK && <p className="mt-6 rounded-lg border border-dashed border-slate-300 p-3 text-xs text-slate-500">Sample-data mode: student@college.edu / student123 or admin@college.edu / admin123. Nothing is saved.</p>}
    </>
  );
}

export function SignupForm() {
  const [f, setF] = useState({ name: '', email: '', studentId: '', department: '', password: '', confirm: '' });
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(null);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    const x = {};
    if (!f.name.trim()) x.name = 'Enter your full name.';
    if (!EMAIL_RE.test(f.email.trim())) x.email = 'Enter a valid email address.';
    if (!f.studentId.trim()) x.studentId = 'Enter your Student ID.';
    const p = passwordProblem(f.password);
    if (p) x.password = p;
    if (f.confirm !== f.password) x.confirm = 'The passwords do not match.';
    setErrors(x);
    if (Object.keys(x).length) return;
    setBusy(true);
    try { setDone(await register({ ...f, name: f.name.trim(), email: f.email.trim(), studentId: f.studentId.trim() })); }
    catch (ex) { setErrors({ form: ex.message }); } finally { setBusy(false); }
  };

  if (done) {
    return (
      <div className="text-center">
        <CheckCircle2 size={44} className="mx-auto text-green-600" aria-hidden />
        <h2 className="mt-3 text-2xl font-bold text-slate-900">Account created</h2>
        <p className="mt-2 text-sm text-slate-600">
          {done.email_configured ? `We sent a confirmation link to ${f.email.trim()}. ` : ''}
          {done.verification_required ? 'Confirm your email, then sign in.' : 'You can sign in now.'}
        </p>
        <Link to="/login" className="mt-6 inline-flex min-h-[44px] items-center rounded-lg bg-brand-600 px-6 text-sm font-semibold text-white hover:bg-brand-700">Go to sign in</Link>
      </div>
    );
  }
  return (
    <>
      <Heading title="Create your account" text="Students register here. Administrators are added by the transport office." />
      <form onSubmit={submit} className="space-y-4" noValidate>
        {errors.form && <Notice>{errors.form}</Notice>}
        <Input label="Full name" autoComplete="name" value={f.name} onChange={set('name')} error={errors.name} />
        <Input label="College email" type="email" autoComplete="email" value={f.email} onChange={set('email')} error={errors.email} />
        <div className="grid gap-4 sm:grid-cols-2">
          <Input label="Student ID" value={f.studentId} onChange={set('studentId')} error={errors.studentId} />
          <Input label="Department (optional)" value={f.department} onChange={set('department')} />
        </div>
        <div>
          <Input label="Password" type="password" autoComplete="new-password" value={f.password} onChange={set('password')} error={errors.password} />
          <PasswordHints value={f.password} />
        </div>
        <Input label="Confirm password" type="password" autoComplete="new-password" value={f.confirm} onChange={set('confirm')} error={errors.confirm} />
        <Button type="submit" loading={busy} className="w-full">Create account</Button>
      </form>
      <p className="mt-6 text-center text-sm text-slate-500">Already registered? <Link to="/login" className="font-medium text-brand-600 hover:underline">Sign in</Link></p>
    </>
  );
}

export function ForgotForm() {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    if (!EMAIL_RE.test(email.trim())) return setError('Enter a valid email address.');
    setError(''); setBusy(true);
    try { await forgotPassword(email.trim()); setSent(true); } catch (ex) { setError(ex.message); } finally { setBusy(false); }
  };

  return sent ? (
    <div className="text-center">
      <CheckCircle2 size={44} className="mx-auto text-green-600" aria-hidden />
      <h2 className="mt-3 text-2xl font-bold text-slate-900">Check your email</h2>
      <p className="mt-2 text-sm text-slate-600">If an account exists for {email.trim()}, a link to choose a new password is on its way. It works once and expires soon.</p>
      <Link to="/login" className="mt-6 inline-block text-sm font-medium text-brand-600 hover:underline">Back to sign in</Link>
    </div>
  ) : (
    <>
      <Heading title="Reset your password" text="Enter your email and we will send you a link." />
      <form onSubmit={submit} className="space-y-4" noValidate>
        <Input label="Email" type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} error={error} />
        <Button type="submit" loading={busy} className="w-full">Send reset link</Button>
      </form>
      <p className="mt-6 text-center text-sm"><Link to="/login" className="font-medium text-brand-600 hover:underline">Back to sign in</Link></p>
    </>
  );
}

export function ResetForm() {
  const [params] = useSearchParams();
  const token = params.get('token') || '';
  const [f, setF] = useState({ next: '', confirm: '' });
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    const x = {};
    const p = passwordProblem(f.next);
    if (p) x.next = p;
    if (f.confirm !== f.next) x.confirm = 'The passwords do not match.';
    setErrors(x);
    if (Object.keys(x).length) return;
    setBusy(true);
    try { await resetPassword(token, f.next); setDone(true); } catch (ex) { setErrors({ form: ex.message }); } finally { setBusy(false); }
  };

  if (!token) return <><Notice>This reset link is incomplete. Open the link from your email again, or request a new one.</Notice><Link to="/forgot-password" className="mt-4 inline-block text-sm font-medium text-brand-600 hover:underline">Request a new link</Link></>;
  if (done) {
    return (
      <div className="text-center">
        <CheckCircle2 size={44} className="mx-auto text-green-600" aria-hidden />
        <h2 className="mt-3 text-2xl font-bold text-slate-900">Password updated</h2>
        <p className="mt-2 text-sm text-slate-600">Sign in with your new password. Any other devices were signed out.</p>
        <Link to="/login" className="mt-6 inline-flex min-h-[44px] items-center rounded-lg bg-brand-600 px-6 text-sm font-semibold text-white hover:bg-brand-700">Go to sign in</Link>
      </div>
    );
  }
  return (
    <>
      <Heading title="Choose a new password" text="Pick something you do not use anywhere else." />
      <form onSubmit={submit} className="space-y-4" noValidate>
        {errors.form && <Notice>{errors.form} <Link to="/forgot-password" className="font-semibold underline">Request a new link</Link></Notice>}
        <div>
          <Input label="New password" type="password" autoComplete="new-password" value={f.next} onChange={(e) => setF({ ...f, next: e.target.value })} error={errors.next} />
          <PasswordHints value={f.next} />
        </div>
        <Input label="Confirm new password" type="password" autoComplete="new-password" value={f.confirm} onChange={(e) => setF({ ...f, confirm: e.target.value })} error={errors.confirm} />
        <Button type="submit" loading={busy} className="w-full">Update password</Button>
      </form>
    </>
  );
}

export function VerifyPanel() {
  const [params] = useSearchParams();
  const token = params.get('token');
  const [state, setState] = useState(token ? 'loading' : 'error');
  const [message, setMessage] = useState(token ? '' : 'This confirmation link is incomplete.');

  useEffect(() => {
    if (!token) return;
    verifyEmail(token).then(() => setState('ok')).catch((e) => { setState('error'); setMessage(e.message); });
  }, [token]);

  return (
    <div className="text-center">
      {state === 'loading' && <><Loader2 size={40} className="mx-auto animate-spin text-brand-600" aria-hidden /><p className="mt-3 text-sm text-slate-600">Confirming your email…</p></>}
      {state === 'ok' && <><CheckCircle2 size={44} className="mx-auto text-green-600" aria-hidden /><h2 className="mt-3 text-2xl font-bold text-slate-900">Email confirmed</h2><p className="mt-2 text-sm text-slate-600">Thank you. Your email address is verified.</p><Link to="/login" className="mt-6 inline-flex min-h-[44px] items-center rounded-lg bg-brand-600 px-6 text-sm font-semibold text-white hover:bg-brand-700">Continue to sign in</Link></>}
      {state === 'error' && <><TriangleAlert size={44} className="mx-auto text-amber-600" aria-hidden /><h2 className="mt-3 text-2xl font-bold text-slate-900">Link not valid</h2><p className="mt-2 text-sm text-slate-600">{message}</p><Link to="/login" className="mt-6 inline-block text-sm font-medium text-brand-600 hover:underline">Back to sign in</Link></>}
    </div>
  );
}
