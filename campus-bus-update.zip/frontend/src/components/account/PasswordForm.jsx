import { useState } from 'react';
import useAuth from '../../hooks/useAuth';
import { changePassword } from '../../services/authService';
import { passwordProblem } from '../../utils/passwordRules';
import { useToast } from '../Toast';
import Input from '../Input';
import Button from '../Button';
import Card from '../Card';

export default function PasswordForm() {
  const { setToken } = useAuth();
  const toast = useToast();
  const [f, setF] = useState({ current: '', next: '', confirm: '' });
  const [err, setErr] = useState({});
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    const x = {};
    if (!f.current) x.current = 'Enter your current password.';
    const p = passwordProblem(f.next);
    if (p) x.next = p;
    else if (f.next === f.current) x.next = 'Choose a password different from the current one.';
    if (f.confirm !== f.next) x.confirm = 'The passwords do not match.';
    setErr(x);
    if (Object.keys(x).length) return;
    setBusy(true);
    try {
      const token = await changePassword({ current: f.current, next: f.next });
      if (token) setToken(token); // this device stays signed in; every other device is signed out by the server
      setF({ current: '', next: '', confirm: '' });
      toast('Password changed. Your other devices were signed out.');
    } catch (ex) { setErr({ current: ex.message }); toast(ex.message, 'error'); } finally { setBusy(false); }
  };

  return (
    <Card title="Change password">
      <form onSubmit={submit} className="grid max-w-md gap-4" noValidate>
        <Input label="Current password" type="password" autoComplete="current-password" value={f.current} onChange={set('current')} error={err.current} />
        <Input label="New password" type="password" autoComplete="new-password" value={f.next} onChange={set('next')} error={err.next} hint="At least 8 characters with a letter and a number." />
        <Input label="Confirm new password" type="password" autoComplete="new-password" value={f.confirm} onChange={set('confirm')} error={err.confirm} />
        <Button type="submit" loading={busy} className="sm:w-fit">Change password</Button>
      </form>
    </Card>
  );
}
