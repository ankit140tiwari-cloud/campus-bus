import useAuth from '../../hooks/useAuth';
import Card from '../Card';
import Logo from '../Logo';
import { APP_VERSION } from '../../utils/constants';

export default function AboutCard() {
  const { user } = useAuth();
  return (
    <Card>
      <Logo />
      <p className="mt-4 text-sm text-slate-600">Campus Bus helps students find the right bus, its route, stops, departure times, live location and ETA, and gives administrators one place to manage the whole college transportation system.</p>
      <dl className="mt-4 grid grid-cols-2 gap-4 text-sm">
        <div><dt className="text-slate-500">Version</dt><dd className="font-semibold">{APP_VERSION}</dd></div>
        <div><dt className="text-slate-500">Signed in as</dt><dd className="font-semibold capitalize">{user.role}</dd></div>
        <div className="col-span-2"><dt className="text-slate-500">Built with</dt><dd className="font-semibold">React, FastAPI, PostgreSQL, WebSocket, Leaflet and scikit-learn</dd></div>
      </dl>
    </Card>
  );
}
