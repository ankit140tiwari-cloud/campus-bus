import { Sun, Moon, Monitor } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import { useToast } from '../Toast';
import Card from '../Card';
import { cx } from '../../utils/helpers';

const OPTIONS = [['light', 'Light', Sun, 'Bright background'], ['dark', 'Dark', Moon, 'Easier on the eyes at night'], ['system', 'System', Monitor, 'Match this device']];

export default function ThemePicker() {
  const { mode, setMode } = useTheme();
  const toast = useToast();
  const pick = async (m) => { try { await setMode(m); } catch (e) { toast(e.message, 'error'); } };
  return (
    <Card title="Theme">
      <div role="radiogroup" aria-label="Theme" className="grid gap-3 sm:grid-cols-3">
        {OPTIONS.map(([k, label, Icon, hint]) => (
          <button key={k} role="radio" aria-checked={mode === k} onClick={() => pick(k)}
            className={cx('flex min-h-[72px] flex-col items-start gap-1 rounded-xl border p-3 text-left', mode === k ? 'border-brand-500 bg-brand-50 ring-2 ring-brand-500/30' : 'border-slate-200 hover:border-slate-300')}>
            <Icon size={18} className={mode === k ? 'text-brand-600' : 'text-slate-500'} aria-hidden />
            <span className="text-sm font-semibold text-slate-900">{label}</span>
            <span className="text-xs text-slate-500">{hint}</span>
          </button>
        ))}
      </div>
      <p className="mt-3 text-xs text-slate-500">Your choice is saved to your account and follows you to other devices.</p>
    </Card>
  );
}
