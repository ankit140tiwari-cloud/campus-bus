import { useEffect, useState } from 'react';
import useAsync from '../../hooks/useAsync';
import { getCampus, saveCampus } from '../../services/campusService';
import { useToast } from '../Toast';
import Card from '../Card';
import Input from '../Input';
import Button from '../Button';
import ErrorNote from '../ErrorNote';
import MapComponent from '../MapComponent';
import { cx } from '../../utils/helpers';

const blank = { name: '', lat: '', lng: '' };
const num = (v) => (v === '' || Number.isNaN(Number(v)) ? null : Number(v));
const pinOf = (p) => (num(p.lat) != null && num(p.lng) != null && Math.abs(num(p.lat)) <= 90 && Math.abs(num(p.lng)) <= 180 ? { lat: num(p.lat), lng: num(p.lng) } : null);

// Where the college and its front gate are. Students see the gate on the bus map and distances are measured from it.
export default function CampusForm() {
  const { data, loading, error, reload } = useAsync(getCampus, []);
  const toast = useToast();
  const [form, setForm] = useState({ college: { ...blank, name: 'College' }, gate: { ...blank, name: 'College front gate' } });
  const [target, setTarget] = useState('gate');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!data) return;
    const f = (p, name) => (p ? { name: p.name, lat: String(p.lat), lng: String(p.lng) } : { ...blank, name });
    setForm({ college: f(data.college, 'College'), gate: f(data.gate, 'College front gate') });
  }, [data]);

  const set = (who, k) => (e) => setForm({ ...form, [who]: { ...form[who], [k]: e.target.value } });
  const pick = (lat, lng) => setForm((f) => ({ ...f, [target]: { ...f[target], lat: lat.toFixed(6), lng: lng.toFixed(6) } }));
  const other = target === 'gate' ? 'college' : 'gate';
  const otherPin = pinOf(form[other]);

  const save = async () => {
    for (const who of ['college', 'gate']) {
      if (!form[who].name.trim() || !pinOf(form[who])) return toast(`Enter a name and valid latitude and longitude for the ${who === 'gate' ? 'front gate' : 'college'}.`, 'error');
    }
    setBusy(true);
    try { await saveCampus(form); toast('Campus location saved'); reload(); }
    catch (e) { toast(e.message, 'error'); } finally { setBusy(false); }
  };

  if (error) return <ErrorNote message={error} onRetry={reload} />;
  return (
    <Card title="College and front gate location">
      <p className="mb-3 text-sm text-slate-500">Students see the front gate on the bus map and the distance of each bus from it. Pick which point to place, then click the map.</p>
      {loading ? <p className="text-sm text-slate-500">Loading…</p> : (
        <div className="space-y-4">
          <div role="radiogroup" aria-label="Which point to place" className="flex gap-2">
            {[['gate', 'Front gate'], ['college', 'College']].map(([k, l]) => (
              <button key={k} role="radio" aria-checked={target === k} onClick={() => setTarget(k)}
                className={cx('min-h-[40px] rounded-full px-4 text-sm font-medium', target === k ? 'bg-brand-600 text-white' : 'border border-slate-300 text-slate-700')}>{l}</button>
            ))}
          </div>
          <MapComponent className="h-64" label="Pick the location on the map" pin={pinOf(form[target])} onMapClick={pick}
            stops={otherPin ? [{ name: form[other].name || other, lat: otherPin.lat, lng: otherPin.lng, isCollege: other === 'college' }] : []} />
          <div className="grid gap-4 sm:grid-cols-2">
            {['college', 'gate'].map((who) => (
              <fieldset key={who} className="space-y-3 rounded-xl border border-slate-200 p-3">
                <legend className="px-1 text-sm font-semibold text-slate-800">{who === 'gate' ? 'Front gate' : 'College'}</legend>
                <Input label="Name" value={form[who].name} onChange={set(who, 'name')} />
                <div className="grid grid-cols-2 gap-3">
                  <Input label="Latitude" inputMode="decimal" value={form[who].lat} onChange={set(who, 'lat')} />
                  <Input label="Longitude" inputMode="decimal" value={form[who].lng} onChange={set(who, 'lng')} />
                </div>
              </fieldset>
            ))}
          </div>
          <Button onClick={save} loading={busy}>Save location</Button>
        </div>
      )}
    </Card>
  );
}
