import { useState } from 'react';
import useAuth from '../../hooks/useAuth';
import useAsync from '../../hooks/useAsync';
import { updateProfile, resendVerification } from '../../services/authService';
import { getStopOptions } from '../../services/routeService';
import { pushConfigured, pushSupported, pushEnabled, enablePush, disablePush } from '../../services/pushService';
import { USE_MOCK } from '../../utils/config';
import { initials } from '../../utils/helpers';
import { useToast } from '../Toast';
import Input from '../Input';
import Select from '../Select';
import Button from '../Button';
import Card from '../Card';
import Badge from '../Badge';

const PREFS = [['departed', 'Bus departed'], ['delayed', 'Bus delayed'], ['arriving', 'Bus arriving soon'], ['changes', 'Route or schedule changes'], ['emergency', 'Emergency announcements']];
const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
const PHONE_RE = /^\+?[0-9][0-9 -]{5,18}$/;

// One profile form for students and admins. Saving writes to the database, then the signed-in user (and so the navbar) is updated from the saved copy.
export default function ProfileForm() {
  const { user, updateUser } = useAuth();
  const toast = useToast();
  const student = user.role === 'student';
  const stops = useAsync(() => (student ? getStopOptions() : Promise.resolve([])), [student]).data || [];
  const [form, setForm] = useState({ name: user.name, email: user.email, phone: user.phone || '', department: user.department || '', defaultStop: user.defaultStop || '', currentPassword: '' });
  const [prefs, setPrefs] = useState({ ...Object.fromEntries(PREFS.map(([k]) => [k, true])), ...(user.prefs || {}) });
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const [push, setPush] = useState(pushEnabled());
  const [pushBusy, setPushBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const emailChanged = form.email.trim().toLowerCase() !== user.email.toLowerCase();

  const save = async (e) => {
    e.preventDefault();
    const err = {};
    if (!form.name.trim()) err.name = 'Enter your name.';
    if (!EMAIL_RE.test(form.email.trim())) err.email = 'Enter a valid email address.';
    if (form.phone.trim() && !PHONE_RE.test(form.phone.trim())) err.phone = 'Enter a valid phone number (7 to 15 digits).';
    if (emailChanged && !form.currentPassword) err.currentPassword = 'Enter your current password to change your email.';
    setErrors(err);
    if (Object.keys(err).length) return;
    setBusy(true);
    try {
      const patch = { name: form.name.trim(), department: form.department.trim(), phone: form.phone.trim() };
      if (emailChanged) Object.assign(patch, { email: form.email.trim(), currentPassword: form.currentPassword });
      if (student) Object.assign(patch, { defaultStop: form.defaultStop, prefs });
      const saved = await updateProfile(patch);
      updateUser(saved);
      setForm((f) => ({ ...f, name: saved.name ?? f.name, email: saved.email ?? f.email, currentPassword: '' }));
      toast(emailChanged && !USE_MOCK ? 'Saved. Check your inbox to confirm the new email address.' : 'Profile saved');
    } catch (ex) { toast(ex.message, 'error'); } finally { setBusy(false); }
  };

  const togglePush = async () => {
    setPushBusy(true);
    try {
      if (push) { await disablePush(); setPush(false); toast('Push notifications turned off on this device'); }
      else { await enablePush(); setPush(true); toast('Push notifications turned on for this device'); }
    } catch (ex) { toast(ex.message, 'error'); } finally { setPushBusy(false); }
  };

  const resend = async () => { try { await resendVerification(); toast('Confirmation email sent'); } catch (ex) { toast(ex.message, 'error'); } };

  return (
    <form onSubmit={save} className="space-y-4" noValidate>
      <div className="flex items-center gap-4">
        <span className="grid h-14 w-14 place-items-center rounded-full bg-brand-100 text-lg font-bold text-brand-700">{initials(user.name)}</span>
        <div className="min-w-0">
          <p className="truncate text-lg font-bold text-slate-900">{user.name}</p>
          <p className="flex flex-wrap items-center gap-2 text-sm text-slate-500">{user.email}
            {!USE_MOCK && (user.emailVerified ? <Badge tone="success">Verified</Badge> : <><Badge tone="warning">Not verified</Badge><button type="button" onClick={resend} className="text-brand-600 hover:underline">Resend email</button></>)}
          </p>
        </div>
      </div>

      <Card title="Account details">
        <div className="grid gap-4 sm:grid-cols-2">
          <Input label="Name" value={form.name} onChange={set('name')} error={errors.name} autoComplete="name" />
          <Input label="Email" type="email" value={form.email} onChange={set('email')} error={errors.email} autoComplete="email" hint="You sign in with this address." />
          {emailChanged && <Input className="sm:col-span-2" label="Current password (needed to change your email)" type="password" autoComplete="current-password" value={form.currentPassword} onChange={set('currentPassword')} error={errors.currentPassword} />}
          <Input label="Phone number" type="tel" placeholder="Optional" value={form.phone} onChange={set('phone')} error={errors.phone} autoComplete="tel" />
          <Input label={student ? 'Department' : 'Role / department'} value={form.department} onChange={set('department')} />
          {student && <Input label="Student ID" value={user.studentId || ''} disabled hint="Contact the transport office to change this." />}
          {student && <Select label="Default bus stop" placeholder="Choose your stop" options={stops} value={form.defaultStop} onChange={set('defaultStop')} />}
        </div>
      </Card>

      {student && (
        <Card title="Notification preferences">
          <ul className="divide-y divide-slate-100">
            {PREFS.map(([k, label]) => (
              <li key={k}><label className="flex min-h-[44px] items-center justify-between text-sm"><span>{label}</span>
                <input type="checkbox" checked={!!prefs[k]} disabled={k === 'emergency'} onChange={(e) => setPrefs({ ...prefs, [k]: e.target.checked })} className="h-5 w-5 rounded border-slate-300" /></label></li>
            ))}
          </ul>
          <p className="mt-2 text-xs text-slate-500">Emergency announcements are always delivered.</p>
        </Card>
      )}

      {student && !USE_MOCK && (
        <Card title="Push notifications">
          {!pushSupported() ? <p className="text-sm text-slate-500">This browser does not support push notifications.</p>
            : !pushConfigured() ? <p className="text-sm text-slate-500">Push is not set up on this server yet. You will still see notifications inside the app.</p>
            : (
              <div className="flex items-center justify-between gap-3">
                <p className="text-sm text-slate-600">{push ? 'On for this device.' : 'Get bus alerts even when the app is closed.'}</p>
                <Button type="button" variant="secondary" loading={pushBusy} onClick={togglePush}>{push ? 'Turn off' : 'Turn on'}</Button>
              </div>
            )}
        </Card>
      )}

      <Button type="submit" loading={busy} className="w-full sm:w-auto">Save changes</Button>
    </form>
  );
}
