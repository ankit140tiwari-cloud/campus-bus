import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogOut, ShieldCheck } from 'lucide-react';
import useAuth from '../../hooks/useAuth';
import { logoutAllDevices } from '../../services/authService';
import { useToast } from '../Toast';
import PasswordForm from './PasswordForm';
import ConfirmDialog from '../ConfirmDialog';
import Button from '../Button';
import Card from '../Card';

export default function SecurityPanel() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);

  const everywhere = async () => {
    setBusy(true);
    try { await logoutAllDevices(); logout(); navigate('/login'); }
    catch (e) { toast(e.message, 'error'); setConfirm(false); } finally { setBusy(false); }
  };

  return (
    <div className="space-y-4">
      <PasswordForm />
      <Card title="Sessions">
        <div className="flex items-start gap-3 text-sm text-slate-600">
          <ShieldCheck size={18} className="mt-0.5 shrink-0 text-green-600" aria-hidden />
          <div>
            <p>Your password is stored only as a salted hash. Sessions expire automatically, and changing your password signs out every other device.</p>
            {user.lastLoginAt && <p className="mt-1 text-slate-500">Last sign-in: {new Date(user.lastLoginAt).toLocaleString('en-IN')}</p>}
          </div>
        </div>
        <Button variant="secondary" className="mt-4" onClick={() => setConfirm(true)}><LogOut size={16} aria-hidden /> Sign out of all devices</Button>
      </Card>
      <ConfirmDialog open={confirm} title="Sign out everywhere?" confirmLabel="Sign out of all devices" loading={busy} onClose={() => setConfirm(false)} onConfirm={everywhere}
        message="You will be signed out on this device and every other device where you are signed in." />
    </div>
  );
}
