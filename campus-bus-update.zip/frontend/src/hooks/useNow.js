import { useEffect, useState } from 'react';

// Current time in ms, re-rendering every `ms`, so "updated 12 s ago" keeps counting without any server traffic.
export default function useNow(ms = 1000) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => { const id = setInterval(() => setNow(Date.now()), ms); return () => clearInterval(id); }, [ms]);
  return now;
}
