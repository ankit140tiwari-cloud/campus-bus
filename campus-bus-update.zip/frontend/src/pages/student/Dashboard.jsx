import { useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Bus, Search, Bell, MapPin, LocateFixed, Route as RouteIcon, CalendarClock, MessageSquareWarning, Megaphone } from 'lucide-react';
import useAuth from '../../hooks/useAuth';
import useAsync from '../../hooks/useAsync';
import useNow from '../../hooks/useNow';
import useBusLocation from '../../hooks/useBusLocation';
import { getNextBus, getBuses } from '../../services/busService';
import { getRoutes } from '../../services/routeService';
import { getNotifications, markRead, markAllRead } from '../../services/studentService';
import { applySnapshot } from '../../utils/liveHelpers';
import { stopsForMap, lineFor, busForMap } from '../../utils/mapHelpers';
import { agoText } from '../../utils/helpers';
import { useToast } from '../../components/Toast';
import Card from '../../components/Card';
import Badge from '../../components/Badge';
import Button from '../../components/Button';
import EtaTag from '../../components/EtaTag';
import LiveBadge from '../../components/LiveBadge';
import LiveWarning from '../../components/LiveWarning';
import MapComponent from '../../components/MapComponent';
import StopTimeline from '../../components/StopTimeline';
import NotificationItem from '../../components/NotificationItem';
import EmptyState from '../../components/EmptyState';
import LoadingSkeleton from '../../components/LoadingSkeleton';
import ErrorNote from '../../components/ErrorNote';

const ACTIONS = [['/student/find-bus', 'Find Bus', Search], ['/student/live', 'Live Tracking', MapPin], ['/student/bus-locations', 'Bus Locations', LocateFixed], ['/student/routes', 'Routes', RouteIcon], ['/student/schedule', 'Schedule', CalendarClock], ['/student/report', 'Report Issue', MessageSquareWarning]];

export default function StudentDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();
  const now = useNow(1000);
  const next = useAsync(() => getNextBus(user.defaultStop), [user.defaultStop]);
  const fleet = useAsync(getBuses, []);
  const routes = useAsync(getRoutes, []);
  const notes = useAsync(getNotifications, []);
  const { updates, status } = useBusLocation();

  const nextBus = useMemo(() => next.data && applySnapshot(next.data, updates[next.data.number], user.defaultStop), [next.data, updates, user.defaultStop]);
  const route = nextBus && (routes.data || []).find((r) => r.id === nextBus.routeId);
  const live = useMemo(() => (fleet.data || []).map((b) => applySnapshot(b, updates[b.number])), [fleet.data, updates]);
  const running = live.filter((b) => b.status !== 'Offline').length;
  const delayed = live.filter((b) => b.status === 'Delayed').length;
  const list = notes.data || [];
  const unread = list.filter((n) => !n.read).length;
  const alert = list.find((n) => ['emergency', 'announcement'].includes(n.type));
  const age = nextBus?.updatedAt ? now - nextBus.updatedAt : null;

  const read = async (id) => { await markRead(id); notes.setData(list.map((n) => (n.id === id ? { ...n, read: true } : n))); };
  const readAll = async () => { await markAllRead(); notes.setData(list.map((n) => ({ ...n, read: true }))); toast('All notifications marked as read'); };

  return (
    <div className="grid w-full gap-4 lg:grid-cols-12 lg:items-start">
      <div className="min-w-0 space-y-4 lg:col-span-8 xl:col-span-9">
        <div className="flex flex-wrap items-end justify-between gap-2">
          <div>
            <h1 className="text-xl font-bold text-slate-900 sm:text-2xl">Hi, {user.name.split(' ')[0]}</h1>
            <p className="text-sm text-slate-500">{user.defaultStop ? <>Your stop: <b className="text-slate-700">{user.defaultStop}</b></> : <>No default stop yet. <Link to="/student/profile" className="font-medium text-brand-600 hover:underline">Choose one in your profile</Link></>}</p>
          </div>
          <LiveBadge status={status} />
        </div>
        <LiveWarning status={status} />

        <div className="grid gap-4 xl:grid-cols-5">
          {/* 1. bus status + 3. next bus / ETA */}
          <Card title="Next bus to your stop" className="xl:col-span-3">
            {next.loading ? <LoadingSkeleton rows={1} /> : next.error ? <ErrorNote message={next.error} onRetry={next.reload} /> : nextBus ? (
              <div className="space-y-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <span className="grid h-12 w-12 place-items-center rounded-xl bg-brand-50 text-brand-600"><Bus aria-hidden /></span>
                    <div><p className="text-lg font-bold text-slate-900">{nextBus.number}</p><p className="text-sm text-slate-500">{nextBus.routeName}</p></div>
                  </div>
                  <Badge>{nextBus.status}</Badge>
                </div>
                <div>
                  <p className="text-5xl font-bold text-slate-900">{nextBus.eta ?? '—'}<span className="ml-1 text-xl font-medium text-slate-500">min</span></p>
                  <EtaTag meta={nextBus.etaMeta} km={nextBus.distanceKm} />
                </div>
                <dl className="grid grid-cols-3 gap-3 text-sm">
                  <div><dt className="text-slate-500">Now at</dt><dd className="font-semibold">{nextBus.currentLocation}</dd></div>
                  <div><dt className="text-slate-500">Next stop</dt><dd className="font-semibold">{nextBus.nextStop}</dd></div>
                  <div><dt className="text-slate-500">Updated</dt><dd className={age > 45000 ? 'font-semibold text-amber-600' : 'font-semibold'}>{age == null ? '—' : agoText(age)}</dd></div>
                </dl>
                <div className="flex flex-wrap gap-2">
                  <Button onClick={() => navigate(`/student/live?bus=${nextBus.number}`)}>Track live</Button>
                  <Link to="/student/find-bus" className="inline-flex min-h-[44px] items-center rounded-lg border border-slate-300 px-4 text-sm font-semibold text-slate-700 hover:bg-slate-50">Find another bus</Link>
                </div>
              </div>
            ) : <EmptyState icon={Search} title="No bus is heading to your stop" message="Try Find Bus to search another stop or time." action={<Link to="/student/find-bus"><Button>Find Bus</Button></Link>} />}
          </Card>

          {/* 7. important transport information */}
          <Card title="Service overview" className="xl:col-span-2">
            <dl className="grid grid-cols-3 gap-3 text-center">
              {[['Running', running, 'text-green-600'], ['Delayed', delayed, delayed ? 'text-amber-600' : 'text-slate-900'], ['Total', live.length, 'text-slate-900']].map(([l, v, c]) => (
                <div key={l} className="rounded-lg bg-slate-50 p-3"><dd className={`text-2xl font-bold ${c}`}>{v}</dd><dt className="text-xs text-slate-500">{l}</dt></div>
              ))}
            </dl>
            <div className="mt-4 rounded-lg border border-slate-200 p-3 text-sm">
              <p className="flex items-center gap-2 font-semibold text-slate-800"><Megaphone size={16} className="text-brand-600" aria-hidden />{alert ? alert.title : 'No service announcements'}</p>
              <p className="mt-1 text-slate-600">{alert ? alert.message : 'Announcements from the transport office will appear here.'}</p>
            </div>
          </Card>
        </div>

        {/* 2. live bus location */}
        <Card title="Live bus location" action={nextBus && <Link to={`/student/live?bus=${nextBus.number}`} className="text-sm font-medium text-brand-600 hover:underline">Open tracking</Link>}>
          {nextBus ? (
            <MapComponent className="h-72 sm:h-96 xl:h-[26rem]" label={`Map showing ${nextBus.number}`} stops={stopsForMap(nextBus.routeStops)} lines={[lineFor(nextBus.routeId, nextBus.routeStops)]}
              buses={[busForMap(nextBus)].filter(Boolean)} highlight={user.defaultStop} />
          ) : <EmptyState icon={MapPin} title="No bus to show on the map" message="When a bus is heading to your stop it appears here." />}
        </Card>

        <div className="grid gap-4 md:grid-cols-2">
          {/* 4. route information */}
          <Card title="Route information" action={route && <span className="text-xs font-medium text-slate-500">{route.id}</span>}>
            {route ? (<><p className="mb-3 text-sm font-semibold text-slate-800">{route.name}</p><StopTimeline stops={route.stops} currentIdx={nextBus?.currentIdx ?? -2} highlight={user.defaultStop} /></>)
              : <p className="text-sm text-slate-500">Route details appear when a bus is heading to your stop.</p>}
          </Card>
          {/* 6. quick actions */}
          <Card title="Quick actions">
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-2">
              {ACTIONS.map(([to, label, Icon]) => (
                <Link key={to} to={to} className="flex min-h-[64px] flex-col items-start justify-center gap-1 rounded-xl border border-slate-200 p-3 text-sm font-medium text-slate-700 hover:border-brand-500 hover:bg-brand-50">
                  <Icon size={18} className="text-brand-600" aria-hidden />{label}
                </Link>
              ))}
            </div>
          </Card>
        </div>
      </div>

      {/* 5. notifications: right-hand panel on desktop, below the dashboard on small screens, scrolls on its own */}
      <aside aria-label="Notifications" className="lg:col-span-4 lg:sticky lg:top-20 xl:col-span-3">
        <section className="flex flex-col rounded-xl border border-slate-200 bg-white p-4">
          <header className="mb-3 flex items-center justify-between gap-2">
            <h2 className="flex items-center gap-2 text-sm font-semibold text-slate-900"><Bell size={16} aria-hidden />Notifications{unread > 0 && <span className="rounded-full bg-brand-600 px-2 py-0.5 text-xs text-white">{unread}</span>}</h2>
            {unread > 0 && <button onClick={readAll} className="text-xs font-medium text-brand-600 hover:underline">Mark all read</button>}
          </header>
          <div className="max-h-[28rem] overflow-y-auto pr-1 lg:max-h-[calc(100vh-12rem)]">
            {notes.loading ? <LoadingSkeleton rows={3} /> : notes.error ? <ErrorNote message={notes.error} onRetry={notes.reload} />
              : list.length ? <ul className="space-y-2">{list.map((n) => <NotificationItem key={n.id} n={n} onRead={read} />)}</ul>
              : <EmptyState icon={Bell} title="You're all caught up" message="New bus alerts will show up here." />}
          </div>
          <Link to="/student/notifications" className="mt-3 text-center text-sm font-medium text-brand-600 hover:underline">Open notification center</Link>
        </section>
      </aside>
    </div>
  );
}
