import { useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Info } from 'lucide-react';
import useAuth from '../../hooks/useAuth';
import useAsync from '../../hooks/useAsync';
import useBusLocation from '../../hooks/useBusLocation';
import useNow from '../../hooks/useNow';
import LiveWarning from '../../components/LiveWarning';
import { agoText } from '../../utils/helpers';
import { getBuses, getBusDetail } from '../../services/busService';
import { applySnapshot } from '../../utils/liveHelpers';
import { stopsForMap, lineFor, busForMap } from '../../utils/mapHelpers';
import Card from '../../components/Card';
import Badge from '../../components/Badge';
import Select from '../../components/Select';
import LiveBadge from '../../components/LiveBadge';
import EtaTag from '../../components/EtaTag';
import StopTimeline from '../../components/StopTimeline';
import MapComponent from '../../components/MapComponent';
import LoadingSkeleton from '../../components/LoadingSkeleton';
import EmptyState from '../../components/EmptyState';

export default function LiveTracking() {
  const { user } = useAuth();
  const [params, setParams] = useSearchParams();
  const buses = useAsync(getBuses, []);
  const { updates, status } = useBusLocation();
  const number = params.get('bus') || buses.data?.find((b) => b.status !== 'Offline')?.number || 'BUS-12';
  const stop = params.get('stop') || user.defaultStop;
  const detail = useAsync(() => getBusDetail(number, stop), [number, stop]);
  const snap = updates[number];
  const d = useMemo(() => detail.data && applySnapshot(detail.data, snap, stop), [detail.data, snap, stop]);
  const bus = d && busForMap(d);
  const now = useNow(1000);

  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-xl font-bold text-slate-900">Live tracking</h1>
        <LiveBadge status={status} />
      </div>
      <LiveWarning status={status} />
      <Select label="Bus" value={number} onChange={(e) => setParams({ bus: e.target.value, stop })}
        options={(buses.data || []).map((b) => ({ value: b.number, label: `${b.number} · ${b.routeName}${b.status === 'Offline' ? ' (not running)' : ''}` }))} />

      {detail.loading ? <LoadingSkeleton rows={3} /> : !d ? (
        <Card><EmptyState icon={Info} title="Bus not found" message="Pick a bus from the list above." /></Card>
      ) : (
        <>
          <MapComponent className="h-72 sm:h-96" label={`Map showing ${d.number} on ${d.routeName}`} stops={stopsForMap(d.stops)} lines={[lineFor(d.routeId, d.stops)]}
            buses={bus ? [bus] : []} highlight={stop} />
          {d.status === 'Offline' && (
            <div className="flex items-start gap-2 rounded-lg bg-slate-100 p-3 text-sm text-slate-700">
              <Info size={16} className="mt-0.5 shrink-0" aria-hidden />
              <p>{d.number} is not sending its location right now, so it is not shown on the map.</p>
            </div>
          )}
          <Card>
            <div className="flex items-center justify-between"><p className="font-bold text-slate-900">{d.number}</p><Badge>{d.status}</Badge></div>
            <dl className="mt-3 grid grid-cols-3 gap-3 text-sm">
              <div><dt className="text-slate-500">Now at</dt><dd className="font-semibold">{d.currentLocation}</dd></div>
              <div><dt className="text-slate-500">Next stop</dt><dd className="font-semibold">{d.nextStop}</dd></div>
              <div><dt className="text-slate-500">ETA to {stop}</dt><dd className="font-semibold">{d.eta !== undefined ? `${d.eta} min` : d.status === 'Offline' ? '—' : 'Passed'}{d.eta !== undefined && <EtaTag meta={d.etaMeta} km={d.distanceKm} />}</dd></div>
            </dl>
            <p className={`mt-3 text-xs ${d.updatedAt && now - d.updatedAt > 45000 ? 'text-amber-600' : 'text-slate-500'}`}>
              {d.updatedAt ? `Location updated ${agoText(now - d.updatedAt)}` : 'No location received yet'}{d.speedKmh != null && ` · ${Math.round(d.speedKmh)} km/h`}
            </p>
          </Card>
          <Card title={d.routeName}><StopTimeline stops={d.stops} currentIdx={d.currentIdx} highlight={stop} /></Card>
        </>
      )}
    </div>
  );
}
