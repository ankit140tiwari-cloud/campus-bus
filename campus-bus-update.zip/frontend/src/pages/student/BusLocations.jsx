import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { BusFront, SearchX } from 'lucide-react';
import useAsync from '../../hooks/useAsync';
import useNow from '../../hooks/useNow';
import useBusLocation from '../../hooks/useBusLocation';
import { getBuses } from '../../services/busService';
import { getCampus } from '../../services/campusService';
import { applySnapshot } from '../../utils/liveHelpers';
import { busForMap } from '../../utils/mapHelpers';
import { haversineKm } from '../../utils/geo';
import { matchesAll } from '../../utils/search';
import { agoText } from '../../utils/helpers';
import Badge from '../../components/Badge';
import Card from '../../components/Card';
import EmptyState from '../../components/EmptyState';
import ErrorNote from '../../components/ErrorNote';
import LiveBadge from '../../components/LiveBadge';
import LiveWarning from '../../components/LiveWarning';
import LoadingSkeleton from '../../components/LoadingSkeleton';
import MapComponent from '../../components/MapComponent';
import SearchBox from '../../components/SearchBox';

const STALE_MS = 45000;
const coord = (n) => n.toFixed(5);

export default function BusLocations() {
  const now = useNow(1000);
  const buses = useAsync(getBuses, []);
  const campus = useAsync(getCampus, []);
  const { updates, status } = useBusLocation();
  const [q, setQ] = useState('');
  const gate = campus.data?.gate;

  const fleet = useMemo(() => (buses.data || []).map((b) => applySnapshot(b, updates[b.number])), [buses.data, updates]);
  const rows = fleet.filter((b) => matchesAll([b.number, b.routeCode, b.routeName, b.plate, b.currentLocation, b.status], q));
  const age = (b) => (b.updatedAt ? now - b.updatedAt : null);
  const mapBuses = rows.map((b) => busForMap(b, { eta: b.etaToDest != null ? `${b.etaToDest} min to college` : undefined, updated: b.updatedAt ? agoText(age(b)) : 'no signal yet' })).filter(Boolean);

  return (
    <div className="w-full space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div><h1 className="text-xl font-bold text-slate-900">Bus locations</h1><p className="text-sm text-slate-500">Where every bus is right now, and how far it is from the college front gate.</p></div>
        <LiveBadge status={status} />
      </div>
      <LiveWarning status={status} />
      <SearchBox value={q} onChange={setQ} placeholder="Search bus, route or number plate" className="max-w-md" />

      {buses.error ? <ErrorNote message={buses.error} onRetry={buses.reload} /> : buses.loading ? <LoadingSkeleton rows={4} /> : (
        <div className="grid gap-4 lg:grid-cols-5 lg:items-start">
          <div className="lg:sticky lg:top-20 lg:col-span-3">
            <MapComponent className="h-80 sm:h-[28rem] lg:h-[calc(100vh-14rem)]" label="Map of bus locations and the college front gate" buses={mapBuses}
              stops={gate ? [{ name: gate.name, lat: gate.lat, lng: gate.lng, isCollege: true }] : []} />
            {!gate && <p className="mt-2 text-xs text-slate-500">The college front gate has not been set yet. The transport office can add it in Settings.</p>}
          </div>

          <div className="space-y-3 lg:col-span-2 lg:max-h-[calc(100vh-14rem)] lg:overflow-y-auto lg:pr-1">
            {rows.length ? rows.map((b) => {
              const a = age(b);
              const stale = b.status !== 'Offline' && a != null && a > STALE_MS;
              const km = gate && b.position ? haversineKm(b.position, gate) : null;
              return (
                <article key={b.number} className="rounded-xl border border-slate-200 bg-white p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div><p className="flex items-center gap-2 font-bold text-slate-900"><BusFront size={18} className="text-brand-600" aria-hidden />{b.number}</p><p className="text-sm text-slate-500">{b.routeCode} · {b.routeName}</p></div>
                    <Badge>{b.status}</Badge>
                  </div>
                  <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
                    <div className="col-span-2"><dt className="text-slate-500">Position</dt><dd className="font-mono text-xs font-semibold">{b.position ? `${coord(b.position.lat)}, ${coord(b.position.lng)}` : 'No position received yet'}</dd></div>
                    <div><dt className="text-slate-500">Status</dt><dd className="font-semibold">{b.currentLocation}</dd></div>
                    <div><dt className="text-slate-500">Next stop</dt><dd className="font-semibold">{b.nextStop}</dd></div>
                    <div><dt className="text-slate-500">From front gate</dt><dd className="font-semibold">{km != null ? `${km.toFixed(1)} km` : '—'}</dd></div>
                    <div><dt className="text-slate-500">ETA to college</dt><dd className="font-semibold">{b.etaToDest != null ? `${b.etaToDest} min` : '—'}</dd></div>
                    {b.speedKmh != null && <div><dt className="text-slate-500">Speed</dt><dd className="font-semibold">{Math.round(b.speedKmh)} km/h</dd></div>}
                    <div><dt className="text-slate-500">Last updated</dt><dd className={stale ? 'font-semibold text-amber-600' : 'font-semibold'}>{a == null ? 'No signal yet' : agoText(a)}{stale && ' · signal delayed'}</dd></div>
                  </dl>
                  {b.status !== 'Offline' && <Link to={`/student/live?bus=${b.number}`} className="mt-3 inline-block text-sm font-medium text-brand-600 hover:underline">Track on route</Link>}
                </article>
              );
            }) : <Card><EmptyState icon={q ? SearchX : BusFront} title={q ? `No buses match “${q.trim()}”` : 'No buses yet'} message={q ? 'Try a bus number, a route code like R-101, or a number plate.' : 'Buses added by the transport office appear here.'} /></Card>}
          </div>
        </div>
      )}
    </div>
  );
}
