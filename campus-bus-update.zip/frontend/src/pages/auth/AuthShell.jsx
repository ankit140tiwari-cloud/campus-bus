import { Link, Navigate, useLocation } from 'react-router-dom';
import { Bus, MapPin, Clock, ListChecks, ArrowLeft } from 'lucide-react';
import useAuth from '../../hooks/useAuth';
import { APP_NAME, APP_SUBTITLE, HOME_BY_ROLE } from '../../utils/constants';
import { LoginForm, SignupForm, ForgotForm, ResetForm, VerifyPanel } from '../../components/auth/AuthForms';
import { cx } from '../../utils/helpers';

const MODES = { '/': 'welcome', '/login': 'login', '/signup': 'signup', '/forgot-password': 'forgot', '/reset-password': 'reset', '/verify-email': 'verify' };
const FEATURES = [[Bus, 'Find your bus', 'See which bus serves your stop and when it leaves.'], [MapPin, 'Track it live', 'Watch the bus move on the map in real time.'], [Clock, 'Know your ETA', 'Arrival estimates, with delays and alerts.']];

// One component for the welcome page and every sign-in screen. It stays mounted while the URL changes, so the brand panel
// slides from full width to the left half (and the form slides in from the right) as a CSS transition, with no page reload.
export default function AuthShell() {
  const { pathname } = useLocation();
  const { user } = useAuth();
  const mode = MODES[pathname] || 'welcome';
  const welcome = mode === 'welcome';
  if (user && mode !== 'verify' && mode !== 'reset') return <Navigate to={HOME_BY_ROLE[user.role]} replace />;

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-slate-50 lg:flex lg:h-screen lg:overflow-hidden">
      {/* brand panel */}
      <section className={cx('relative z-10 flex w-full flex-col justify-center overflow-hidden bg-brand-900 px-6 text-white transition-all duration-700 ease-in-out sm:px-10',
        welcome ? 'min-h-screen py-10 lg:w-full' : 'min-h-0 py-6 lg:min-h-screen lg:w-1/2 lg:py-10')}>
        <svg className="pointer-events-none absolute inset-0 h-full w-full opacity-[0.07]" aria-hidden viewBox="0 0 400 400" preserveAspectRatio="xMidYMid slice">
          <path d="M-20 320 C 80 260, 120 340, 200 250 S 330 160, 430 90" fill="none" stroke="#fff" strokeWidth="3" strokeDasharray="10 8" />
          <path d="M-20 120 C 70 160, 150 60, 240 130 S 360 250, 430 210" fill="none" stroke="#fff" strokeWidth="3" strokeDasharray="10 8" />
          {[[60, 292], [200, 250], [320, 170], [150, 105], [290, 150]].map(([x, y]) => <circle key={`${x}${y}`} cx={x} cy={y} r="6" fill="#fff" />)}
        </svg>

        <div className={cx('relative mx-auto flex w-full flex-col transition-all duration-700 ease-in-out', welcome ? 'max-w-3xl items-center gap-6 text-center' : 'max-w-xl gap-4 lg:gap-6')}>
          <div className={cx('flex items-center gap-4 transition-all duration-700', welcome ? 'flex-col' : 'flex-row')}>
            <span className={cx('grid shrink-0 place-items-center rounded-2xl bg-brand-600 shadow-lg transition-all duration-700', welcome ? 'h-20 w-20' : 'h-12 w-12')}>
              <Bus className={cx('transition-all duration-700', welcome ? 'h-10 w-10' : 'h-6 w-6')} aria-hidden />
            </span>
            <div>
              <h1 className={cx('font-bold leading-tight transition-all duration-700', welcome ? 'text-4xl sm:text-6xl' : 'text-2xl lg:text-4xl')}>{APP_NAME}</h1>
              <p className={cx('text-indigo-200 transition-all duration-700', welcome ? 'mt-2 text-lg sm:text-xl' : 'text-sm lg:text-base')}>{APP_SUBTITLE}</p>
            </div>
          </div>

          <p className={cx('max-w-2xl text-indigo-100 transition-all duration-700', welcome ? 'max-h-64 text-base opacity-100 sm:text-lg' : 'max-h-0 overflow-hidden text-sm opacity-0 lg:max-h-48 lg:opacity-100')}>
            Campus Bus helps students identify the right bus, its route, stops, departure times, live location and ETA, while giving administrators one place to manage the whole college transport system.
          </p>

          <div className={cx('flex flex-wrap justify-center gap-3 overflow-hidden transition-all duration-500', welcome ? 'max-h-28 opacity-100' : 'pointer-events-none max-h-0 opacity-0')}>
            <Link to="/login" className="inline-flex min-h-[48px] items-center rounded-xl bg-white px-8 text-base font-semibold text-brand-900 hover:bg-indigo-50">Login</Link>
            <Link to="/signup" className="inline-flex min-h-[48px] items-center rounded-xl border border-white/60 px-8 text-base font-semibold text-white hover:bg-white/10">Sign Up</Link>
          </div>

          <ul className={cx('grid w-full gap-3 transition-all duration-700', welcome ? 'max-h-96 opacity-100 sm:grid-cols-3' : 'hidden max-h-0 opacity-0 lg:grid lg:max-h-96 lg:opacity-100')}>
            {FEATURES.map(([Icon, title, text]) => (
              <li key={title} className={cx('rounded-xl bg-white/10 p-4 backdrop-blur-sm', welcome ? 'text-left' : 'flex items-start gap-3 text-left')}>
                <Icon size={20} className="shrink-0 text-indigo-200" aria-hidden />
                <div><p className="mt-1 font-semibold">{title}</p><p className={cx('text-sm text-indigo-200', welcome && 'mt-1')}>{text}</p></div>
              </li>
            ))}
          </ul>
          <p className={cx('flex items-center gap-2 text-sm text-indigo-300 transition-opacity duration-700', welcome ? 'opacity-100' : 'hidden opacity-0')}><ListChecks size={16} aria-hidden /> Students sign up with their college email. Administrators are added by the transport office.</p>
        </div>
      </section>

      {/* form panel: slides in from the right */}
      <section aria-hidden={welcome} className={cx('flex items-center justify-center bg-white px-5 transition-all duration-700 ease-in-out lg:absolute lg:inset-y-0 lg:right-0 lg:w-1/2 lg:overflow-y-auto',
        welcome ? 'pointer-events-none max-h-0 overflow-hidden py-0 opacity-0 lg:max-h-none lg:translate-x-full' : 'max-h-[300vh] py-8 opacity-100 lg:translate-x-0')}>
        <div key={mode} className="cb-fade w-full max-w-md">
          <Link to="/" className="mb-6 inline-flex min-h-[44px] items-center gap-1 text-sm text-slate-500 hover:text-slate-800"><ArrowLeft size={16} aria-hidden /> Back to welcome</Link>
          {mode === 'login' && <LoginForm />}
          {mode === 'signup' && <SignupForm />}
          {mode === 'forgot' && <ForgotForm />}
          {mode === 'reset' && <ResetForm />}
          {mode === 'verify' && <VerifyPanel />}
        </div>
      </section>
    </div>
  );
}
