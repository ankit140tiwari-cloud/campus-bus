import { useMemo, useState } from 'react';
import { BusFront, SearchX } from 'lucide-react';
import useAsync from '../../hooks/useAsync';
import useNow from '../../hooks/useNow';
import useBusLocation from '../../hooks/useBusLocation';
import { getFleet } from '../../services/adminService';
import { applySnapshot } from '../../utils/liveHelpers';
import { busForMap, lineFor } from '../../utils/mapHelpers';
import { matchesAll } from '../../utils/search';
import { agoText, cx } from '../../utils/helpers';
import DataTable from '../../components/DataTable';
import Badge from '../../components/Badge';
import Modal from '../../components/Modal';
import Button from '../../components/Button';
import Card from '../../components/Card';
import LiveBadge from '../../components/LiveBadge';
import LiveWarning from '../../components/LiveWarning';
import MapComponent from '../../components/MapComponent';
import SearchBox from '../../components/SearchBox';
import EmptyState from '../../components/EmptyState';
import ErrorNote from '../../components/ErrorNote';
import LoadingSkeleton from '../../components/LoadingSkeleton';

const FILTERS = ['All', 'On Time', 'Delayed', 'Offline'];
const STALE_MS = 45000;

export default function LiveMonitoring() {
  const { data, loading, error, reload } = useAsync(getFleet, []);
  const { updates, status } = useBusLocation();
  const now = useNow(1000);
  const [filter, setFilter] = useState('All');
  const [q, setQ] = useState('');
  const [selNumber, setSelNumber] = useState(null);

  const fleet = useMemo(() => (data || []).map((b) => applySnapshot(b, updates[b.number])), [data, updates]);
  const bySearch = fleet.filter((b) => matchesAll([b.number, b.routeCode, b.routeName, b.plate, b.currentLocation, b.nextStop, b.status], q));
  const rows = bySearch.filter((b) => filter === 'All' || b.status === filter);
  const sel = fleet.find((b) => b.number === selNumber) || null;

  // every route line and stop stays on the map; search and filters only change which buses are shown
  const { lines, stops } = useMemo(() => {
    const byRoute = new Map(), byStop = new Map();
    (data || []).forEach((b) => {
      if (b.routeId && !byRoute.has(b.routeId)) byRoute.set(b.routeId, lineFor(b.routeId, b.routeStops));
      b.routeStops.forEach((s) => byStop.set(s.name, { name: s.name, lat: s.lat, lng: s.lng, isCollege: s.name === 'College' }));
    });
    return { lines: [...byRoute.values()], stops: [...byStop.values()] };
  }, [data]);

  const age = (b) => (b.updatedAt ? now - b.updatedAt : null);
  const updated = (b) => { const a = age(b); return a == null ? 'No signal' : agoText(a); };
  const mapBuses = rows.map((b) => busForMap(b, { eta: b.etaToDest != null ? `${b.etaToDest} min to destination` : undefined, updated: updated(b) })).filter(Boolean);

  const columns = [
    { key: 'number', label: 'Bus' },
    { key: 'route', label: 'Route', render: (b) => (b.routeCode ? `${b.routeCode} · ${b.routeName}` : b.routeName) },
    { key: 'plate', label: 'Number plate' },
    { key: 'currentLocation', label: 'Current location' },
    { key: 'nextStop', label: 'Next stop' },
    { key: 'status', label: 'Status', render: (b) => <Badge>{b.status}</Badge> },
    { key: 'speed', label: 'Speed', render: (b) => (b.speedKmh != null ? `${Math.round(b.speedKmh)} km/h` : '—') },
    { key: 'eta', label: 'ETA (destination)', render: (b) => (b.etaToDest != null ? `${b.etaToDest} min` : '—') },
    { key: 'updated', label: 'Last updated', render: (b) => { const a = age(b); return <span className={cx(b.status !== 'Offline' && a > STALE_MS && 'font-semibold text-amber-600')}>{updated(b)}</span>; } },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-xl font-bold text-slate-900">Live bus monitoring</h1>
        <LiveBadge status={status} />
      </div>
      <LiveWarning status={status} />

      <div className="flex flex-wrap items-center gap-3">
        <SearchBox value={q} onChange={setQ} placeholder="Search bus, route (R-101), number plate…" label="Search buses" className="w-full sm:max-w-md" />
        <div className="flex flex-wrap gap-2" role="group" aria-label="Filter by status">
          {FILTERS.map((f) => (
            <button key={f} onClick={() => setFilter(f)} aria-pressed={filter === f}
              className={cx('min-h-[44px] rounded-full px-4 text-sm font-medium', filter === f ? 'bg-brand-600 text-white' : 'border border-slate-300 bg-white text-slate-700 hover:bg-slate-50')}>
              {f}<span className="ml-1.5 opacity-70">{f === 'All' ? bySearch.length : bySearch.filter((b) => b.status === f).length}</span>
            </button>
          ))}
        </div>
      </div>

      {loading ? <LoadingSkeleton rows={4} /> : error ? <ErrorNote message={error} onRetry={reload} /> : (
        <>
          <MapComponent className="h-72 sm:h-[28rem]" label="Map of all buses" stops={stops} lines={lines} buses={mapBuses} onBusSelect={setSelNumber} />
          <p className="text-sm text-slate-500">{mapBuses.length} of {rows.length} buses on the map. A bus with no running trip or no recent GPS fix shows Offline at its last known position. Select a marker or a row for details.</p>
          {rows.length ? <DataTable columns={columns} rows={rows} rowKey="number" onRowClick={(b) => setSelNumber(b.number)} />
            : <Card><EmptyState icon={q.trim() ? SearchX : BusFront} title={q.trim() ? `No buses match “${q.trim()}”` : `No ${filter.toLowerCase()} buses`} message={q.trim() ? 'Try a bus number, a route code like R-101, or a number plate.' : 'Choose another filter to see the rest of the fleet.'} /></Card>}
        </>
      )}

      <Modal open={!!sel} onClose={() => setSelNumber(null)} title={sel ? `${sel.number} details` : ''} footer={<Button variant="secondary" onClick={() => setSelNumber(null)}>Close</Button>}>
        {sel && (
          <dl className="grid grid-cols-2 gap-4 text-sm">
            {[['Route', sel.routeCode ? `${sel.routeCode} · ${sel.routeName}` : sel.routeName], ['Number plate', sel.plate || '—'], ['Status', <Badge key="s">{sel.status}</Badge>], ['Delay', sel.delay ? `${sel.delay} min` : 'None'],
              ['Current location', sel.currentLocation], ['Next stop', sel.nextStop], ['Speed', sel.speedKmh != null ? `${Math.round(sel.speedKmh)} km/h` : '—'], ['ETA (destination)', sel.etaToDest != null ? `${sel.etaToDest} min` : '—'],
              ['Position', sel.position ? `${sel.position.lat.toFixed(5)}, ${sel.position.lng.toFixed(5)}` : 'None yet'], ['Last updated', updated(sel)]].map(([l, v]) => (
              <div key={l}><dt className="text-slate-500">{l}</dt><dd className="font-semibold text-slate-900">{v}</dd></div>
            ))}
          </dl>
        )}
      </Modal>
    </div>
  );
}
