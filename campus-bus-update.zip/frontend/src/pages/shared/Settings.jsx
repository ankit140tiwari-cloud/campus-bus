import { useSearchParams, useNavigate } from 'react-router-dom';
import { User, Palette, KeyRound, Landmark, Info, LogOut } from 'lucide-react';
import useAuth from '../../hooks/useAuth';
import ProfileForm from '../../components/account/ProfileForm';
import ThemePicker from '../../components/account/ThemePicker';
import SecurityPanel from '../../components/account/SecurityPanel';
import AboutCard from '../../components/account/AboutCard';
import CampusForm from '../../components/account/CampusForm';
import Card from '../../components/Card';
import Button from '../../components/Button';
import { cx } from '../../utils/helpers';

const TABS = [['profile', 'Profile', User], ['appearance', 'Theme', Palette], ['security', 'Password & Security', KeyRound], ['campus', 'Campus', Landmark, true], ['about', 'About', Info]];

// The same page for students and admins; the admin gets the extra Campus tab.
export default function Settings() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const tabs = TABS.filter(([, , , adminOnly]) => !adminOnly || user.role === 'admin');
  const tab = tabs.some(([k]) => k === params.get('tab')) ? params.get('tab') : 'profile';

  return (
    <div className="mx-auto w-full max-w-5xl space-y-4">
      <h1 className="text-xl font-bold text-slate-900">Settings</h1>
      <div className="grid gap-4 md:grid-cols-[14rem_1fr]">
        <nav aria-label="Settings sections" role="tablist" className="flex gap-1 overflow-x-auto md:flex-col md:overflow-visible">
          {tabs.map(([k, label, Icon]) => (
            <button key={k} role="tab" aria-selected={tab === k} onClick={() => setParams({ tab: k })}
              className={cx('flex min-h-[44px] shrink-0 items-center gap-2 rounded-lg px-3 text-sm font-medium', tab === k ? 'bg-brand-50 text-brand-700' : 'text-slate-600 hover:bg-slate-100')}>
              <Icon size={16} aria-hidden />{label}
            </button>
          ))}
        </nav>
        <div role="tabpanel" className="min-w-0 space-y-4">
          {tab === 'profile' && <ProfileForm />}
          {tab === 'appearance' && <ThemePicker />}
          {tab === 'security' && <SecurityPanel />}
          {tab === 'campus' && <CampusForm />}
          {tab === 'about' && <AboutCard />}
          <Card title="Sign out">
            <p className="mb-3 text-sm text-slate-500">Signing out clears this device's session and returns you to the welcome page.</p>
            <Button variant="danger" onClick={() => { logout(); navigate('/'); }}><LogOut size={16} aria-hidden /> Sign out</Button>
          </Card>
        </div>
      </div>
    </div>
  );
}
