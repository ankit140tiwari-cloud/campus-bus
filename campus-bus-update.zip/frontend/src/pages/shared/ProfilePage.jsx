import { Link } from 'react-router-dom';
import useAuth from '../../hooks/useAuth';
import ProfileForm from '../../components/account/ProfileForm';
import PasswordForm from '../../components/account/PasswordForm';

export default function ProfilePage() {
  const { user } = useAuth();
  return (
    <div className="mx-auto w-full max-w-3xl space-y-4">
      <div className="flex items-end justify-between gap-3">
        <h1 className="text-xl font-bold text-slate-900">Profile</h1>
        <Link to={`/${user.role}/settings`} className="text-sm font-medium text-brand-600 hover:underline">More in Settings</Link>
      </div>
      <ProfileForm />
      <PasswordForm />
    </div>
  );
}
