import { Routes, Route, Navigate } from 'react-router-dom';
import useAuth from './hooks/useAuth';
import AuthShell from './pages/auth/AuthShell';
import StudentLayout from './layouts/StudentLayout';
import AdminLayout from './layouts/AdminLayout';
import StudentDashboard from './pages/student/Dashboard';
import FindBus from './pages/student/FindBus';
import LiveTracking from './pages/student/LiveTracking';
import BusLocations from './pages/student/BusLocations';
import StudentRoutes from './pages/student/Routes';
import Schedule from './pages/student/Schedule';
import Notifications from './pages/student/Notifications';
import ReportIssue from './pages/student/ReportIssue';
import ProfilePage from './pages/shared/ProfilePage';
import Settings from './pages/shared/Settings';
import AdminDashboard from './pages/admin/Dashboard';
import LiveMonitoring from './pages/admin/LiveMonitoring';
import Buses from './pages/admin/Buses';
import AdminRoutes from './pages/admin/Routes';
import Stops from './pages/admin/Stops';
import Schedules from './pages/admin/Schedules';
import TripControl from './pages/admin/TripControl';
import AdminNotifications from './pages/admin/Notifications';
import Complaints from './pages/admin/Complaints';
import Students from './pages/admin/Students';
import Analytics from './pages/admin/Analytics';
import { HOME_BY_ROLE } from './utils/constants';

// The server checks the role on every request; this only keeps people out of screens that are not theirs.
function RequireRole({ role, children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (user.role !== role) return <Navigate to={HOME_BY_ROLE[user.role]} replace />;
  return children;
}

export default function App() {
  const { user } = useAuth();
  return (
    <Routes>
      {/* welcome, login, sign-up, password reset and email confirmation share one animated shell */}
      <Route element={<AuthShell />}>
        {['/', '/login', '/signup', '/forgot-password', '/reset-password', '/verify-email'].map((p) => <Route key={p} path={p} element={null} />)}
      </Route>

      <Route path="/student" element={<RequireRole role="student"><StudentLayout /></RequireRole>}>
        <Route index element={<StudentDashboard />} />
        <Route path="find-bus" element={<FindBus />} />
        <Route path="live" element={<LiveTracking />} />
        <Route path="bus-locations" element={<BusLocations />} />
        <Route path="routes" element={<StudentRoutes />} />
        <Route path="schedule" element={<Schedule />} />
        <Route path="notifications" element={<Notifications />} />
        <Route path="report" element={<ReportIssue />} />
        <Route path="profile" element={<ProfilePage />} />
        <Route path="settings" element={<Settings />} />
      </Route>

      <Route path="/admin" element={<RequireRole role="admin"><AdminLayout /></RequireRole>}>
        <Route index element={<AdminDashboard />} />
        <Route path="live" element={<LiveMonitoring />} />
        <Route path="buses" element={<Buses />} />
        <Route path="routes" element={<AdminRoutes />} />
        <Route path="stops" element={<Stops />} />
        <Route path="schedules" element={<Schedules />} />
        <Route path="students" element={<Students />} />
        <Route path="notifications" element={<AdminNotifications />} />
        <Route path="complaints" element={<Complaints />} />
        <Route path="analytics" element={<Analytics />} />
        <Route path="trip-control" element={<TripControl />} />
        <Route path="profile" element={<ProfilePage />} />
        <Route path="settings" element={<Settings />} />
      </Route>

      <Route path="*" element={<Navigate to={user ? HOME_BY_ROLE[user.role] : '/'} replace />} />
    </Routes>
  );
}
