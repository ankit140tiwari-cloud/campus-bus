// Case-insensitive search that ignores spaces and hyphens, so "r101", "R-101" and "r 101" all find route R-101,
// and "mp04ab1234" finds the plate "MP04 AB 1234".
export const norm = (s) => String(s ?? '').toLowerCase().replace(/[\s\-_.]+/g, '');

export const tokens = (q) => String(q ?? '').toLowerCase().split(/\s+/).map((t) => t.replace(/[-_.]/g, '')).filter(Boolean);

// every word typed must appear somewhere in the haystack
export function matchesAll(haystackParts, query) {
  const t = tokens(query);
  if (!t.length) return true;
  const hay = norm(haystackParts.join(' '));
  return t.every((x) => hay.includes(x));
}

// Rank menu entries: label starts with the text > label contains it > a keyword contains it.
export function searchItems(items, query) {
  const q = norm(query);
  if (!q) return [];
  return items
    .map((it) => {
      const label = norm(it.label);
      const score = label.startsWith(q) ? 0 : label.includes(q) ? 1 : (it.keywords || []).some((k) => norm(k).includes(q)) ? 2 : 9;
      return { it, score };
    })
    .filter((x) => x.score < 9)
    .sort((a, b) => a.score - b.score)
    .map((x) => x.it);
}
