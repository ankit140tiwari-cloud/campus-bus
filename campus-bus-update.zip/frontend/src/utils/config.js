// The backend and database are the source of truth. Sample data is opt-in: set VITE_USE_MOCK=true for a quick look without a backend.
export const USE_MOCK = import.meta.env.VITE_USE_MOCK === 'true';
