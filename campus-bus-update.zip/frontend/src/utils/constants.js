export const APP_NAME = 'Campus Bus';
export const APP_SUBTITLE = 'Identification and Management System';
export const APP_VERSION = '1.0.0';
export const ROLES = { STUDENT: 'student', ADMIN: 'admin' };
export const HOME_BY_ROLE = { student: '/student', admin: '/admin' };
export const STORAGE_KEY = 'campus_bus_auth';

// `keywords` feed the global search; `icon` is a lucide-react icon name.
export const STUDENT_NAV = [
  { to: '/student', label: 'Dashboard', icon: 'LayoutDashboard', end: true, keywords: ['home', 'overview', 'next bus'] },
  { to: '/student/find-bus', label: 'Find Bus', icon: 'Search', keywords: ['which bus', 'search bus', 'eta'] },
  { to: '/student/live', label: 'Live Tracking', icon: 'MapPin', keywords: ['track', 'map', 'where is my bus'] },
  { to: '/student/bus-locations', label: 'Bus Locations', icon: 'LocateFixed', keywords: ['standing', 'current location', 'gate', 'college', 'gps', 'real time'] },
  { to: '/student/routes', label: 'Routes & Stops', icon: 'Route', keywords: ['routes', 'stops', 'stop list'] },
  { to: '/student/schedule', label: 'Schedule', icon: 'CalendarClock', keywords: ['timetable', 'timings', 'departure'] },
  { to: '/student/notifications', label: 'Notifications', icon: 'Bell', keywords: ['alerts', 'announcements', 'messages'] },
  { to: '/student/report', label: 'Report Issue', icon: 'MessageSquareWarning', keywords: ['complaint', 'problem', 'feedback'] },
  { to: '/student/profile', label: 'Profile', icon: 'User', keywords: ['account', 'name', 'phone', 'email', 'default stop'] },
  { to: '/student/settings', label: 'Settings', icon: 'Settings', keywords: ['preferences', 'options'] },
];

export const ADMIN_NAV = [
  { to: '/admin', label: 'Dashboard', icon: 'LayoutDashboard', end: true, keywords: ['home', 'overview', 'kpi'] },
  { to: '/admin/live', label: 'Live Monitoring', icon: 'Radar', keywords: ['map', 'buses live', 'gps', 'track'] },
  { to: '/admin/buses', label: 'Buses', icon: 'Bus', keywords: ['fleet', 'number plate', 'registration', 'vehicles'] },
  { to: '/admin/routes', label: 'Routes', icon: 'Route', keywords: ['route code', 'add route'] },
  { to: '/admin/stops', label: 'Stops', icon: 'MapPin', keywords: ['latitude', 'longitude', 'add stop'] },
  { to: '/admin/schedules', label: 'Schedules', icon: 'CalendarClock', keywords: ['timetable', 'timings'] },
  { to: '/admin/students', label: 'Students', icon: 'Users', keywords: ['accounts', 'activate', 'deactivate'] },
  { to: '/admin/notifications', label: 'Notifications', icon: 'Megaphone', keywords: ['announcement', 'send', 'broadcast'] },
  { to: '/admin/complaints', label: 'Complaints', icon: 'MessageSquareWarning', keywords: ['issues', 'reports'] },
  { to: '/admin/analytics', label: 'Analytics', icon: 'BarChart3', keywords: ['charts', 'statistics', 'delay', 'eta model'] },
  { to: '/admin/trip-control', label: 'Trip Control', icon: 'Navigation', keywords: ['gps test', 'simulate', 'start trip'] },
  { to: '/admin/profile', label: 'Profile', icon: 'User', keywords: ['account', 'name', 'email'] },
  { to: '/admin/settings', label: 'Settings', icon: 'Settings', keywords: ['preferences', 'options'] },
];

// Things inside pages that people look for by name; they open the right settings tab.
export const SEARCH_EXTRAS = {
  student: [
    { to: '/student/settings?tab=appearance', label: 'Theme (light / dark)', icon: 'Palette', keywords: ['dark mode', 'appearance', 'light mode'] },
    { to: '/student/settings?tab=security', label: 'Change password', icon: 'KeyRound', keywords: ['password', 'security', 'sessions'] },
    { to: '/student/settings?tab=about', label: 'About Campus Bus', icon: 'Info', keywords: ['version', 'help'] },
    { action: 'logout', label: 'Sign out', icon: 'LogOut', keywords: ['logout', 'log out', 'exit'] },
  ],
  admin: [
    { to: '/admin/settings?tab=appearance', label: 'Theme (light / dark)', icon: 'Palette', keywords: ['dark mode', 'appearance', 'light mode'] },
    { to: '/admin/settings?tab=security', label: 'Change password', icon: 'KeyRound', keywords: ['password', 'security', 'sessions'] },
    { to: '/admin/settings?tab=campus', label: 'College & front gate location', icon: 'Landmark', keywords: ['campus', 'gate', 'college location'] },
    { to: '/admin/settings?tab=about', label: 'About Campus Bus', icon: 'Info', keywords: ['version', 'help'] },
    { action: 'logout', label: 'Sign out', icon: 'LogOut', keywords: ['logout', 'log out', 'exit'] },
  ],
};
