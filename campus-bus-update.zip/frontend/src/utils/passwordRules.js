// Same rules as the server (backend/app/validation.py), so people hear about a weak password before they submit.
export const passwordChecks = (p = '') => [
  { ok: p.length >= 8, label: 'At least 8 characters' },
  { ok: /[A-Za-z]/.test(p), label: 'A letter' },
  { ok: /\d/.test(p), label: 'A number' },
];

export function passwordProblem(p = '') {
  if (p.length < 8) return 'Password must be at least 8 characters.';
  if (!/[A-Za-z]/.test(p) || !/\d/.test(p)) return 'Password must contain at least one letter and one number.';
  return '';
}
