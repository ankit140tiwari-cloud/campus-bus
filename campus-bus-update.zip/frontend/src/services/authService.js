import { STORAGE_KEY } from '../utils/constants';
import { USE_MOCK } from '../utils/config';
import { api } from './api';

// Mock mode only (VITE_USE_MOCK=true): throwaway accounts so the UI can be explored without a backend. Nothing is saved.
const DEMO_USERS = [
  { identifier: 'student@college.edu', studentId: 'CS2021045', password: 'student123', user: { id: 1, name: 'Aarav Sharma', role: 'student', studentId: 'CS2021045', email: 'student@college.edu', department: 'Computer Science', phone: '', defaultStop: 'MP Nagar', theme: 'system', emailVerified: true } },
  { identifier: 'admin@college.edu', studentId: null, password: 'admin123', user: { id: 2, name: 'Transport Office', role: 'admin', email: 'admin@college.edu', phone: '', theme: 'system', emailVerified: true } },
];
const pause = (ms = 500) => new Promise((r) => setTimeout(r, ms));

export const mapUser = (u) => ({
  id: u.id, name: u.name, email: u.email, role: u.role, studentId: u.student_id, department: u.department || '', phone: u.phone || '', defaultStop: u.default_stop,
  prefs: u.notification_prefs, theme: u.theme || 'system', emailVerified: !!u.email_verified, lastLoginAt: u.last_login_at,
});

const storageFor = () => (localStorage.getItem(STORAGE_KEY) ? localStorage : sessionStorage);

export async function login({ identifier, password, remember }) {
  let result;
  if (USE_MOCK) {
    await pause(600);
    const id = identifier.trim().toLowerCase();
    const match = DEMO_USERS.find((u) => (u.identifier === id || u.studentId?.toLowerCase() === id) && u.password === password);
    if (!match) throw new Error('Email / Student ID or password is incorrect.');
    result = { token: 'demo-token', user: match.user };
  } else {
    const r = await api('/auth/login', { method: 'POST', body: { identifier, password, remember: !!remember } });
    result = { token: r.token, user: mapUser(r.user) };
  }
  localStorage.removeItem(STORAGE_KEY);
  sessionStorage.removeItem(STORAGE_KEY);
  (remember ? localStorage : sessionStorage).setItem(STORAGE_KEY, JSON.stringify(result));
  return result;
}

export function logout() {
  localStorage.removeItem(STORAGE_KEY);
  sessionStorage.removeItem(STORAGE_KEY);
}

// The database is the source of truth: the signed-in user is re-read from it at start-up and after every save.
export const fetchMe = async () => (USE_MOCK ? null : mapUser(await api('/auth/me')));

export async function updateProfile(patch) {
  if (USE_MOCK) { await pause(300); const { currentPassword, ...rest } = patch; return rest; }  // never keep a password in the stored user
  const body = {};
  if ('name' in patch) body.name = patch.name;
  if ('department' in patch) body.department = patch.department;
  if ('phone' in patch) body.phone = patch.phone;
  if ('email' in patch) body.email = patch.email;
  if ('currentPassword' in patch) body.current_password = patch.currentPassword;
  if ('defaultStop' in patch && patch.defaultStop) body.default_stop_name = patch.defaultStop;
  if ('prefs' in patch) body.notification_prefs = patch.prefs;
  if ('theme' in patch) body.theme = patch.theme;
  return mapUser(await api('/auth/me', { method: 'PUT', body }));
}

export async function register({ name, email, studentId, department, password }) {
  if (USE_MOCK) { await pause(600); return { message: 'Account created.', verification_required: false, email_configured: false }; }
  return api('/auth/register', { method: 'POST', body: { name, email, student_id: studentId, department: department || null, password } });
}

export async function changePassword({ current, next }) {
  if (USE_MOCK) { await pause(400); if (current !== 'student123' && current !== 'admin123') throw new Error('Current password is incorrect.'); return null; }
  return (await api('/auth/change-password', { method: 'POST', body: { current_password: current, new_password: next } })).token;
}

// Keeps this device signed in after a password change (the server signs every other device out).
export function replaceToken(token) {
  const store = storageFor();
  const auth = JSON.parse(store.getItem(STORAGE_KEY) || 'null');
  if (auth && token) store.setItem(STORAGE_KEY, JSON.stringify({ ...auth, token }));
}

export const forgotPassword = (email) => (USE_MOCK ? pause().then(() => ({})) : api('/auth/forgot-password', { method: 'POST', body: { email } }));
export const resetPassword = (token, newPassword) => (USE_MOCK ? pause() : api('/auth/reset-password', { method: 'POST', body: { token, new_password: newPassword } }));
export const verifyEmail = (token) => (USE_MOCK ? pause() : api('/auth/verify-email', { method: 'POST', body: { token } }));
export const resendVerification = () => (USE_MOCK ? pause() : api('/auth/resend-verification', { method: 'POST' }));
export const logoutAllDevices = () => (USE_MOCK ? pause() : api('/auth/logout-all', { method: 'POST' }));
