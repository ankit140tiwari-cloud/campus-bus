import { USE_MOCK } from '../utils/config';
import { api } from './api';
import { STOP_COORDS, delay } from './mockData';

const place = (p) => (p ? { name: p.name, lat: p.latitude, lng: p.longitude } : null);

// The college and its front gate: stored in the database, edited in Admin > Settings > Campus.
export async function getCampus() {
  if (USE_MOCK) {
    const [lat, lng] = STOP_COORDS.College;
    return delay({ college: { name: 'College', lat, lng }, gate: { name: 'College front gate', lat: lat + 0.0006, lng: lng - 0.0004 } }, 150);
  }
  const c = await api('/campus');
  return { college: place(c.college), gate: place(c.gate) };
}

export async function saveCampus({ college, gate }) {
  const body = (p) => ({ name: p.name, latitude: Number(p.lat), longitude: Number(p.lng) });
  if (USE_MOCK) return delay({ college, gate });
  const c = await api('/campus', { method: 'PUT', body: { college: body(college), gate: body(gate) } });
  return { college: place(c.college), gate: place(c.gate) };
}
