import { api } from './api';
import { toMin, addMin } from '../utils/helpers';
import { applySnapshot } from '../utils/liveHelpers';

const hhmm = (t) => (t || '').slice(0, 5);

export async function loadAll() {
  const [buses, routes, live, last] = await Promise.all([api('/buses'), api('/routes'), api('/tracking/live'), api('/tracking/last-known')]);
  return { lastBy: Object.fromEntries(last.map((l) => [l.bus_id, l])), buses, routeBy: Object.fromEntries(routes.map((r) => [r.id, r])), liveBy: Object.fromEntries(live.map((l) => [l.bus_id, l])) };
}

// Same output shape as busService.describeBus, built from API data plus an optional live snapshot.
export function describeLive(bus, route, snap, stopName, last) {
  const stops = route ? route.stops.map((s) => ({ name: s.stop_name, time: hhmm(s.expected_time), lat: s.latitude, lng: s.longitude })) : [];
  const base = {
    id: bus.id, number: bus.bus_number, routeId: route ? route.route_code : '', routeName: route?.route_name || 'Unassigned',
    status: 'Offline', delay: 0, currentLocation: 'Not running', nextStop: '—', currentIdx: -1,
    plate: bus.registration_number, routeCode: route?.route_code || '', speedKmh: null,
    // where an idle bus was last seen (from the database), so it never just disappears from the map
    position: last ? { lat: last.latitude, lng: last.longitude } : null, updatedAt: last ? Date.parse(last.timestamp) : null,
    routeStops: stops.map(({ name, lat, lng }) => ({ name, lat, lng })), stops,
  };
  return applySnapshot(base, snap, stopName);
}

const describeAll = async (stopName) => {
  const { buses, routeBy, liveBy, lastBy } = await loadAll();
  return buses.map((b) => describeLive(b, routeBy[b.route_id], liveBy[b.id], stopName, lastBy[b.id]));
};

export const getBuses = () => describeAll();

export async function getBusDetail(number, stopName) {
  const d = (await describeAll(stopName)).find((b) => b.number === number);
  if (!d) return null;
  return { ...d, stops: d.stops.map((s) => ({ ...s, time: addMin(s.time, d.delay) })) };
}

export async function getNextBus(stopName) {
  const list = (await describeAll(stopName)).filter((b) => b.status !== 'Offline' && b.eta !== undefined);
  return list.sort((a, b) => a.eta - b.eta)[0] || null;
}

export async function searchBuses({ from, to, time }) {
  const list = await describeAll(from);
  return list
    .filter((b) => {
      const names = b.stops.map((s) => s.name);
      const i = names.indexOf(from), j = names.indexOf(to);
      if (b.status === 'Offline' || i < 0 || j < 0 || i >= j || b.eta === undefined) return false;
      return !time || toMin(addMin(b.stops[i].time, b.delay)) >= toMin(time);
    })
    .map((b) => ({ ...b, routeName: `${from} → ${to}`, destination: to }))
    .sort((a, b) => a.eta - b.eta);
}
