import { createContext, useState, useCallback, useEffect } from 'react';
import * as authService from '../services/authService';
import { getStoredAuth } from '../services/api';
import { STORAGE_KEY } from '../utils/constants';

export const AuthContext = createContext(null);

const persist = (auth) => {
  const store = localStorage.getItem(STORAGE_KEY) ? localStorage : sessionStorage;
  store.setItem(STORAGE_KEY, JSON.stringify(auth));
};

export function AuthProvider({ children }) {
  const [auth, setAuth] = useState(() => getStoredAuth());

  const login = useCallback(async (creds) => {
    const result = await authService.login(creds);
    setAuth(result);
    return result.user;
  }, []);

  const logout = useCallback(() => { authService.logout(); setAuth(null); }, []);

  // merge new fields into the signed-in user and keep the stored copy in step
  const updateUser = useCallback((patch) => {
    setAuth((a) => {
      if (!a) return a;
      const next = { ...a, user: { ...a.user, ...patch } };
      persist(next);
      return next;
    });
  }, []);

  const setToken = useCallback((token) => {
    authService.replaceToken(token);
    setAuth((a) => (a ? { ...a, token } : a));
  }, []);

  // On every page load, replace the stored copy of the user with the database's version (name, theme, verification...).
  const token = auth?.token;
  useEffect(() => {
    if (!token) return;
    authService.fetchMe().then((u) => { if (u) updateUser(u); }).catch(() => {});
  }, [token, updateUser]);

  return (
    <AuthContext.Provider value={{ user: auth?.user ?? null, token: auth?.token ?? null, login, logout, updateUser, setToken }}>
      {children}
    </AuthContext.Provider>
  );
}
