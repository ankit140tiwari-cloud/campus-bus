import { createContext, useCallback, useContext, useEffect, useState } from 'react';
import useAuth from '../hooks/useAuth';
import { updateProfile } from '../services/authService';
import { USE_MOCK } from '../utils/config';

const KEY = 'campus_bus_theme';
const ThemeContext = createContext({ mode: 'system', setMode: () => {} });
export const useTheme = () => useContext(ThemeContext);

const apply = (mode) => {
  const dark = mode === 'dark' || (mode === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.classList.toggle('dark', dark);
};

export function ThemeProvider({ children }) {
  const { user, updateUser } = useAuth();
  const [mode, setModeState] = useState(() => localStorage.getItem(KEY) || 'system');

  // the choice saved in the database (follows the account to any device) wins once the user is known
  useEffect(() => {
    if (user?.theme && user.theme !== mode) { setModeState(user.theme); localStorage.setItem(KEY, user.theme); }
  }, [user?.theme]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    apply(mode);
    if (mode !== 'system') return undefined;
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const on = () => apply('system');
    mq.addEventListener('change', on);
    return () => mq.removeEventListener('change', on);
  }, [mode]);

  const setMode = useCallback(async (m) => {
    setModeState(m);
    localStorage.setItem(KEY, m);
    if (!user) return;
    updateUser({ theme: m });
    if (!USE_MOCK) await updateProfile({ theme: m });  // saved to the account; a failure still leaves the choice applied on this device
  }, [user, updateUser]);

  return <ThemeContext.Provider value={{ mode, setMode }}>{children}</ThemeContext.Provider>;
}
