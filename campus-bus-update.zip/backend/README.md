# Campus Bus API (FastAPI + PostgreSQL)

    docker compose up -d db            # from the project root
    cd backend
    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    cp .env.example .env               # then set SECRET_KEY
    python -m app.seed                 # demo data (add --reset to wipe)
    uvicorn app.main:app --reload      # http://localhost:8000/docs

Demo logins: admin@college.edu / admin123, student@college.edu / student123 (dev seed only).

## Live tracking (Phase 7)
- Admin starts a trip (`POST /api/trips/start`), then streams GPS to `ws://localhost:8000/ws/bus/{bus_id}`.
- Everyone signed in can watch: `ws://localhost:8000/ws/fleet` (all buses) or `/ws/bus/{id}` (one bus).
- The first WebSocket message must be `{"type":"auth","token":"<JWT>"}`; the token is never put in the URL.
- Messages: send `{"type":"location","latitude":..,"longitude":..,"timestamp":<ms>}`; receive `bus_update`, `snapshot`, `trip_ended`.
- `GET /api/buses/{id}/location`, `GET /api/tracking/live`, `GET /api/trips/active`, `POST /api/trips/{id}/end`.
- Status rules: Offline = no fix for 120 s; Delayed = 5+ min behind the schedule at the last stop reached. All tunable in `.env`.
- ETA is schedule-based with the current delay carried forward until the Phase 10 ML model replaces it.
- Current state lives in process memory, so run ONE worker. Several workers need Redis pub/sub (Phase 11 deployment).
- Tests for the delay/stop logic: `python tests/test_tracking_core.py`.

## Notifications and complaints (Phase 8)
- `GET /api/notifications`, `POST /api/notifications/{id}/read`, `POST /api/notifications/read-all`, `POST|DELETE /api/notifications/device-token`
- Admin: `POST /api/notifications`, `GET /api/notifications/admin`
- `POST /api/complaints` (multipart, students), `GET /api/complaints`, `PUT /api/complaints/{id}` (admin), `GET /api/complaints/{id}/image`
- Push needs `FIREBASE_CREDENTIALS`; without it push is skipped silently.
- Existing dev databases need `python -m app.seed --reset` (new columns, no migrations yet).
- Tests: `python tests/test_notify_core.py`

## Analytics (Phase 9)
- `GET /api/analytics/dashboard?range=today|7d|30d` (all charts), `/api/analytics/routes`, `/api/analytics/delays`, `/api/analytics/overview` (KPI counts). Admin only.
- `python -m app.seed --reset --demo-history` fills 30 days of synthetic trips, stop visits and complaints for development.
- Tests: `python tests/test_analytics_core.py`

## ETA model (Phase 10)
- `python -m app.ml.train` trains from recorded stop visits and saves `models/eta_model.joblib` plus `eta_model.json` (metrics and the reason it was or was not promoted).
- `GET /api/ml/status`, `POST /api/ml/train` (admin), `GET /api/buses/{id}/eta?stop_id=`.
- Snapshots (`/api/tracking/live`, WebSocket) include `etas` and `eta_meta` = `{source: "model"|"schedule", is_demo, model_version, per_stop: {stop: {distance_km, confidence}}}`.
- Tests: `python tests/test_eta_core.py` (needs numpy, pandas, scikit-learn, joblib).

## Accounts and security (update)
- `python -m app.create_admin --email ... --name ...` creates or promotes an admin (password prompted, never a CLI argument).
- `/api/auth/*`: register, login, me (GET/PUT), change-password (returns a fresh token), forgot-password, reset-password, verify-email, resend-verification, logout-all.
- `/api/campus` (GET any user, PUT admin): college and front gate. `/api/tracking/last-known`: last saved position per bus.
- Sessions carry a `tv` (token version). Changing or resetting a password, or "sign out everywhere", bumps it and revokes every older token, including WebSocket sessions.
- Tests: `python tests/test_auth_core.py`
