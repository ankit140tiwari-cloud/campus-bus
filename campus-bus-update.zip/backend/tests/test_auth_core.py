import os
import sys
import types

try:
    import dotenv  # noqa: F401
except ImportError:
    sys.modules["dotenv"] = types.SimpleNamespace(load_dotenv=lambda *a, **k: None)
try:
    import bcrypt  # noqa: F401
except ImportError:  # sandbox without bcrypt: the token tests below do not touch password hashing
    sys.modules["bcrypt"] = types.SimpleNamespace(hashpw=lambda p, s: b"x", gensalt=lambda: b"s", checkpw=lambda p, h: True)
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import jwt  # noqa: E402
from app import ratelimit  # noqa: E402
from app.validation import check_password, check_phone, email_domain_allowed  # noqa: E402


def raises(fn, *a):
    try:
        fn(*a)
    except ValueError as e:
        return str(e)
    return None


def test_password_rules():
    assert check_password("student123") == "student123"
    assert "8 characters" in raises(check_password, "ab1")
    assert "letter and one number" in raises(check_password, "onlyletters")
    assert "letter and one number" in raises(check_password, "12345678")
    assert "too common" in raises(check_password, "Password123")
    assert "too long" in raises(check_password, "a1" * 40)


def test_phone_rules():
    assert check_phone("") == "" and check_phone(" +91 98765 43210 ") == "+91 98765 43210" and check_phone("9876543210") == "9876543210"
    assert raises(check_phone, "12ab") and raises(check_phone, "123") and raises(check_phone, "+" + "9" * 20)


def test_email_domains():
    assert email_domain_allowed("a@college.edu", []) and email_domain_allowed("a@College.edu", ["college.edu"])
    assert not email_domain_allowed("a@gmail.com", ["college.edu"]) and not email_domain_allowed("a@evil-college.edu", ["college.edu"])


def test_rate_limit_window():
    ratelimit.reset_all()
    assert all(ratelimit.allow("k", 3, 60, now=t) for t in (0, 1, 2))
    assert not ratelimit.allow("k", 3, 60, now=3)           # fourth attempt inside the window is refused
    assert ratelimit.allow("other", 3, 60, now=3)           # other keys are independent
    assert ratelimit.allow("k", 3, 60, now=62)              # the window slides: attempts at t=0.. have expired
    ratelimit.clear("k"); assert ratelimit.allow("k", 1, 60, now=63)


def test_one_time_tokens_and_session_versions():
    from app.security import create_token, decode_token, hash_one_time_token, new_one_time_token
    raw, hashed = new_one_time_token()
    assert hashed == hash_one_time_token(raw) and raw != hashed and len(raw) >= 40 and new_one_time_token()[0] != raw
    t = create_token(7, "student", token_version=3)
    p = decode_token(t)
    assert p["sub"] == "7" and p["role"] == "student" and p["tv"] == 3
    try:
        jwt.decode(t, "wrong-secret", algorithms=["HS256"])
        assert False
    except jwt.PyJWTError:
        pass


if __name__ == "__main__":
    for n, f in list(globals().items()):
        if n.startswith("test_"):
            f(); print("PASS", n)
