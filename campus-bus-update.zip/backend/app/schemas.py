from datetime import time
from typing import Annotated, Literal

from pydantic import AfterValidator, BaseModel, EmailStr, Field, StringConstraints

from .validation import check_password, check_phone

Text = lambda n: Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=n)]  # noqa: E731
Status = Literal["Active", "Inactive"]
Day = Literal["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
Password = Annotated[str, AfterValidator(check_password)]  # 8+ chars, a letter and a number; bcrypt ignores bytes past 72
Phone = Annotated[str, AfterValidator(check_phone)]


class LoginIn(BaseModel):
    identifier: Text(255)
    password: Annotated[str, StringConstraints(min_length=1, max_length=72)]
    remember: bool = False


class RegisterIn(BaseModel):
    name: Text(120)
    email: EmailStr
    password: Password
    student_id: Text(40)
    department: Text(120) | None = None
    phone: Phone | None = None
    default_stop_id: int | None = None


PREF_KEYS = {"departed", "delayed", "arriving", "changes", "emergency"}


class ProfileIn(BaseModel):
    name: Text(120) | None = None
    department: Annotated[str, StringConstraints(strip_whitespace=True, max_length=120)] | None = None
    phone: Phone | None = None
    email: EmailStr | None = None
    current_password: Annotated[str, StringConstraints(max_length=72)] | None = None  # required only when the email changes
    default_stop_name: Text(120) | None = None
    notification_prefs: dict[str, bool] | None = None
    theme: Literal["light", "dark", "system"] | None = None


class ForgotIn(BaseModel):
    email: EmailStr


class ResetIn(BaseModel):
    token: Text(200)
    new_password: Password


class TokenIn(BaseModel):
    token: Text(200)


class PasswordIn(BaseModel):
    current_password: Annotated[str, StringConstraints(min_length=1, max_length=72)]
    new_password: Password


class StatusIn(BaseModel):
    status: Status


class BusIn(BaseModel):
    bus_number: Text(40)
    registration_number: Text(40)
    capacity: int = Field(ge=1, le=100)
    route_id: int | None = None
    status: Status = "Active"


class StopIn(BaseModel):
    stop_name: Text(120)
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    status: Status = "Active"
    route_id: int | None = None
    stop_order: int | None = Field(default=None, ge=1)


class RouteStopIn(BaseModel):
    stop_id: int
    expected_time: time


class RouteIn(BaseModel):
    route_code: Annotated[str, StringConstraints(strip_whitespace=True, max_length=20)] | None = None
    route_name: Text(120)
    start_point: Annotated[str, StringConstraints(strip_whitespace=True, max_length=120)] | None = None
    destination: Annotated[str, StringConstraints(strip_whitespace=True, max_length=120)] | None = None
    status: Status = "Active"
    stops: list[RouteStopIn]
    bus_ids: list[int] = []


class ScheduleIn(BaseModel):
    bus_id: int
    route_id: int
    day: Day
    departure_time: time
    arrival_time: time
    status: Status = "Active"


class NotificationIn(BaseModel):
    title: Text(160)
    message: Text(1000)
    priority: Literal["Normal", "High", "Emergency"] = "Normal"
    target_type: Literal["all", "route", "bus"] = "all"
    target_id: int | None = None


class DeviceTokenIn(BaseModel):
    token: Text(512)


class ComplaintUpdateIn(BaseModel):
    status: Literal["Pending", "Investigating", "Resolved"] | None = None
    priority: Literal["Low", "Medium", "High"] | None = None


class Place(BaseModel):
    name: Text(120)
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)


class CampusIn(BaseModel):
    college: Place
    gate: Place
