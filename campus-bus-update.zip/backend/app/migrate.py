"""Idempotent schema upgrades for databases created by earlier phases. create_all() makes missing TABLES but never adds COLUMNS,
and the data an admin has entered must survive upgrades, so new columns are added here. PostgreSQL only (IF NOT EXISTS)."""
import logging

from sqlalchemy import text

log = logging.getLogger("migrate")

STATEMENTS = [
    # phase 8
    "ALTER TABLE users ADD COLUMN IF NOT EXISTS notification_prefs JSON",
    "ALTER TABLE notifications ADD COLUMN IF NOT EXISTS category VARCHAR(20) NOT NULL DEFAULT 'announcement'",
    # accounts update
    "ALTER TABLE users ADD COLUMN IF NOT EXISTS phone VARCHAR(20)",
    "ALTER TABLE users ADD COLUMN IF NOT EXISTS theme VARCHAR(10) NOT NULL DEFAULT 'system'",
    "ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verified BOOLEAN",
    "UPDATE users SET email_verified = TRUE WHERE email_verified IS NULL",  # accounts that already exist are treated as verified
    "ALTER TABLE users ADD COLUMN IF NOT EXISTS token_version INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE users ADD COLUMN IF NOT EXISTS last_login_at TIMESTAMPTZ",
    # route numbers
    "ALTER TABLE routes ADD COLUMN IF NOT EXISTS code VARCHAR(20)",
    "UPDATE routes SET code = 'R-' || (100 + id) WHERE code IS NULL",
    "CREATE UNIQUE INDEX IF NOT EXISTS uq_routes_code ON routes (code)",
    # bus speed
    "ALTER TABLE bus_locations ADD COLUMN IF NOT EXISTS speed_kmh DOUBLE PRECISION",
]


def run(engine) -> None:
    if engine.dialect.name != "postgresql":
        return
    for stmt in STATEMENTS:  # one transaction per step: in PostgreSQL a failed statement poisons the rest of its transaction
        try:
            with engine.begin() as conn:
                conn.execute(text(stmt))
        except Exception:
            log.exception("migration step skipped: %s", stmt)
