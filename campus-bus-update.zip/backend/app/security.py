import hashlib
import secrets
from datetime import datetime, timedelta, timezone

import bcrypt
import jwt

from .config import ACCESS_TOKEN_HOURS, REMEMBER_ME_HOURS, SECRET_KEY

ALGORITHM = "HS256"


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


def verify_password(password: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode(), hashed.encode())
    except ValueError:
        return False


# Used so a login for an unknown user takes as long as one for a known user.
DUMMY_HASH = hash_password("not-a-real-password")


def create_token(user_id: int, role: str, token_version: int = 0, remember: bool = False) -> str:
    """`tv` is the user's token_version: changing a password or signing out everywhere bumps it, which revokes every older token."""
    hours = REMEMBER_ME_HOURS if remember else ACCESS_TOKEN_HOURS
    payload = {"sub": str(user_id), "role": role, "tv": token_version, "exp": datetime.now(timezone.utc) + timedelta(hours=hours)}
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def new_one_time_token() -> tuple[str, str]:
    """(raw token for the email link, hash to store). Only the hash is kept, so a leaked database cannot be used to reset passwords."""
    raw = secrets.token_urlsafe(32)
    return raw, hash_one_time_token(raw)


def hash_one_time_token(raw: str) -> str:
    return hashlib.sha256(raw.encode()).hexdigest()


def decode_token(token: str) -> dict:
    return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
