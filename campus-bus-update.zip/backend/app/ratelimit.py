"""Small in-memory sliding-window limiter for login, sign-up and reset endpoints.
Per process: with several workers each keeps its own counts, so put a shared limiter (Redis, or the reverse proxy) in front for production."""
import threading
import time
from collections import defaultdict, deque

_lock = threading.Lock()
_hits: dict[str, deque] = defaultdict(deque)


def allow(key: str, limit: int, window_s: float, now: float | None = None) -> bool:
    """Record an attempt and say whether it is within `limit` attempts per `window_s` seconds."""
    now = time.monotonic() if now is None else now
    with _lock:
        q = _hits[key]
        while q and now - q[0] > window_s:
            q.popleft()
        if len(q) >= limit:
            return False
        q.append(now)
        if len(_hits) > 5000:  # forget keys that have gone quiet so memory cannot grow without bound
            for k in [k for k, v in _hits.items() if not v or now - v[-1] > window_s]:
                _hits.pop(k, None)
        return True


def clear(key: str) -> None:
    with _lock:
        _hits.pop(key, None)


def reset_all() -> None:
    with _lock:
        _hits.clear()
