import logging
import smtplib
import ssl
from email.message import EmailMessage

from . import config

log = logging.getLogger("email")


def configured() -> bool:
    return bool(config.EMAIL_HOST and config.EMAIL_FROM)


def send_email(to: str, subject: str, text: str, html: str | None = None) -> bool:
    """Blocking SMTP send; call it from a background task. Never raises: a mail problem must not break sign-up or reset requests."""
    if not configured():
        # development convenience only. In production the body (which contains a live link) is never written to the log.
        if config.IS_PRODUCTION:
            log.error("EMAIL_HOST / EMAIL_FROM are not configured, so no email was sent to %s.", to)
        else:
            log.warning("Email is not configured. Would have sent to %s\nSubject: %s\n\n%s", to, subject, text)
        return False
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = config.EMAIL_FROM, to, subject
    msg.set_content(text)
    if html:
        msg.add_alternative(html, subtype="html")
    try:
        if config.EMAIL_PORT == 465:
            smtp = smtplib.SMTP_SSL(config.EMAIL_HOST, config.EMAIL_PORT, timeout=15, context=ssl.create_default_context())
        else:
            smtp = smtplib.SMTP(config.EMAIL_HOST, config.EMAIL_PORT, timeout=15)
            if config.EMAIL_USE_TLS:
                smtp.starttls(context=ssl.create_default_context())
        with smtp:
            if config.EMAIL_USERNAME:
                smtp.login(config.EMAIL_USERNAME, config.EMAIL_PASSWORD)
            smtp.send_message(msg)
        return True
    except Exception:
        log.exception("Could not send email to %s", to)
        return False


def _html(title: str, intro: str, label: str, link: str, outro: str) -> str:
    return (f'<div style="font-family:Arial,sans-serif;max-width:480px;margin:auto;color:#1e293b"><h2 style="color:#1e1b4b">Campus Bus</h2>'
            f'<p style="margin-top:-12px;color:#64748b;font-size:13px">Identification and Management System</p><h3>{title}</h3><p>{intro}</p>'
            f'<p><a href="{link}" style="background:#4338ca;color:#fff;padding:12px 20px;border-radius:8px;text-decoration:none;display:inline-block">{label}</a></p>'
            f'<p style="font-size:13px;color:#64748b">If the button does not work, copy this link into your browser:<br>{link}</p><p style="font-size:13px;color:#64748b">{outro}</p></div>')


def verification_email(name: str, link: str) -> tuple[str, str, str]:
    hours = config.VERIFY_TOKEN_HOURS
    text = f"Hi {name},\n\nConfirm your email address for Campus Bus:\n{link}\n\nThe link works for {hours} hours. If you did not sign up, ignore this email."
    return "Confirm your Campus Bus email", text, _html("Confirm your email", f"Hi {name}, confirm your email address to finish setting up your account.", "Confirm email", link, f"The link works for {hours} hours. If you did not sign up, ignore this email.")


def reset_email(name: str, link: str) -> tuple[str, str, str]:
    mins = config.RESET_TOKEN_MINUTES
    text = f"Hi {name},\n\nSomeone asked to reset your Campus Bus password. Choose a new one here:\n{link}\n\nThe link works once and expires in {mins} minutes. If this was not you, ignore this email: your password stays the same."
    return "Reset your Campus Bus password", text, _html("Reset your password", f"Hi {name}, use the button to choose a new password.", "Choose a new password", link, f"The link works once and expires in {mins} minutes. If this was not you, ignore this email.")
