import re

COMMON = {"password", "password1", "password123", "12345678", "123456789", "1234567890", "qwerty123", "iloveyou1", "admin123456", "letmein123"}


def check_password(p: str) -> str:
    if len(p) < 8:
        raise ValueError("Password must be at least 8 characters.")
    if len(p.encode()) > 72:
        raise ValueError("Password is too long (72 bytes at most).")
    if not re.search(r"[A-Za-z]", p) or not re.search(r"\d", p):
        raise ValueError("Password must contain at least one letter and one number.")
    if p.lower() in COMMON:
        raise ValueError("That password is too common. Choose another.")
    return p


def check_phone(p: str) -> str:
    p = p.strip()
    if p == "":
        return ""
    if not re.fullmatch(r"\+?[0-9][0-9 \-]{5,18}", p) or not 7 <= len(re.sub(r"\D", "", p)) <= 15:
        raise ValueError("Enter a valid phone number (7 to 15 digits, optional + at the start).")
    return p


def email_domain_allowed(email: str, allowed: list[str]) -> bool:
    return not allowed or email.rsplit("@", 1)[-1].lower() in allowed
