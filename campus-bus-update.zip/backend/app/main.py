import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy.exc import IntegrityError

from . import models  # noqa: F401  (registers tables on Base.metadata)
from .config import CORS_ORIGINS
from . import migrate
from .database import Base, engine
from .routers import analytics, auth, buses, campus, complaints, ml, notifications, routes, schedules, stops, students, tracking


@asynccontextmanager
async def lifespan(_: FastAPI):
    Base.metadata.create_all(engine)  # creates missing tables
    migrate.run(engine)               # adds new columns to existing tables without losing data (Alembic arrives in Phase 11)
    tracking.restore_states()
    watcher = asyncio.create_task(tracking.watch_offline())
    yield
    watcher.cancel()


app = FastAPI(title="Campus Bus API", description="Identification and Management System", version="0.11.0", lifespan=lifespan)

app.add_middleware(CORSMiddleware, allow_origins=CORS_ORIGINS, allow_credentials=False, allow_methods=["*"], allow_headers=["*"])

for r in (auth.router, buses.router, routes.router, stops.router, schedules.router, students.router, analytics.router, tracking.router, notifications.router, complaints.router, ml.router, campus.router):
    app.include_router(r, prefix="/api")
app.include_router(tracking.ws_router)  # /ws/bus/{bus_id} and /ws/fleet


@app.get("/api/health")
def health():
    return {"status": "ok"}


log = logging.getLogger("api")


@app.exception_handler(IntegrityError)
async def integrity_error(_, exc: IntegrityError):
    log.warning("integrity error: %s", exc.orig)
    return JSONResponse(status_code=409, content={"detail": "That change conflicts with existing data."})


@app.exception_handler(Exception)
async def unexpected_error(_, exc: Exception):
    """Details go to the server log; the person using the app only sees a plain message."""
    log.exception("unhandled error")
    return JSONResponse(status_code=500, content={"detail": "Something went wrong on our side. Please try again in a moment."})
