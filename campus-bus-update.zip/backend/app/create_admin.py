"""Create (or promote) a real administrator account.
    python -m app.create_admin --email you@college.edu --name "Transport Office"
The password is asked for interactively (or taken from the CREATE_ADMIN_PASSWORD environment variable); it is never a command-line argument."""
import argparse
import getpass
import os
import re
import sys

from sqlalchemy import func, select

from . import migrate
from .database import Base, SessionLocal, engine
from .models import User
from .security import hash_password
from .validation import check_password


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--email", required=True)
    ap.add_argument("--name", required=True)
    args = ap.parse_args()
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", args.email):
        sys.exit("That does not look like an email address.")
    pw = os.getenv("CREATE_ADMIN_PASSWORD")
    if not pw:
        pw = getpass.getpass("Password: ")
        if pw != getpass.getpass("Repeat password: "):
            sys.exit("The passwords do not match.")
    try:
        check_password(pw)
    except ValueError as e:
        sys.exit(str(e))
    Base.metadata.create_all(engine)
    migrate.run(engine)
    with SessionLocal() as db:
        existing = db.scalar(select(User).where(func.lower(User.email) == args.email.lower()))
        if existing:
            existing.role, existing.name, existing.status, existing.email_verified = "admin", args.name, "Active", True
            existing.password_hash = hash_password(pw)
            existing.token_version += 1
            print(f"Updated {existing.email}: now an active admin with the new password.")
        else:
            db.add(User(name=args.name, email=args.email.lower(), role="admin", password_hash=hash_password(pw), email_verified=True))
            print(f"Created admin {args.email.lower()}.")
        db.commit()


if __name__ == "__main__":
    main()
