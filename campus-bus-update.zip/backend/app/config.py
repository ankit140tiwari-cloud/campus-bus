import os

from dotenv import load_dotenv

load_dotenv()


def _bool(name: str, default: bool = False) -> bool:
    return os.getenv(name, str(default)).strip().lower() in ("1", "true", "yes", "on")


ENVIRONMENT = os.getenv("ENVIRONMENT", "development").strip().lower()
IS_PRODUCTION = ENVIRONMENT == "production"

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql+psycopg2://campus:campus@localhost:5432/campus_bus")

_INSECURE = "dev-only-insecure-key-change-me"
SECRET_KEY = os.getenv("JWT_SECRET") or os.getenv("SECRET_KEY") or _INSECURE
if SECRET_KEY == _INSECURE:
    if IS_PRODUCTION:
        raise RuntimeError("JWT_SECRET must be set when ENVIRONMENT=production.")
    print("WARNING: JWT_SECRET is not set; using an insecure development key. Set JWT_SECRET in backend/.env.")

ACCESS_TOKEN_HOURS = int(os.getenv("ACCESS_TOKEN_HOURS", "12"))
REMEMBER_ME_HOURS = int(os.getenv("REMEMBER_ME_HOURS", "720"))
CORS_ORIGINS = [o.strip() for o in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",") if o.strip()]
FRONTEND_URL = os.getenv("FRONTEND_URL", "http://localhost:5173").rstrip("/")  # used in links inside emails

# ---- email (SMTP). Leave EMAIL_HOST empty in development: links are then printed to the server log instead. ----
EMAIL_HOST = os.getenv("EMAIL_HOST", "")
EMAIL_PORT = int(os.getenv("EMAIL_PORT", "587"))
EMAIL_USERNAME = os.getenv("EMAIL_USERNAME", "")
EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD", "")
EMAIL_FROM = os.getenv("EMAIL_FROM", "")
EMAIL_USE_TLS = _bool("EMAIL_USE_TLS", True)  # STARTTLS on 587; port 465 uses implicit TLS automatically
EMAIL_VERIFICATION_REQUIRED = _bool("EMAIL_VERIFICATION_REQUIRED", False)
ALLOWED_EMAIL_DOMAINS = [d.strip().lower().lstrip("@") for d in os.getenv("ALLOWED_EMAIL_DOMAINS", "").split(",") if d.strip()]  # empty = any
RESET_TOKEN_MINUTES = int(os.getenv("RESET_TOKEN_MINUTES", "30"))
VERIFY_TOKEN_HOURS = int(os.getenv("VERIFY_TOKEN_HOURS", "48"))

# ---- live tracking ----
APP_TIMEZONE = os.getenv("APP_TIMEZONE", "Asia/Kolkata")          # timezone the schedule times are written in
STALE_SECONDS = int(os.getenv("STALE_SECONDS", "120"))            # no GPS for this long => Offline
VISIT_RADIUS_M = float(os.getenv("VISIT_RADIUS_M", "150"))        # within this distance a stop counts as reached
DELAY_THRESHOLD_MIN = int(os.getenv("DELAY_THRESHOLD_MIN", "5"))  # this many minutes behind => Delayed
MIN_UPDATE_INTERVAL_S = float(os.getenv("MIN_UPDATE_INTERVAL_S", "1"))
DB_WRITE_INTERVAL_S = float(os.getenv("DB_WRITE_INTERVAL_S", "5"))

# ---- notifications and complaints ----
FIREBASE_CREDENTIALS = os.getenv("FIREBASE_CREDENTIALS", "")  # path to a Firebase service-account JSON; empty = push disabled
UPLOAD_DIR = os.getenv("UPLOAD_DIR", "uploads")
MAX_UPLOAD_BYTES = int(os.getenv("MAX_UPLOAD_BYTES", str(5 * 1024 * 1024)))
COMPLAINTS_PER_HOUR = int(os.getenv("COMPLAINTS_PER_HOUR", "10"))

# ---- ETA model ----
MODEL_DIR = os.getenv("MODEL_DIR", "models")
