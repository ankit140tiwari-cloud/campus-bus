from datetime import datetime, timedelta, timezone

from sqlalchemy import select, update
from sqlalchemy.orm import Session

from .models import AuthToken, User
from .security import hash_one_time_token, new_one_time_token


def issue(db: Session, user: User, kind: str, minutes: int) -> str:
    """Create a one-time token, cancelling any earlier unused one of the same kind. Returns the raw token for the email link."""
    now = datetime.now(timezone.utc)
    db.execute(update(AuthToken).where(AuthToken.user_id == user.id, AuthToken.kind == kind, AuthToken.used_at.is_(None)).values(used_at=now))
    raw, hashed = new_one_time_token()
    db.add(AuthToken(user_id=user.id, kind=kind, token_hash=hashed, expires_at=now + timedelta(minutes=minutes)))
    db.commit()
    return raw


def consume(db: Session, raw: str, kind: str) -> User | None:
    """Return the token's user and mark the token used, or None if it is unknown, used, expired, or the account is gone/inactive."""
    row = db.scalar(select(AuthToken).where(AuthToken.token_hash == hash_one_time_token(raw), AuthToken.kind == kind))
    now = datetime.now(timezone.utc)
    if row is None or row.used_at is not None or row.expires_at < now:
        return None
    user = db.get(User, row.user_id)
    if user is None or user.status != "Active":
        return None
    row.used_at = now
    db.flush()
    return user
