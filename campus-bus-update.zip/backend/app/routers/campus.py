from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user, require_admin
from ..models import AppSetting, Stop, User
from ..schemas import CampusIn

router = APIRouter(prefix="/campus", tags=["campus"])


def _read(db: Session) -> dict:
    row = db.get(AppSetting, "campus")
    if row:
        return row.value
    # nothing saved yet: use the stop called "College", if the admin has created one
    stop = db.scalar(select(Stop).where(func.lower(Stop.stop_name) == "college"))
    if stop is None:
        return {"college": None, "gate": None}
    return {"college": {"name": "College", "latitude": stop.latitude, "longitude": stop.longitude},
            "gate": {"name": "College front gate", "latitude": stop.latitude, "longitude": stop.longitude}}


@router.get("")
def get_campus(db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    return _read(db)


@router.put("")
def set_campus(data: CampusIn, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    value = data.model_dump()
    row = db.get(AppSetting, "campus")
    if row:
        row.value = value
    else:
        db.add(AppSetting(key="campus", value=value))
    db.commit()
    return value
