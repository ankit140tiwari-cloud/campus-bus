from datetime import datetime, timezone

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Request
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import auth_tokens, config, email, ratelimit
from ..database import get_db
from ..deps import get_current_user
from ..models import Stop, User
from ..schemas import PREF_KEYS, ForgotIn, LoginIn, PasswordIn, ProfileIn, RegisterIn, ResetIn, TokenIn
from ..security import DUMMY_HASH, create_token, hash_password, verify_password
from ..validation import email_domain_allowed

router = APIRouter(prefix="/auth", tags=["auth"])
TOO_MANY = "Too many attempts. Please wait a few minutes and try again."


def user_out(u: User) -> dict:
    return {"id": u.id, "name": u.name, "email": u.email, "role": u.role, "student_id": u.student_id, "department": u.department, "phone": u.phone,
            "default_stop_id": u.default_stop_id, "default_stop": u.default_stop.stop_name if u.default_stop else None, "status": u.status,
            "notification_prefs": u.notification_prefs, "theme": u.theme, "email_verified": u.email_verified,
            "last_login_at": u.last_login_at.astimezone(timezone.utc).isoformat() if u.last_login_at else None}


def _ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"


def _send_verification(db: Session, user: User, background: BackgroundTasks) -> None:
    raw = auth_tokens.issue(db, user, "verify", config.VERIFY_TOKEN_HOURS * 60)
    subject, text, html = email.verification_email(user.name, f"{config.FRONTEND_URL}/verify-email?token={raw}")
    background.add_task(email.send_email, user.email, subject, text, html)


@router.post("/login")
def login(data: LoginIn, request: Request, db: Session = Depends(get_db)):
    key = f"login:{_ip(request)}:{data.identifier.lower()}"
    if not ratelimit.allow(key, 10, 900):
        raise HTTPException(429, TOO_MANY)
    ident = data.identifier.lower()
    user = db.scalar(select(User).where((func.lower(User.email) == ident) | (func.lower(User.student_id) == ident)))
    ok = verify_password(data.password, user.password_hash if user else DUMMY_HASH)
    if not user or not ok:
        raise HTTPException(401, "Email / Student ID or password is incorrect.")
    if user.status != "Active":
        raise HTTPException(403, "This account is deactivated. Contact the transport office.")
    if config.EMAIL_VERIFICATION_REQUIRED and user.role != "admin" and not user.email_verified:
        raise HTTPException(403, "Please verify your email address first. Check your inbox for the confirmation link.")
    ratelimit.clear(key)
    user.last_login_at = datetime.now(timezone.utc)
    db.commit()
    return {"token": create_token(user.id, user.role, user.token_version, data.remember), "user": user_out(user)}


@router.post("/register", status_code=201)
def register(data: RegisterIn, request: Request, background: BackgroundTasks, db: Session = Depends(get_db)):
    """Self-registration always creates a student. Admin accounts are created with `python -m app.create_admin`."""
    if not ratelimit.allow(f"register:{_ip(request)}", 10, 3600):
        raise HTTPException(429, TOO_MANY)
    addr = data.email.lower()
    if not email_domain_allowed(addr, config.ALLOWED_EMAIL_DOMAINS):
        raise HTTPException(400, f"Use your college email address ({', '.join('@' + d for d in config.ALLOWED_EMAIL_DOMAINS)}).")
    if db.scalar(select(User).where(func.lower(User.email) == addr)):
        raise HTTPException(409, "An account with this email already exists.")
    if db.scalar(select(User).where(func.lower(User.student_id) == data.student_id.lower())):
        raise HTTPException(409, "An account with this Student ID already exists.")
    if data.default_stop_id is not None and db.get(Stop, data.default_stop_id) is None:
        raise HTTPException(400, "Default stop does not exist.")
    user = User(name=data.name, email=addr, password_hash=hash_password(data.password), role="student", student_id=data.student_id,
                department=data.department, phone=data.phone or None, default_stop_id=data.default_stop_id, email_verified=False)
    db.add(user)
    db.commit()
    _send_verification(db, user, background)
    return {"message": "Account created.", "verification_required": config.EMAIL_VERIFICATION_REQUIRED, "email_configured": email.configured()}


@router.post("/verify-email", status_code=204)
def verify_email(data: TokenIn, request: Request, db: Session = Depends(get_db)):
    if not ratelimit.allow(f"verify:{_ip(request)}", 20, 3600):
        raise HTTPException(429, TOO_MANY)
    user = auth_tokens.consume(db, data.token, "verify")
    if user is None:
        raise HTTPException(400, "This confirmation link is invalid or has expired. Request a new one from your profile.")
    user.email_verified = True
    db.commit()


@router.post("/resend-verification", status_code=204)
def resend_verification(background: BackgroundTasks, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.email_verified:
        return
    if not ratelimit.allow(f"resend:{user.id}", 3, 3600):
        raise HTTPException(429, TOO_MANY)
    _send_verification(db, user, background)


@router.post("/forgot-password", status_code=202)
def forgot_password(data: ForgotIn, request: Request, background: BackgroundTasks, db: Session = Depends(get_db)):
    """Always answers the same way, so nobody can use this form to find out which emails have accounts."""
    addr = data.email.lower()
    allowed = ratelimit.allow(f"forgot-ip:{_ip(request)}", 10, 3600) and ratelimit.allow(f"forgot-email:{addr}", 3, 3600)
    user = db.scalar(select(User).where(func.lower(User.email) == addr)) if allowed else None
    if user and user.status == "Active":
        raw = auth_tokens.issue(db, user, "reset", config.RESET_TOKEN_MINUTES)
        subject, text, html = email.reset_email(user.name, f"{config.FRONTEND_URL}/reset-password?token={raw}")
        background.add_task(email.send_email, user.email, subject, text, html)
    return {"message": "If an account exists for that email, a reset link is on its way."}


@router.post("/reset-password", status_code=204)
def reset_password(data: ResetIn, request: Request, db: Session = Depends(get_db)):
    if not ratelimit.allow(f"reset:{_ip(request)}", 10, 3600):
        raise HTTPException(429, TOO_MANY)
    user = auth_tokens.consume(db, data.token, "reset")
    if user is None:
        raise HTTPException(400, "This reset link is invalid or has expired. Request a new one.")
    user.password_hash = hash_password(data.new_password)
    user.token_version += 1  # every existing session is signed out
    db.commit()


@router.get("/me")
def me(user: User = Depends(get_current_user)):
    return user_out(user)


@router.put("/me")
def update_me(data: ProfileIn, background: BackgroundTasks, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    fields = data.model_fields_set
    if "name" in fields and data.name is not None:
        user.name = data.name
    if "department" in fields and data.department is not None:
        user.department = data.department or None
    if "phone" in fields:
        user.phone = data.phone or None
    if data.default_stop_name is not None:
        stop = db.scalar(select(Stop).where(Stop.stop_name == data.default_stop_name))
        if stop is None:
            raise HTTPException(400, "That stop does not exist.")
        user.default_stop_id = stop.id
    if data.notification_prefs is not None:
        if not set(data.notification_prefs) <= PREF_KEYS:
            raise HTTPException(400, "Unknown notification preference.")
        user.notification_prefs = {**(user.notification_prefs or {}), **data.notification_prefs, "emergency": True}  # emergencies cannot be switched off
    if data.theme is not None:
        user.theme = data.theme
    new_email = data.email.lower() if data.email else None
    if new_email and new_email != user.email.lower():  # changing the sign-in address needs the password, and must be confirmed again
        if not data.current_password or not verify_password(data.current_password, user.password_hash):
            raise HTTPException(400, "Enter your current password to change your email address.")
        if not email_domain_allowed(new_email, config.ALLOWED_EMAIL_DOMAINS):
            raise HTTPException(400, f"Use your college email address ({', '.join('@' + d for d in config.ALLOWED_EMAIL_DOMAINS)}).")
        if db.scalar(select(User.id).where(func.lower(User.email) == new_email, User.id != user.id)):
            raise HTTPException(409, "An account with this email already exists.")
        user.email, user.email_verified = new_email, False
        db.commit()
        _send_verification(db, user, background)
    db.commit()
    db.refresh(user)
    return user_out(user)


@router.post("/change-password")
def change_password(data: PasswordIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not ratelimit.allow(f"chpw:{user.id}", 10, 900):
        raise HTTPException(429, TOO_MANY)
    if not verify_password(data.current_password, user.password_hash):
        raise HTTPException(400, "Current password is incorrect.")
    if data.current_password == data.new_password:
        raise HTTPException(400, "Choose a new password that is different from the current one.")
    user.password_hash = hash_password(data.new_password)
    user.token_version += 1  # signs out every other device; this device gets a fresh token below
    db.commit()
    return {"token": create_token(user.id, user.role, user.token_version)}


@router.post("/logout-all", status_code=204)
def logout_all(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    user.token_version += 1
    db.commit()
