import { USE_MOCK } from '../utils/config';
import { api } from './api';
import { ROUTES, BUSES, STOP_NAMES, delay } from './mockData';

// Both branches return the API's JSON shape (see backend /api/analytics/dashboard), so the page never knows which is active.
export const getAnalytics = (range) => (USE_MOCK ? mockAnalytics(range) : api(`/analytics/dashboard?range=${range}`));

// ---------- sample data (mock mode only): deterministic, so it does not jump around between renders ----------
const mulberry = (a) => () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
const DAYS = { today: 1, '7d': 7, '30d': 30 };

function mockAnalytics(range) {
  const rnd = mulberry(range.length * 97 + 11);
  const n = DAYS[range] || 7;
  const labels = Array.from({ length: n }, (_, i) => { const d = new Date(); d.setDate(d.getDate() - (n - 1 - i)); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; });
  const weekend = labels.map((l) => [0, 6].includes(new Date(`${l}T00:00:00`).getDay()));
  const trips = weekend.map((w) => (w ? Math.floor(rnd() * 3) : 7 + Math.floor(rnd() * 4)));
  const avg_delay = trips.map((t) => (t ? Math.round((2 + rnd() * 6) * 10) / 10 : null));
  const complaints = labels.map(() => Math.floor(rnd() * 3));
  const totalTrips = trips.reduce((a, b) => a + b, 0);
  const share = [0.45, 0.33, 0.22];
  const routes = ROUTES.map((r, i) => ({ route: r.name, trips: Math.round(totalTrips * share[i]), students: [48, 36, 21][i] })).sort((a, b) => b.trips - a.trips);
  const delays = avg_delay.filter((x) => x != null);
  const total = complaints.reduce((a, b) => a + b, 0);
  const resolved = Math.round(total * 0.55), investigating = Math.round(total * 0.25);
  const types = ['Bus Delay', 'Bus Overcrowding', 'Stop Problem', 'Bus Not Available', 'Route Problem', 'Other'];
  return delay({
    range, from: labels[0], to: labels.at(-1), timezone: 'Asia/Kolkata', sample: true,
    summary: { trips: totalTrips, buses_used: Math.min(BUSES.length - 1, totalTrips ? 3 : 0), avg_delay_min: delays.length ? Math.round((delays.reduce((a, b) => a + b, 0) / delays.length) * 10) / 10 : null,
      on_time_pct: totalTrips ? 84 : null, complaints: total, resolved_pct: total ? Math.round((100 * resolved) / total) : null },
    daily: { labels, trips, avg_delay, complaints },
    routes,
    stops: STOP_NAMES.map((s, i) => ({ stop: s, students: Math.max(3, 24 - i * 3) })).slice(0, 8),
    delays_by_route: ROUTES.map((r, i) => ({ route: r.name, avg_delay: [6.2, 4.1, 3.3][i], visits: Math.round(totalTrips * 3.4 * share[i]) })),
    utilization: BUSES.filter((b) => b.status !== 'Offline').map((b, i) => { const scheduled = Math.max(1, Math.round(n * 0.7) * 2); const run = Math.max(0, scheduled - i * Math.ceil(n / 7)); return { bus: b.number, scheduled, run, pct: Math.min(100, Math.round((100 * run) / scheduled)) }; }),
    complaints: { by_status: [{ label: 'Pending', value: total - resolved - investigating }, { label: 'Investigating', value: investigating }, { label: 'Resolved', value: resolved }],
      by_type: types.map((t, i) => ({ label: t, value: Math.max(0, Math.round((total * [0.34, 0.22, 0.16, 0.12, 0.1, 0.06][i]))) })).filter((x) => x.value > 0) },
    demand: [['7 AM', 52], ['8 AM', 38], ['9 AM', 9], ['1 PM', 14], ['4 PM', 31], ['5 PM', 22]].map(([hour, students]) => ({ hour, students })),
  });
}
