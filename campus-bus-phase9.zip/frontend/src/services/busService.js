import { BUSES, ROUTES, delay } from './mockData';
import { toMin, addMin, fmt12 } from '../utils/helpers';
import { USE_MOCK } from '../utils/config';
import * as live from './busServiceLive';

// Simulated until Phase 7: place the bus between its last stop and the next one, by minutes travelled.
function positionOf(route, bus) {
  const a = route.stops[bus.currentIdx], b = route.stops[bus.currentIdx + 1];
  if (!a) return null;
  if (!b) return { lat: a.lat, lng: a.lng };
  const f = Math.min(Math.max(bus.ahead / (toMin(b.time) - toMin(a.time)), 0), 1);
  return { lat: a.lat + (b.lat - a.lat) * f, lng: a.lng + (b.lng - a.lng) * f };
}

const routeOf = (bus) => ROUTES.find((r) => r.id === bus.routeId);

// Builds the student-facing view of a bus, optionally relative to one stop.
export function describeBus(bus, stopName) {
  const route = routeOf(bus);
  const cur = route.stops[bus.currentIdx];
  const next = route.stops[bus.currentIdx + 1] || null;
  const out = {
    id: bus.id, number: bus.number, routeId: route.id, routeName: route.name, status: bus.status, delay: bus.delay,
    currentLocation: cur ? cur.name : 'Not started', nextStop: next ? next.name : 'Arrived at destination',
    position: positionOf(route, bus), routeStops: route.stops.map(({ name, lat, lng }) => ({ name, lat, lng })),
  };
  if (stopName && cur) {
    const t = route.stops.findIndex((s) => s.name === stopName);
    if (t >= bus.currentIdx && t >= 0) {
      out.eta = Math.max(0, toMin(route.stops[t].time) - toMin(cur.time) - bus.ahead + bus.delay);
      out.stopsRemaining = t - bus.currentIdx;
      out.departure = fmt12(addMin(route.stops[t].time, bus.delay));
    }
  }
  return out;
}

const mockGetBuses = () => delay(BUSES.map((b) => describeBus(b)));

function mockGetBusDetail(number, stopName) {
  const bus = BUSES.find((b) => b.number === number);
  if (!bus) return delay(null);
  const route = routeOf(bus);
  return delay({ ...describeBus(bus, stopName), currentIdx: bus.currentIdx, stops: route.stops.map((s) => ({ ...s, time: addMin(s.time, bus.delay) })) });
}

function mockGetNextBus(stopName) {
  const list = BUSES.filter((b) => b.status !== 'Offline').map((b) => describeBus(b, stopName)).filter((b) => b.eta !== undefined);
  return delay(list.sort((a, b) => a.eta - b.eta)[0] || null);
}

// Find Bus: routes where `from` comes before `to`, buses that have not passed `from` yet.
function mockSearchBuses({ from, to, time }) {
  const results = BUSES.filter((b) => b.status !== 'Offline').flatMap((b) => {
    const r = routeOf(b);
    const i = r.stops.findIndex((s) => s.name === from), j = r.stops.findIndex((s) => s.name === to);
    if (i < 0 || j < 0 || i >= j) return [];
    const d = describeBus(b, from);
    if (d.eta === undefined) return [];
    return [{ ...d, routeName: `${from} → ${to}`, destination: to }];
  });
  const filtered = time ? results.filter((r) => toMin(r.departure.length ? convert(r.departure) : '00:00') >= toMin(time)) : results;
  return delay(filtered.sort((a, b) => a.eta - b.eta));
}

function convert(s12) {
  const [t, ap] = s12.split(' ');
  let [h, m] = t.split(':').map(Number);
  if (ap === 'PM' && h !== 12) h += 12;
  if (ap === 'AM' && h === 12) h = 0;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

export const getBuses = () => (USE_MOCK ? mockGetBuses() : live.getBuses());
export const getBusDetail = (number, stop) => (USE_MOCK ? mockGetBusDetail(number, stop) : live.getBusDetail(number, stop));
export const getNextBus = (stop) => (USE_MOCK ? mockGetNextBus(stop) : live.getNextBus(stop));
export const searchBuses = (q) => (USE_MOCK ? mockSearchBuses(q) : live.searchBuses(q));
