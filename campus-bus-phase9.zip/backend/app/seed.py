"""Loads demo data matching the frontend sample data.
Run:  python -m app.seed [--reset] [--demo-history]
  --reset         wipe all tables first
  --demo-history  also invent 30 days of trips, stop visits and complaints so the analytics charts are populated (dev only)
"""
import os
import random
import sys
from datetime import datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

from sqlalchemy import select

from . import models as m
from .database import Base, SessionLocal, engine
from .security import hash_password

COORDS = {"Habibganj": (23.2296, 77.4393), "MP Nagar": (23.2332, 77.4344), "Board Office": (23.23, 77.43), "College": (23.2599, 77.4126),
          "Kolar": (23.17, 77.42), "New Market": (23.233, 77.399), "Roshanpura": (23.238, 77.405), "Bairagarh": (23.279, 77.338)}
ROUTES = [
    ("Habibganj – College", [("Habibganj", "07:15"), ("MP Nagar", "07:25"), ("Board Office", "07:35"), ("College", "07:50")]),
    ("Kolar – College", [("Kolar", "07:05"), ("New Market", "07:25"), ("Roshanpura", "07:38"), ("College", "07:55")]),
    ("Bairagarh – College", [("Bairagarh", "07:10"), ("Roshanpura", "07:30"), ("New Market", "07:42"), ("College", "08:00")]),
]
BUSES = [("BUS-12", 1, "Active"), ("BUS-07", 2, "Active"), ("BUS-21", 3, "Active"), ("BUS-03", 1, "Inactive"), ("BUS-05", 1, "Active"),
         ("BUS-09", 2, "Active"), ("BUS-14", 3, "Active"), ("BUS-18", 2, "Inactive"), ("BUS-25", 3, "Active")]
DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]


def t(s: str) -> time:
    h, mi = s.split(":")
    return time(int(h), int(mi))


def demo_history(db, admin_id: int) -> None:
    rng = random.Random(7)
    tz = ZoneInfo(os.getenv("APP_TIMEZONE", "Asia/Kolkata"))
    today = datetime.now(tz).date()
    day_names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    routes = {r.id: db.scalars(select(m.RouteStop).where(m.RouteStop.route_id == r.id).order_by(m.RouteStop.stop_order)).all() for r in db.scalars(select(m.Route)).all()}
    scheds = db.scalars(select(m.Schedule).where(m.Schedule.status == "Active")).all()
    trips = visits = 0
    for back in range(30, 0, -1):
        day = today - timedelta(days=back)
        for sc in (x for x in scheds if x.day == day_names[day.weekday()]):
            if rng.random() > 0.88:  # some scheduled trips do not run
                continue
            start = datetime.combine(day, sc.departure_time, tzinfo=tz).astimezone(timezone.utc)
            trip = m.Trip(bus_id=sc.bus_id, route_id=sc.route_id, started_by=admin_id, started_at=start,
                          ended_at=start + timedelta(minutes=(sc.arrival_time.hour * 60 + sc.arrival_time.minute) - (sc.departure_time.hour * 60 + sc.departure_time.minute)))
            db.add(trip)
            db.flush()
            trips += 1
            base = rng.choice([0, 0, 1, 2, 3, 4, 6, 9, 14])  # most trips run close to time, a few run late
            for link in routes[sc.route_id]:
                delay = max(0, base + rng.choice([-1, 0, 0, 1, 2]))
                offset = (link.expected_time.hour * 60 + link.expected_time.minute) - (sc.departure_time.hour * 60 + sc.departure_time.minute)
                db.add(m.StopVisit(trip_id=trip.id, bus_id=sc.bus_id, route_id=sc.route_id, stop_id=link.stop_id, stop_order=link.stop_order,
                                   delay_min=delay, arrived_at=start + timedelta(minutes=offset + delay)))
                visits += 1
    students = db.scalars(select(m.User).where(m.User.role == "student")).all()
    kinds = ["Bus Delay", "Bus Delay", "Bus Overcrowding", "Bus Not Available", "Stop Problem", "Route Problem", "Other"]
    for _ in range(18):
        when = datetime.now(timezone.utc) - timedelta(days=rng.randint(0, 29), hours=rng.randint(0, 20))
        st = rng.choice(students)
        db.add(m.Complaint(student_id=st.id, issue_type=rng.choice(kinds), description="Sample report created by the demo history seed.",
                           priority=rng.choice(["Low", "Medium", "High"]), status=rng.choice(["Pending", "Investigating", "Resolved", "Resolved"]), created_at=when, updated_at=when))
    db.commit()
    print(f"Demo history: {trips} trips, {visits} stop visits, 18 complaints (synthetic).")


def main() -> None:
    if "--reset" in sys.argv:
        Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        if db.scalar(select(m.User.id).limit(1)):
            print("Database already has data. Use --reset to wipe and reseed.")
            return
        stops = {n: m.Stop(stop_name=n, latitude=lat, longitude=lng) for n, (lat, lng) in COORDS.items()}
        db.add_all(stops.values())
        routes = []
        for name, plan in ROUTES:
            r = m.Route(route_name=name, start_point=plan[0][0], destination=plan[-1][0])
            db.add(r)
            db.flush()
            for i, (sn, tm) in enumerate(plan, 1):
                db.add(m.RouteStop(route_id=r.id, stop_id=stops[sn].id, stop_order=i, expected_time=t(tm)))
            routes.append((r, plan))
        db.flush()
        for i, (num, ridx, status) in enumerate(BUSES, 1):
            route, plan = routes[ridx - 1]
            bus = m.Bus(bus_number=num, registration_number=f"MP04 BU {1000 + i * 37}", capacity=40 + i * 4, route_id=route.id, status=status)
            db.add(bus)
            db.flush()
            if status != "Active":
                continue
            trips = [(plan[0][1], plan[-1][1], DAYS), ("16:30", "17:15", DAYS[:5])]
            if num == "BUS-21":
                trips.append(("13:30", "14:15", DAYS[:5]))
            for dep, arr, days in trips:
                for d in days:
                    db.add(m.Schedule(bus_id=bus.id, route_id=route.id, day=d, departure_time=t(dep), arrival_time=t(arr)))
        db.add(m.User(name="Transport Office", email="admin@college.edu", role="admin", password_hash=hash_password(os.getenv("SEED_ADMIN_PASSWORD", "admin123"))))
        db.add(m.User(name="Aarav Sharma", email="student@college.edu", role="student", student_id="CS2021045", department="Computer Science",
                      default_stop_id=stops["MP Nagar"].id, password_hash=hash_password(os.getenv("SEED_STUDENT_PASSWORD", "student123"))))
        extra = [("Riya Verma", "riya@college.edu", "CS2021051", "Computer Science", "Habibganj"), ("Karan Singh", "karan@college.edu", "ME2022012", "Mechanical", "Kolar"),
                 ("Neha Patel", "neha@college.edu", "EC2021033", "Electronics", "Bairagarh"), ("Imran Khan", "imran@college.edu", "CE2022008", "Civil", "New Market")]
        for name, email, sid, dept, stop in extra:
            db.add(m.User(name=name, email=email, role="student", student_id=sid, department=dept, default_stop_id=stops[stop].id,
                          password_hash=hash_password(os.getenv("SEED_STUDENT_PASSWORD", "student123"))))
        db.commit()
        print("Seeded: 8 stops, 3 routes, 9 buses, schedules, 1 admin, 5 students.")
        if "--demo-history" in sys.argv:
            demo_history(db, db.scalar(select(m.User.id).where(m.User.role == "admin")))


if __name__ == "__main__":
    main()
