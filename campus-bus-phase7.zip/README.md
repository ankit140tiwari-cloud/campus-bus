# Campus Bus — Identification and Management System

    frontend/   React + Vite + Tailwind + Leaflet
    backend/    FastAPI + SQLAlchemy + PostgreSQL + WebSocket
    docker-compose.yml   PostgreSQL 16

## Run with the real database and live tracking
1. `docker compose up -d db`
2. Backend (`backend/README.md`): install, `cp .env.example .env`, `python -m app.seed`, `uvicorn app.main:app --reload`
3. Frontend: `cd frontend && cp .env.example .env && npm install && npm run dev`

## Try live tracking (no phone needed)
1. Sign in as admin (admin@college.edu / admin123) and open **Trip Control**.
2. Pick BUS-12, tick **Simulate movement along the route**, press **START TRIP**.
3. In another tab, sign in as student@college.edu and open Live Tracking (or open admin Live Monitoring). The bus moves in real time.
4. Press **END TRIP**: the bus goes Offline everywhere.
Note: the simulation compares against the schedule times in your clock, so outside the 7-8 AM window the bus will show as Delayed. That is correct behaviour, not a bug.

For a real phone, open the app over HTTPS (browsers only give GPS to secure pages), sign in as admin, untick Simulate.

## Run frontend only (sample data)
`cd frontend && npm install && npm run dev` (VITE_USE_MOCK defaults to true; nothing is sent anywhere).

## Still sample data
Student notifications and complaints, admin Students/Notifications/Complaints (Phase 8), Analytics (Phase 9), ML ETA (Phase 10).
