import os
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql+psycopg2://campus:campus@localhost:5432/campus_bus")
SECRET_KEY = os.getenv("SECRET_KEY", "dev-only-insecure-key-change-me")
ACCESS_TOKEN_HOURS = int(os.getenv("ACCESS_TOKEN_HOURS", "12"))
REMEMBER_ME_HOURS = int(os.getenv("REMEMBER_ME_HOURS", "720"))
CORS_ORIGINS = [o.strip() for o in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",") if o.strip()]

if SECRET_KEY == "dev-only-insecure-key-change-me":
    print("WARNING: SECRET_KEY is the insecure default. Set SECRET_KEY in backend/.env before deploying.")

# ---- live tracking (Phase 7) ----
APP_TIMEZONE = os.getenv("APP_TIMEZONE", "Asia/Kolkata")          # timezone the schedule times are written in
STALE_SECONDS = int(os.getenv("STALE_SECONDS", "120"))            # no GPS for this long => Offline
VISIT_RADIUS_M = float(os.getenv("VISIT_RADIUS_M", "150"))        # within this distance a stop counts as reached
DELAY_THRESHOLD_MIN = int(os.getenv("DELAY_THRESHOLD_MIN", "5"))  # this many minutes behind => Delayed
MIN_UPDATE_INTERVAL_S = float(os.getenv("MIN_UPDATE_INTERVAL_S", "1"))
DB_WRITE_INTERVAL_S = float(os.getenv("DB_WRITE_INTERVAL_S", "5"))
