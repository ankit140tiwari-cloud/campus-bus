# Campus Bus — Identification and Management System (frontend)

    npm install
    npm run dev

Demo logins: student@college.edu / student123, admin@college.edu / admin123.
Phase 1 uses mock auth (src/services/authService.js, USE_MOCK = true).
