import { cx } from '../utils/helpers';

const tones = {
  success: 'bg-green-50 text-green-700 ring-green-600/20',
  warning: 'bg-amber-50 text-amber-700 ring-amber-600/20',
  danger: 'bg-red-50 text-red-700 ring-red-600/20',
  info: 'bg-brand-50 text-brand-700 ring-brand-600/20',
  neutral: 'bg-slate-100 text-slate-600 ring-slate-500/20',
};

export const statusTone = (s = '') =>
  ({ 'on time': 'success', active: 'success', resolved: 'success', delayed: 'warning', investigating: 'warning', pending: 'warning', offline: 'danger', inactive: 'neutral' }[s.toLowerCase()] || 'neutral');

export default function Badge({ tone, children }) {
  const t = tone || statusTone(String(children));
  return <span className={cx('inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset', tones[t])}>{children}</span>;
}
