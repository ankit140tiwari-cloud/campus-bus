import { ChevronRight } from 'lucide-react';

export default function RouteCard({ route, onOpen }) {
  return (
    <button onClick={() => onOpen(route)} className="flex w-full items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white p-4 text-left hover:border-brand-500">
      <div className="min-w-0">
        <p className="text-xs font-medium text-brand-600">{route.id}</p>
        <p className="font-semibold text-slate-900">{route.name}</p>
        <p className="mt-1 text-sm text-slate-500">{route.start} → {route.destination}</p>
        <p className="mt-1 text-xs text-slate-500">{route.stopCount} stops · {route.busCount} buses</p>
      </div>
      <ChevronRight size={20} className="shrink-0 text-slate-400" aria-hidden />
    </button>
  );
}
