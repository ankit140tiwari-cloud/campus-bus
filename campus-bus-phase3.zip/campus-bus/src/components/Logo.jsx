import { Bus } from 'lucide-react';
import { APP_NAME, APP_SUBTITLE } from '../utils/constants';
import { cx } from '../utils/helpers';

export default function Logo({ light = false, compact = false, className }) {
  return (
    <div className={cx('flex items-center gap-3', className)}>
      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-brand-600 text-white">
        <Bus size={22} aria-hidden />
      </span>
      {!compact && (
        <span className="leading-tight">
          <span className={cx('block text-base font-bold', light ? 'text-white' : 'text-brand-900')}>{APP_NAME}</span>
          <span className={cx('block text-[11px]', light ? 'text-indigo-200' : 'text-slate-500')}>{APP_SUBTITLE}</span>
        </span>
      )}
    </div>
  );
}
