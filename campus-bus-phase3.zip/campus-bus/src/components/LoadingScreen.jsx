import Logo from './Logo';

export default function LoadingScreen() {
  return (
    <div className="grid h-full place-items-center bg-white" role="status" aria-label="Loading">
      <div className="flex flex-col items-center gap-5">
        <Logo />
        <div className="h-1 w-40 overflow-hidden rounded-full bg-slate-200">
          <div className="h-full w-1/2 animate-pulse rounded-full bg-brand-600" />
        </div>
      </div>
    </div>
  );
}
