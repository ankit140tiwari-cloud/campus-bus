import { Link } from 'react-router-dom';
import { cx } from '../utils/helpers';

const tones = { neutral: 'text-slate-900', success: 'text-green-600', warning: 'text-amber-600', danger: 'text-red-600' };

export default function KpiCard({ label, value, icon: Icon, tone = 'neutral', to }) {
  const body = (
    <div className="flex items-start justify-between gap-2">
      <div>
        <p className="text-sm text-slate-500">{label}</p>
        <p className={cx('mt-1 text-2xl font-bold', tones[tone])}>{value}</p>
      </div>
      {Icon && <span className="grid h-9 w-9 place-items-center rounded-lg bg-slate-100 text-slate-500"><Icon size={18} aria-hidden /></span>}
    </div>
  );
  const cls = 'block rounded-xl border border-slate-200 bg-white p-4';
  return to ? <Link to={to} className={cx(cls, 'hover:border-brand-500')}>{body}</Link> : <div className={cls}>{body}</div>;
}
