import { useId } from 'react';
import { cx } from '../utils/helpers';

export default function Select({ label, options, placeholder, error, className, ...props }) {
  const id = useId();
  return (
    <div className={className}>
      {label && <label htmlFor={id} className="mb-1.5 block text-sm font-medium text-slate-700">{label}</label>}
      <select id={id} aria-invalid={!!error}
        className={cx('min-h-[44px] w-full rounded-lg border bg-white px-3 text-sm', error ? 'border-red-500' : 'border-slate-300')} {...props}>
        {placeholder && <option value="">{placeholder}</option>}
        {options.map((o) => { const v = typeof o === 'string' ? o : o.value; const l = typeof o === 'string' ? o : o.label; return <option key={v} value={v}>{l}</option>; })}
      </select>
      {error && <p className="mt-1 text-xs text-red-600">{error}</p>}
    </div>
  );
}
