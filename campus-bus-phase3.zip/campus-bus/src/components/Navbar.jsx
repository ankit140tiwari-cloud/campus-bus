import { Menu, LogOut } from 'lucide-react';
import useAuth from '../hooks/useAuth';
import Logo from './Logo';
import { initials } from '../utils/helpers';

export default function Navbar({ onMenu }) {
  const { user, logout } = useAuth();
  return (
    <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-slate-200 bg-white px-3 sm:px-5"
      style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}>
      <div className="flex items-center gap-2">
        <button onClick={onMenu} aria-label="Open menu" className="rounded-md p-2 text-slate-600 hover:bg-slate-100 lg:hidden"><Menu size={22} /></button>
        <Logo compact className="lg:hidden" />
        <p className="text-sm font-bold text-brand-900 lg:hidden">Campus Bus</p>
        <p className="hidden text-sm text-slate-500 lg:block">Campus Bus · Identification and Management System</p>
      </div>
      <div className="flex items-center gap-3">
        <div className="hidden text-right leading-tight sm:block">
          <p className="text-sm font-semibold text-slate-800">{user?.name}</p>
          <p className="text-xs capitalize text-slate-500">{user?.role}</p>
        </div>
        <span className="grid h-9 w-9 place-items-center rounded-full bg-brand-100 text-sm font-bold text-brand-700">{initials(user?.name)}</span>
        <button onClick={logout} aria-label="Sign out" className="rounded-md p-2 text-slate-500 hover:bg-slate-100"><LogOut size={20} /></button>
      </div>
    </header>
  );
}
