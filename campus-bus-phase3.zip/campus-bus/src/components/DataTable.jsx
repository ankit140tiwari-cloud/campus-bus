import { cx } from '../utils/helpers';

// columns: [{ key, label, render?(row) }]. First column becomes the card title on mobile.
export default function DataTable({ columns, rows, onRowClick, rowKey = 'id' }) {
  const cell = (c, r) => (c.render ? c.render(r) : r[c.key]);
  return (
    <>
      <div className="hidden overflow-x-auto rounded-xl border border-slate-200 bg-white md:block">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50 text-slate-500">
            <tr>{columns.map((c) => <th key={c.key} className="whitespace-nowrap px-4 py-3 font-medium">{c.label}</th>)}</tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map((r) => (
              <tr key={r[rowKey]} onClick={onRowClick && (() => onRowClick(r))} className={cx(onRowClick && 'cursor-pointer hover:bg-slate-50')}>
                {columns.map((c, i) => <td key={c.key} className={cx('px-4 py-3', i === 0 && 'font-semibold text-slate-900')}>{cell(c, r)}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <ul className="space-y-3 md:hidden">
        {rows.map((r) => (
          <li key={r[rowKey]}>
            <div onClick={onRowClick && (() => onRowClick(r))} className={cx('rounded-xl border border-slate-200 bg-white p-4', onRowClick && 'cursor-pointer')}>
              <div className="font-semibold text-slate-900">{cell(columns[0], r)}</div>
              <dl className="mt-2 grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
                {columns.slice(1).map((c) => <div key={c.key}><dt className="text-xs text-slate-500">{c.label}</dt><dd>{cell(c, r)}</dd></div>)}
              </dl>
            </div>
          </li>
        ))}
      </ul>
    </>
  );
}
