import { cx } from '../utils/helpers';

export default function Card({ title, action, className, children }) {
  return (
    <section className={cx('rounded-xl border border-slate-200 bg-white p-4 sm:p-5', className)}>
      {(title || action) && (
        <header className="mb-3 flex items-center justify-between gap-2">
          {title && <h2 className="text-sm font-semibold text-slate-900">{title}</h2>}
          {action}
        </header>
      )}
      {children}
    </section>
  );
}
