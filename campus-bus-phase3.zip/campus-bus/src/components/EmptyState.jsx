export default function EmptyState({ icon: Icon, title, message, action }) {
  return (
    <div className="flex flex-col items-center gap-2 py-10 text-center">
      {Icon && <Icon size={32} className="text-slate-400" aria-hidden />}
      <p className="font-semibold text-slate-800">{title}</p>
      {message && <p className="max-w-xs text-sm text-slate-500">{message}</p>}
      {action}
    </div>
  );
}
