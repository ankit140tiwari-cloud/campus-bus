import { Bus } from 'lucide-react';
import { fmt12, cx } from '../utils/helpers';

// currentIdx: last stop the bus passed (-1 = none). highlight: the student's stop.
export default function StopTimeline({ stops, currentIdx = -2, highlight }) {
  return (
    <ol className="relative">
      {stops.map((s, i) => {
        const passed = i <= currentIdx, here = i === currentIdx;
        return (
          <li key={s.name} className="relative flex gap-3 pb-6 last:pb-0">
            {i < stops.length - 1 && <span className={cx('absolute left-[11px] top-6 h-full w-0.5', i < currentIdx ? 'bg-brand-500' : 'bg-slate-200')} />}
            <span className={cx('z-10 grid h-6 w-6 shrink-0 place-items-center rounded-full border-2 bg-white', passed ? 'border-brand-500' : 'border-slate-300', here && 'bg-brand-600')}>
              {here && <Bus size={12} className="text-white" aria-label="Bus is here" />}
            </span>
            <div className="flex flex-1 items-baseline justify-between gap-2">
              <p className={cx('text-sm', s.name === highlight ? 'font-bold text-brand-700' : 'font-medium text-slate-800')}>
                {s.name}{s.name === highlight && <span className="ml-2 text-xs font-normal text-brand-600">Your stop</span>}
              </p>
              <p className="text-sm text-slate-500">{fmt12(s.time)}</p>
            </div>
          </li>
        );
      })}
    </ol>
  );
}
