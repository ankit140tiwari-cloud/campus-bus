export default function LoadingSkeleton({ rows = 3 }) {
  return (
    <div className="space-y-3" aria-hidden>
      {Array.from({ length: rows }).map((_, i) => <div key={i} className="h-16 animate-pulse rounded-xl bg-slate-200" />)}
    </div>
  );
}
