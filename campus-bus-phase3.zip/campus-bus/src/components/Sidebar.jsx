import { NavLink } from 'react-router-dom';
import * as Icons from 'lucide-react';
import Logo from './Logo';
import { cx } from '../utils/helpers';

export default function Sidebar({ items, onNavigate }) {
  return (
    <aside className="flex h-full w-64 flex-col bg-brand-900 p-4">
      <Logo light className="px-2 pb-6 pt-2" />
      <nav className="flex-1 space-y-1 overflow-y-auto">
        {items.map(({ to, label, icon, end }) => {
          const Icon = Icons[icon];
          return (
            <NavLink key={to} to={to} end={end} onClick={onNavigate}
              className={({ isActive }) => cx('flex min-h-[44px] items-center gap-3 rounded-lg px-3 text-sm font-medium transition-colors',
                isActive ? 'bg-white/15 text-white' : 'text-indigo-200 hover:bg-white/10 hover:text-white')}>
              {Icon && <Icon size={18} aria-hidden />}
              {label}
            </NavLink>
          );
        })}
      </nav>
    </aside>
  );
}
