import { Bus } from 'lucide-react';
import Badge from './Badge';
import Button from './Button';

export default function BusCard({ bus, onTrack }) {
  return (
    <article className="rounded-xl border border-slate-200 bg-white p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-lg bg-brand-50 text-brand-600"><Bus size={22} aria-hidden /></span>
          <div>
            <p className="font-bold text-slate-900">{bus.number}</p>
            <p className="text-sm text-slate-500">{bus.routeName}</p>
          </div>
        </div>
        <Badge>{bus.status}</Badge>
      </div>
      <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-3 text-sm sm:grid-cols-3">
        {bus.departure && <div><dt className="text-slate-500">Departure</dt><dd className="font-semibold">{bus.departure}</dd></div>}
        <div><dt className="text-slate-500">Current location</dt><dd className="font-semibold">{bus.currentLocation}</dd></div>
        <div><dt className="text-slate-500">Next stop</dt><dd className="font-semibold">{bus.nextStop}</dd></div>
        {bus.eta !== undefined && <div><dt className="text-slate-500">ETA</dt><dd className="font-semibold">{bus.eta} min</dd></div>}
        {bus.stopsRemaining !== undefined && <div><dt className="text-slate-500">Stops remaining</dt><dd className="font-semibold">{bus.stopsRemaining}</dd></div>}
      </dl>
      {onTrack && <Button onClick={() => onTrack(bus)} className="mt-4 w-full sm:w-auto">Track Bus</Button>}
    </article>
  );
}
