import Badge from './Badge';

export default function ScheduleCard({ item }) {
  return (
    <article className="rounded-xl border border-slate-200 bg-white p-4">
      <div className="flex items-center justify-between"><p className="font-bold text-slate-900">{item.bus}</p><Badge>{item.status}</Badge></div>
      <p className="text-sm text-slate-500">{item.route}</p>
      <p className="mt-2 text-sm"><span className="text-slate-500">Departs</span> <b>{item.dep}</b> <span className="ml-2 text-slate-500">Arrives</span> <b>{item.arr}</b></p>
    </article>
  );
}
