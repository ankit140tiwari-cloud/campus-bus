import { forwardRef, useId } from 'react';
import { cx } from '../utils/helpers';

const Input = forwardRef(function Input({ label, error, hint, className, ...props }, ref) {
  const id = useId();
  return (
    <div className={className}>
      {label && <label htmlFor={id} className="mb-1.5 block text-sm font-medium text-slate-700">{label}</label>}
      <input
        id={id}
        ref={ref}
        aria-invalid={!!error}
        className={cx(
          'min-h-[44px] w-full rounded-lg border bg-white px-3 text-sm placeholder:text-slate-400',
          error ? 'border-red-500' : 'border-slate-300'
        )}
        {...props}
      />
      {error ? <p className="mt-1 text-xs text-red-600">{error}</p> : hint && <p className="mt-1 text-xs text-slate-500">{hint}</p>}
    </div>
  );
});
export default Input;
