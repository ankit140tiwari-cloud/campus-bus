import { createContext, useState, useCallback } from 'react';
import * as authService from '../services/authService';
import { getStoredAuth } from '../services/api';
import { STORAGE_KEY } from '../utils/constants';

export const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [auth, setAuth] = useState(() => getStoredAuth());

  const login = useCallback(async (creds) => {
    const result = await authService.login(creds);
    setAuth(result);
    return result.user;
  }, []);

  const logout = useCallback(() => { authService.logout(); setAuth(null); }, []);

  const updateUser = useCallback((patch) => {
    setAuth((a) => {
      const next = { ...a, user: { ...a.user, ...patch } };
      const store = localStorage.getItem(STORAGE_KEY) ? localStorage : sessionStorage;
      store.setItem(STORAGE_KEY, JSON.stringify(next));
      return next;
    });
  }, []);

  return (
    <AuthContext.Provider value={{ user: auth?.user ?? null, token: auth?.token ?? null, login, logout, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
}
