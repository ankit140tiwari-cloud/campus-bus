import { useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { Bus, MapPin, Clock } from 'lucide-react';
import useAuth from '../../hooks/useAuth';
import Logo from '../../components/Logo';
import Input from '../../components/Input';
import Button from '../../components/Button';
import { HOME_BY_ROLE } from '../../utils/constants';

export default function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ identifier: '', password: '', remember: false });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [notice, setNotice] = useState('');

  if (user) return <Navigate to={HOME_BY_ROLE[user.role]} replace />;

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    const next = {};
    if (!form.identifier.trim()) next.identifier = 'Enter your email or Student ID.';
    if (!form.password) next.password = 'Enter your password.';
    setErrors(next);
    setNotice('');
    if (Object.keys(next).length) return;
    setLoading(true);
    try {
      const u = await login(form);
      navigate(HOME_BY_ROLE[u.role], { replace: true });
    } catch (err) {
      setErrors({ form: err.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid min-h-full lg:grid-cols-2">
      <div className="hidden flex-col justify-between bg-brand-900 p-12 text-white lg:flex">
        <Logo light />
        <div className="max-w-md space-y-6">
          <h1 className="text-3xl font-bold leading-tight">Know which bus to take, and when it reaches you.</h1>
          <ul className="space-y-3 text-indigo-100">
            <li className="flex items-center gap-3"><Bus size={18} /> Find the right bus for your stop</li>
            <li className="flex items-center gap-3"><MapPin size={18} /> Track it live on the map</li>
            <li className="flex items-center gap-3"><Clock size={18} /> See schedules and expected arrival times</li>
          </ul>
        </div>
        <p className="text-sm text-indigo-300">Campus Bus · Identification and Management System</p>
      </div>

      <div className="flex items-center justify-center p-5 sm:p-10">
        <div className="w-full max-w-sm">
          <Logo className="mb-8 lg:hidden" />
          <h2 className="text-2xl font-bold text-slate-900">Sign in</h2>
          <p className="mt-1 text-sm text-slate-500">Use your college email or Student ID.</p>

          <form onSubmit={submit} className="mt-6 space-y-4" noValidate>
            {errors.form && <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700">{errors.form}</p>}
            {notice && <p role="status" className="rounded-lg bg-brand-50 p-3 text-sm text-brand-700">{notice}</p>}
            <Input label="Email / Student ID" autoComplete="username" value={form.identifier} onChange={set('identifier')} error={errors.identifier} />
            <Input label="Password" type="password" autoComplete="current-password" value={form.password} onChange={set('password')} error={errors.password} />
            <div className="flex items-center justify-between text-sm">
              <label className="flex min-h-[44px] items-center gap-2 text-slate-600">
                <input type="checkbox" checked={form.remember} onChange={set('remember')} className="h-4 w-4 rounded border-slate-300" />
                Remember me
              </label>
              <button type="button" className="font-medium text-brand-600 hover:underline"
                onClick={() => setNotice('Password reset arrives with the backend in Phase 5. For now, ask the transport office.')}>
                Forgot password?
              </button>
            </div>
            <Button type="submit" loading={loading} className="w-full">Sign in</Button>
          </form>

          <div className="mt-8 rounded-lg border border-dashed border-slate-300 p-3 text-xs text-slate-500">
            <p className="font-semibold text-slate-600">Demo accounts (Phase 1)</p>
            <p>Student: student@college.edu / student123</p>
            <p>Admin: admin@college.edu / admin123</p>
          </div>
        </div>
      </div>
    </div>
  );
}
