import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { SearchX } from 'lucide-react';
import useAuth from '../../hooks/useAuth';
import { searchBuses } from '../../services/busService';
import { stopNames } from '../../services/routeService';
import Select from '../../components/Select';
import Input from '../../components/Input';
import Button from '../../components/Button';
import BusCard from '../../components/BusCard';
import Card from '../../components/Card';
import EmptyState from '../../components/EmptyState';
import LoadingSkeleton from '../../components/LoadingSkeleton';

export default function FindBus() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ from: user.defaultStop || '', to: 'College', time: '07:00' });
  const [errors, setErrors] = useState({});
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    const err = {};
    if (!form.from) err.from = 'Choose your starting stop.';
    if (!form.to) err.to = 'Choose a destination.';
    if (form.from && form.from === form.to) err.to = 'Destination must differ from the starting stop.';
    setErrors(err);
    if (Object.keys(err).length) return;
    setLoading(true);
    setResults(await searchBuses(form));
    setLoading(false);
  };

  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <h1 className="text-xl font-bold text-slate-900">Find my bus</h1>
      <Card>
        <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2" noValidate>
          <Select label="Starting stop" options={stopNames} placeholder="Select stop" value={form.from} onChange={set('from')} error={errors.from} />
          <Select label="Destination" options={stopNames} placeholder="Select stop" value={form.to} onChange={set('to')} error={errors.to} />
          <Input label="Preferred departure time" type="time" value={form.time} onChange={set('time')} className="sm:col-span-2" />
          <Button type="submit" loading={loading} className="sm:col-span-2">Find buses</Button>
        </form>
      </Card>

      {loading && <LoadingSkeleton rows={2} />}
      {!loading && results && (results.length ? (
        <div className="space-y-3">
          <p className="text-sm text-slate-500">{results.length} bus{results.length > 1 ? 'es' : ''} found</p>
          {results.map((b) => <BusCard key={b.number} bus={b} onTrack={(x) => navigate(`/student/live?bus=${x.number}&stop=${encodeURIComponent(form.from)}`)} />)}
        </div>
      ) : (
        <Card><EmptyState icon={SearchX} title="No buses match" message="No running bus goes from this stop to that destination after your time. Try an earlier time or another stop." /></Card>
      ))}
    </div>
  );
}
