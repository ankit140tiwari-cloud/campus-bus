import { useState } from 'react';
import { CalendarX } from 'lucide-react';
import useAsync from '../../hooks/useAsync';
import { getSchedules } from '../../services/scheduleService';
import { fmt12, periodOf } from '../../utils/helpers';
import Select from '../../components/Select';
import Badge from '../../components/Badge';
import Card from '../../components/Card';
import ScheduleCard from '../../components/ScheduleCard';
import EmptyState from '../../components/EmptyState';
import LoadingSkeleton from '../../components/LoadingSkeleton';

const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const today = DAYS[(new Date().getDay() + 6) % 7] || 'Mon';

export default function Schedule() {
  const { data, loading, error, reload } = useAsync(getSchedules, []);
  const [period, setPeriod] = useState('All');
  const [day, setDay] = useState(today);

  const rows = (data || [])
    .filter((s) => s.days.includes(day) && (period === 'All' || periodOf(s.departure) === period))
    .map((s) => ({ ...s, dep: fmt12(s.departure), arr: fmt12(s.arrival) }))
    .sort((a, b) => a.departure.localeCompare(b.departure));

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <h1 className="text-xl font-bold text-slate-900">Bus schedule</h1>
      <div className="grid grid-cols-2 gap-3">
        <Select label="Time of day" options={['All', 'Morning', 'Afternoon', 'Evening']} value={period} onChange={(e) => setPeriod(e.target.value)} />
        <Select label="Day" options={DAYS} value={day} onChange={(e) => setDay(e.target.value)} />
      </div>
      {loading ? <LoadingSkeleton /> : error ? (
        <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700">{error} <button onClick={reload} className="font-semibold underline">Try again</button></p>
      ) : !rows.length ? (
        <Card><EmptyState icon={CalendarX} title="No trips for this filter" message="Try another day or time of day." /></Card>
      ) : (
        <>
          <div className="space-y-3 md:hidden">{rows.map((r) => <ScheduleCard key={r.id} item={r} />)}</div>
          <div className="hidden overflow-hidden rounded-xl border border-slate-200 bg-white md:block">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-500"><tr>{['Bus', 'Route', 'Departure', 'Expected arrival', 'Status'].map((h) => <th key={h} className="px-4 py-3 font-medium">{h}</th>)}</tr></thead>
              <tbody className="divide-y divide-slate-100">
                {rows.map((r) => (
                  <tr key={r.id}><td className="px-4 py-3 font-semibold">{r.bus}</td><td className="px-4 py-3">{r.route}</td><td className="px-4 py-3">{r.dep}</td><td className="px-4 py-3">{r.arr}</td><td className="px-4 py-3"><Badge>{r.status}</Badge></td></tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
