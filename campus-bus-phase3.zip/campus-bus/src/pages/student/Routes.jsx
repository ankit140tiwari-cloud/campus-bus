import { useState } from 'react';
import { ArrowLeft, Search } from 'lucide-react';
import useAsync from '../../hooks/useAsync';
import { getRoutes } from '../../services/routeService';
import Input from '../../components/Input';
import Card from '../../components/Card';
import RouteCard from '../../components/RouteCard';
import StopTimeline from '../../components/StopTimeline';
import EmptyState from '../../components/EmptyState';
import LoadingSkeleton from '../../components/LoadingSkeleton';

export default function Routes() {
  const { data, loading, error, reload } = useAsync(getRoutes, []);
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(null);

  if (open) {
    return (
      <div className="mx-auto max-w-2xl space-y-4">
        <button onClick={() => setOpen(null)} className="flex min-h-[44px] items-center gap-1 text-sm font-medium text-brand-600"><ArrowLeft size={16} /> All routes</button>
        <h1 className="text-xl font-bold text-slate-900">{open.id} · {open.name}</h1>
        <p className="text-sm text-slate-500">{open.stopCount} stops · {open.busCount} buses · Map view arrives in Phase 6.</p>
        <Card title="Stops and expected arrival"><StopTimeline stops={open.stops} /></Card>
      </div>
    );
  }

  const list = (data || []).filter((r) => `${r.id} ${r.name} ${r.stops.map((s) => s.name).join(' ')}`.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <h1 className="text-xl font-bold text-slate-900">Routes & stops</h1>
      <Input placeholder="Search route or stop" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search routes" />
      {loading ? <LoadingSkeleton /> : error ? (
        <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700">{error} <button onClick={reload} className="font-semibold underline">Try again</button></p>
      ) : list.length ? (
        <div className="space-y-3">{list.map((r) => <RouteCard key={r.id} route={r} onOpen={setOpen} />)}</div>
      ) : <Card><EmptyState icon={Search} title="No routes found" message="Check the spelling or search by a stop name." /></Card>}
    </div>
  );
}
