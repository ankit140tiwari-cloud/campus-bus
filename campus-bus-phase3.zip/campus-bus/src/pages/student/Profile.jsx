import { useState } from 'react';
import useAuth from '../../hooks/useAuth';
import { changePassword } from '../../services/studentService';
import { stopNames } from '../../services/routeService';
import { useToast } from '../../components/Toast';
import { initials } from '../../utils/helpers';
import Input from '../../components/Input';
import Select from '../../components/Select';
import Button from '../../components/Button';
import Card from '../../components/Card';

const PREFS = [['departed', 'Bus departed'], ['delayed', 'Bus delayed'], ['arriving', 'Bus arriving soon'], ['changes', 'Route or schedule changes'], ['emergency', 'Emergency announcements']];

export default function Profile() {
  const { user, updateUser } = useAuth();
  const toast = useToast();
  const [form, setForm] = useState({ name: user.name, department: user.department, defaultStop: user.defaultStop });
  const [prefs, setPrefs] = useState(user.prefs || Object.fromEntries(PREFS.map(([k]) => [k, true])));
  const [pw, setPw] = useState({ current: '', next: '', confirm: '' });
  const [pwErr, setPwErr] = useState('');
  const [pwBusy, setPwBusy] = useState(false);

  const saveProfile = (e) => {
    e.preventDefault();
    if (!form.name.trim()) return toast('Name cannot be empty', 'error');
    updateUser({ ...form, prefs });
    toast('Profile saved');
  };

  const savePw = async (e) => {
    e.preventDefault();
    setPwErr('');
    if (pw.next.length < 8) return setPwErr('New password must be at least 8 characters.');
    if (pw.next !== pw.confirm) return setPwErr('New passwords do not match.');
    setPwBusy(true);
    try { await changePassword(pw); setPw({ current: '', next: '', confirm: '' }); toast('Password changed'); }
    catch (err) { setPwErr(err.message); }
    finally { setPwBusy(false); }
  };

  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <div className="flex items-center gap-4">
        <span className="grid h-14 w-14 place-items-center rounded-full bg-brand-100 text-lg font-bold text-brand-700">{initials(user.name)}</span>
        <div><h1 className="text-xl font-bold text-slate-900">{user.name}</h1><p className="text-sm text-slate-500">{user.studentId} · {user.email}</p></div>
      </div>

      <form onSubmit={saveProfile} className="space-y-4">
        <Card title="Profile">
          <div className="grid gap-4 sm:grid-cols-2">
            <Input label="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <Input label="Department" value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })} />
            <Input label="Student ID" value={user.studentId} disabled hint="Contact the transport office to change this." />
            <Input label="Email" value={user.email} disabled />
            <Select label="Default bus stop" options={stopNames} value={form.defaultStop} onChange={(e) => setForm({ ...form, defaultStop: e.target.value })} className="sm:col-span-2" />
          </div>
        </Card>
        <Card title="Notification preferences">
          <ul className="divide-y divide-slate-100">
            {PREFS.map(([k, label]) => (
              <li key={k}><label className="flex min-h-[44px] items-center justify-between text-sm"><span>{label}</span>
                <input type="checkbox" checked={!!prefs[k]} onChange={(e) => setPrefs({ ...prefs, [k]: e.target.checked })} className="h-5 w-5 rounded border-slate-300" /></label></li>
            ))}
          </ul>
        </Card>
        <Button type="submit" className="w-full sm:w-auto">Save changes</Button>
      </form>

      <Card title="Change password">
        <form onSubmit={savePw} className="space-y-4" noValidate>
          {pwErr && <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700">{pwErr}</p>}
          <Input label="Current password" type="password" autoComplete="current-password" value={pw.current} onChange={(e) => setPw({ ...pw, current: e.target.value })} />
          <Input label="New password" type="password" autoComplete="new-password" value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} />
          <Input label="Confirm new password" type="password" autoComplete="new-password" value={pw.confirm} onChange={(e) => setPw({ ...pw, confirm: e.target.value })} />
          <Button type="submit" variant="secondary" loading={pwBusy}>Change password</Button>
        </form>
      </Card>
    </div>
  );
}
