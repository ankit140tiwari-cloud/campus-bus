import { BellOff } from 'lucide-react';
import useAsync from '../../hooks/useAsync';
import { getNotifications, markRead, markAllRead } from '../../services/studentService';
import { useToast } from '../../components/Toast';
import NotificationItem from '../../components/NotificationItem';
import Button from '../../components/Button';
import Card from '../../components/Card';
import EmptyState from '../../components/EmptyState';
import LoadingSkeleton from '../../components/LoadingSkeleton';

export default function Notifications() {
  const { data, loading, error, reload, setData } = useAsync(getNotifications, []);
  const toast = useToast();
  const unread = (data || []).filter((n) => !n.read).length;

  const read = async (id) => { await markRead(id); setData(data.map((n) => (n.id === id ? { ...n, read: true } : n))); };
  const readAll = async () => { await markAllRead(); setData(data.map((n) => ({ ...n, read: true }))); toast('All notifications marked as read'); };

  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-xl font-bold text-slate-900">Notifications{unread > 0 && <span className="ml-2 text-sm font-medium text-brand-600">{unread} unread</span>}</h1>
        <Button variant="secondary" onClick={readAll} disabled={!unread}>Mark all as read</Button>
      </div>
      {loading ? <LoadingSkeleton /> : error ? (
        <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700">{error} <button onClick={reload} className="font-semibold underline">Try again</button></p>
      ) : data.length ? (
        <ul className="space-y-3">{data.map((n) => <NotificationItem key={n.id} n={n} onRead={read} />)}</ul>
      ) : <Card><EmptyState icon={BellOff} title="No notifications yet" message="Delays, departures and announcements will appear here." /></Card>}
    </div>
  );
}
