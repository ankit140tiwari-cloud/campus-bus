import { useLocation } from 'react-router-dom';
import { Construction } from 'lucide-react';
import EmptyState from '../components/EmptyState';

export default function ComingSoon() {
  const { pathname } = useLocation();
  return <EmptyState icon={Construction} title="This page is not built yet" message={`${pathname} is planned in a later phase.`} />;
}
