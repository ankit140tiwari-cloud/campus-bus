import { Link } from 'react-router-dom';
import { Bus, Activity, Clock, WifiOff, Route, MapPin, Users, MessageSquareWarning, CheckCircle2 } from 'lucide-react';
import useAsync from '../../hooks/useAsync';
import { getOverview } from '../../services/adminService';
import { timeAgo } from '../../utils/helpers';
import KpiCard from '../../components/KpiCard';
import Card from '../../components/Card';
import Badge from '../../components/Badge';
import EmptyState from '../../components/EmptyState';
import LoadingSkeleton from '../../components/LoadingSkeleton';

const ACTIONS = [['/admin/buses', 'Manage buses'], ['/admin/routes', 'Manage routes'], ['/admin/notifications', 'Send announcement'], ['/admin/complaints', 'Review complaints']];

export default function AdminDashboard() {
  const { data, loading, error, reload } = useAsync(getOverview, []);

  if (error) return <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700">{error} <button onClick={reload} className="font-semibold underline">Try again</button></p>;
  if (loading) return <div className="space-y-4"><LoadingSkeleton rows={2} /><LoadingSkeleton rows={2} /></div>;

  const { kpis: k, fleet, complaints } = data;
  const delayed = fleet.filter((b) => b.status === 'Delayed');
  const pending = complaints.filter((c) => c.status === 'Pending');
  const segments = [['On Time', k.activeBuses - k.delayedBuses, 'bg-green-500'], ['Delayed', k.delayedBuses, 'bg-amber-500'], ['Offline', k.offlineBuses, 'bg-red-500']];

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold text-slate-900">Transport overview</h1>
        <p className="text-sm text-slate-500">Sample data until the database is connected in Phase 5.</p>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <KpiCard label="Total Buses" value={k.totalBuses} icon={Bus} to="/admin/buses" />
        <KpiCard label="Active Buses" value={k.activeBuses} icon={Activity} tone="success" to="/admin/live" />
        <KpiCard label="Delayed Buses" value={k.delayedBuses} icon={Clock} tone="warning" to="/admin/live" />
        <KpiCard label="Offline Buses" value={k.offlineBuses} icon={WifiOff} tone="danger" to="/admin/live" />
        <KpiCard label="Total Routes" value={k.totalRoutes} icon={Route} to="/admin/routes" />
        <KpiCard label="Total Stops" value={k.totalStops} icon={MapPin} to="/admin/stops" />
        <KpiCard label="Registered Students" value={k.students.toLocaleString('en-IN')} icon={Users} to="/admin/students" />
        <KpiCard label="Pending Complaints" value={k.pendingComplaints} icon={MessageSquareWarning} tone={k.pendingComplaints ? 'warning' : 'neutral'} to="/admin/complaints" />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Fleet status" className="lg:col-span-1">
          <div className="flex h-3 overflow-hidden rounded-full bg-slate-100" role="img" aria-label={segments.map(([l, n]) => `${n} ${l}`).join(', ')}>
            {segments.map(([l, n, c]) => n > 0 && <div key={l} className={c} style={{ width: `${(n / k.totalBuses) * 100}%` }} />)}
          </div>
          <ul className="mt-4 space-y-2 text-sm">
            {segments.map(([l, n, c]) => <li key={l} className="flex items-center justify-between"><span className="flex items-center gap-2"><span className={`h-2.5 w-2.5 rounded-full ${c}`} />{l}</span><b>{n}</b></li>)}
          </ul>
        </Card>

        <Card title="Delayed buses" action={<Link to="/admin/live" className="text-sm font-medium text-brand-600 hover:underline">Monitor</Link>} className="lg:col-span-2">
          {delayed.length ? (
            <ul className="divide-y divide-slate-100">
              {delayed.map((b) => (
                <li key={b.number} className="flex items-center justify-between gap-3 py-3 text-sm">
                  <div><p className="font-semibold text-slate-900">{b.number} <span className="font-normal text-slate-500">· {b.routeName}</span></p><p className="text-slate-500">At {b.currentLocation}, next {b.nextStop}</p></div>
                  <Badge tone="warning">+{b.delay} min</Badge>
                </li>
              ))}
            </ul>
          ) : <EmptyState icon={CheckCircle2} title="No delays right now" message="Every active bus is on time." />}
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Pending complaints" action={<Link to="/admin/complaints" className="text-sm font-medium text-brand-600 hover:underline">View all</Link>} className="lg:col-span-2">
          {pending.length ? (
            <ul className="divide-y divide-slate-100">
              {pending.map((c) => (
                <li key={c.id} className="flex items-center justify-between gap-3 py-3 text-sm">
                  <div className="min-w-0"><p className="font-semibold text-slate-900">{c.issue}{c.bus && <span className="font-normal text-slate-500"> · {c.bus}</span>}</p><p className="text-slate-500">{c.student} · {timeAgo(c.minsAgo)}</p></div>
                  <Badge tone={c.priority === 'High' ? 'danger' : c.priority === 'Medium' ? 'warning' : 'neutral'}>{c.priority}</Badge>
                </li>
              ))}
            </ul>
          ) : <EmptyState icon={CheckCircle2} title="No pending complaints" />}
        </Card>

        <Card title="Quick actions">
          <div className="grid gap-2">
            {ACTIONS.map(([to, label]) => <Link key={to} to={to} className="flex min-h-[44px] items-center rounded-lg border border-slate-200 px-3 text-sm font-medium text-slate-700 hover:border-brand-500 hover:bg-brand-50">{label}</Link>)}
          </div>
        </Card>
      </div>
    </div>
  );
}
