import { useState } from 'react';
import { Info, BusFront } from 'lucide-react';
import useAsync from '../../hooks/useAsync';
import { getFleet } from '../../services/adminService';
import { cx } from '../../utils/helpers';
import DataTable from '../../components/DataTable';
import Badge from '../../components/Badge';
import Modal from '../../components/Modal';
import Button from '../../components/Button';
import Card from '../../components/Card';
import EmptyState from '../../components/EmptyState';
import LoadingSkeleton from '../../components/LoadingSkeleton';

const FILTERS = ['All', 'On Time', 'Delayed', 'Offline'];
const seen = (m) => (m === 0 ? 'Just now' : m < 60 ? `${m} min ago` : `${Math.floor(m / 60)} h ago`);

const COLUMNS = [
  { key: 'number', label: 'Bus' },
  { key: 'routeName', label: 'Route' },
  { key: 'currentLocation', label: 'Current location' },
  { key: 'nextStop', label: 'Next stop' },
  { key: 'status', label: 'Status', render: (b) => <Badge>{b.status}</Badge> },
  { key: 'lastSeen', label: 'Last updated', render: (b) => seen(b.lastSeen) },
];

export default function LiveMonitoring() {
  const { data, loading, error, reload } = useAsync(getFleet, []);
  const [filter, setFilter] = useState('All');
  const [sel, setSel] = useState(null);
  const rows = (data || []).filter((b) => filter === 'All' || b.status === filter);

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold text-slate-900">Live bus monitoring</h1>
      <div className="flex items-start gap-2 rounded-lg bg-brand-50 p-3 text-sm text-brand-700">
        <Info size={16} className="mt-0.5 shrink-0" aria-hidden />
        <p>The all-buses map (Leaflet + OpenStreetMap) arrives in Phase 6, and real-time GPS updates in Phase 7. This is the fleet list on sample data.</p>
      </div>

      <div className="flex flex-wrap gap-2" role="group" aria-label="Filter by status">
        {FILTERS.map((f) => (
          <button key={f} onClick={() => setFilter(f)} aria-pressed={filter === f}
            className={cx('min-h-[44px] rounded-full px-4 text-sm font-medium', filter === f ? 'bg-brand-600 text-white' : 'border border-slate-300 bg-white text-slate-700 hover:bg-slate-50')}>
            {f}{data && <span className="ml-1.5 opacity-70">{f === 'All' ? data.length : data.filter((b) => b.status === f).length}</span>}
          </button>
        ))}
      </div>

      {loading ? <LoadingSkeleton rows={4} /> : error ? (
        <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700">{error} <button onClick={reload} className="font-semibold underline">Try again</button></p>
      ) : rows.length ? <DataTable columns={COLUMNS} rows={rows} rowKey="number" onRowClick={setSel} />
        : <Card><EmptyState icon={BusFront} title={`No ${filter.toLowerCase()} buses`} message="Choose another filter to see the rest of the fleet." /></Card>}

      <Modal open={!!sel} onClose={() => setSel(null)} title={sel ? `${sel.number} details` : ''} footer={<Button variant="secondary" onClick={() => setSel(null)}>Close</Button>}>
        {sel && (
          <dl className="grid grid-cols-2 gap-4 text-sm">
            {[['Route', `${sel.routeId} · ${sel.routeName}`], ['Status', <Badge key="s">{sel.status}</Badge>], ['Current location', sel.currentLocation], ['Next stop', sel.nextStop],
              ['Delay', sel.delay ? `${sel.delay} min` : 'None'], ['Last updated', seen(sel.lastSeen)]].map(([l, v]) => (
              <div key={l}><dt className="text-slate-500">{l}</dt><dd className="font-semibold text-slate-900">{v}</dd></div>
            ))}
          </dl>
        )}
      </Modal>
    </div>
  );
}
