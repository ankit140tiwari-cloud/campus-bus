import { ROUTES, BUSES, STOP_NAMES, delay } from './mockData';

export const getRoutes = () =>
  delay(ROUTES.map((r) => ({
    id: r.id, name: r.name, stopCount: r.stops.length, busCount: BUSES.filter((b) => b.routeId === r.id).length,
    start: r.stops[0].name, destination: r.stops[r.stops.length - 1].name, stops: r.stops,
  })));
export const getStopNames = () => delay(STOP_NAMES, 100);
export const getRouteOptions = () => ROUTES.map((r) => ({ value: r.id, label: `${r.id} · ${r.name}` }));
export const getBusOptions = () => BUSES.map((b) => ({ value: b.number, label: b.number }));
export const stopNames = STOP_NAMES;
