import { BUSES, ROUTES, STOP_NAMES, delay } from './mockData';
import { describeBus } from './busService';

// PHASE 3 mock fleet. Phase 5 replaces this with GET /api/analytics/overview and GET /api/buses.
const EXTRA = [
  { id: 5, number: 'BUS-05', routeId: 'R01', status: 'On Time', delay: 0, currentIdx: 2, ahead: 1, seen: 0 },
  { id: 6, number: 'BUS-09', routeId: 'R02', status: 'On Time', delay: 0, currentIdx: 1, ahead: 6, seen: 1 },
  { id: 7, number: 'BUS-14', routeId: 'R03', status: 'Delayed', delay: 15, currentIdx: 0, ahead: 2, seen: 0 },
  { id: 8, number: 'BUS-18', routeId: 'R02', status: 'Offline', delay: 0, currentIdx: -1, ahead: 0, seen: 120 },
  { id: 9, number: 'BUS-25', routeId: 'R03', status: 'On Time', delay: 0, currentIdx: 2, ahead: 3, seen: 2 },
];
const FLEET = [...BUSES.map((b, i) => ({ ...b, seen: b.status === 'Offline' ? 45 : i })), ...EXTRA];

const COMPLAINTS = [
  { id: 'C-1048', student: 'Riya Verma', issue: 'Bus Overcrowding', bus: 'BUS-12', priority: 'High', status: 'Pending', minsAgo: 25 },
  { id: 'C-1047', student: 'Karan Singh', issue: 'Bus Delay', bus: 'BUS-14', priority: 'Medium', status: 'Pending', minsAgo: 90 },
  { id: 'C-1042', student: 'Aarav Sharma', issue: 'Bus Delay', bus: 'BUS-07', priority: 'Medium', status: 'Investigating', minsAgo: 1400 },
  { id: 'C-1039', student: 'Neha Patel', issue: 'Stop Problem', bus: '', priority: 'Low', status: 'Pending', minsAgo: 2900 },
];

export function getFleet() {
  return delay(FLEET.map((b) => {
    const d = describeBus(b);
    const offline = b.status === 'Offline';
    return { ...d, currentLocation: offline ? 'Unknown' : d.currentLocation, nextStop: offline ? '—' : d.nextStop, lastSeen: b.seen };
  }));
}

export async function getOverview() {
  const fleet = await getFleet();
  const count = (s) => fleet.filter((b) => b.status === s).length;
  return {
    kpis: {
      totalBuses: fleet.length, activeBuses: count('On Time') + count('Delayed'), delayedBuses: count('Delayed'), offlineBuses: count('Offline'),
      totalRoutes: ROUTES.length, totalStops: STOP_NAMES.length, students: 1240, pendingComplaints: COMPLAINTS.filter((c) => c.status === 'Pending').length,
    },
    fleet,
    complaints: COMPLAINTS,
  };
}
