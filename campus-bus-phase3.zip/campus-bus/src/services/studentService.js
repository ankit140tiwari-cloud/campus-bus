import { NOTIFICATIONS, setNotifications, COMPLAINTS, addComplaint, delay } from './mockData';

export const getNotifications = () => delay(NOTIFICATIONS.map((n) => ({ ...n })));
export const markRead = (id) => { setNotifications(NOTIFICATIONS.map((n) => (n.id === id ? { ...n, read: true } : n))); return delay(true, 100); };
export const markAllRead = () => { setNotifications(NOTIFICATIONS.map((n) => ({ ...n, read: true }))); return delay(true, 100); };

export const getComplaints = () => delay(COMPLAINTS.map((c) => ({ ...c })));
export const createComplaint = (data) => {
  const c = { ...data, id: `C-${1000 + Math.floor(Math.random() * 9000)}`, status: 'Pending', date: new Date().toISOString().slice(0, 10) };
  addComplaint(c);
  return delay(c, 500);
};

export const changePassword = ({ current, next }) =>
  delay(null, 500).then(() => { if (current !== 'student123') throw new Error('Current password is incorrect.'); return true; });
