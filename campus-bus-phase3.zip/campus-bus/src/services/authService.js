import { STORAGE_KEY } from '../utils/constants';
import { api } from './api';

// PHASE 1: demo accounts so the UI works without a backend.
// PHASE 5: set USE_MOCK = false to call POST /api/auth/login on FastAPI.
const USE_MOCK = true;

const DEMO_USERS = [
  { identifier: 'student@college.edu', studentId: 'CS2021045', password: 'student123', user: { id: 1, name: 'Aarav Sharma', role: 'student', studentId: 'CS2021045', email: 'student@college.edu', department: 'Computer Science', defaultStop: 'MP Nagar' } },
  { identifier: 'admin@college.edu', studentId: null, password: 'admin123', user: { id: 2, name: 'Transport Office', role: 'admin', email: 'admin@college.edu' } },
];

export async function login({ identifier, password, remember }) {
  let result;
  if (USE_MOCK) {
    await new Promise((r) => setTimeout(r, 600));
    const id = identifier.trim().toLowerCase();
    const match = DEMO_USERS.find((u) => (u.identifier === id || u.studentId?.toLowerCase() === id) && u.password === password);
    if (!match) throw new Error('Email / Student ID or password is incorrect.');
    result = { token: 'demo-token', user: match.user };
  } else {
    result = await api('/auth/login', { method: 'POST', body: { identifier, password } });
  }
  localStorage.removeItem(STORAGE_KEY);
  sessionStorage.removeItem(STORAGE_KEY);
  (remember ? localStorage : sessionStorage).setItem(STORAGE_KEY, JSON.stringify(result));
  return result;
}

export function logout() {
  localStorage.removeItem(STORAGE_KEY);
  sessionStorage.removeItem(STORAGE_KEY);
}
