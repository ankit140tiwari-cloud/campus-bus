import { SCHEDULES, BUSES, delay } from './mockData';

export const getSchedules = () =>
  delay(SCHEDULES.map((s) => ({ ...s, status: BUSES.find((b) => b.number === s.bus)?.status || 'Scheduled' })));
