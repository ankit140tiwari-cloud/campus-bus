import { STORAGE_KEY } from '../utils/constants';

const BASE = import.meta.env.VITE_API_URL || '/api';

export const getStoredAuth = () => {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || sessionStorage.getItem(STORAGE_KEY) || 'null');
  } catch {
    return null;
  }
};

export async function api(path, { method = 'GET', body, headers = {} } = {}) {
  const auth = getStoredAuth();
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(auth?.token ? { Authorization: `Bearer ${auth.token}` } : {}),
      ...headers,
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || 'Request failed. Check your connection and try again.');
  }
  return res.status === 204 ? null : res.json();
}
