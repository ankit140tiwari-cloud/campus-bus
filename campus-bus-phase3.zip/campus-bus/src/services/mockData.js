// PHASE 2 mock data. Phases 5+ replace this with FastAPI calls inside the service files.
export const delay = (v, ms = 350) => new Promise((r) => setTimeout(() => r(v), ms));

export const ROUTES = [
  { id: 'R01', name: 'Habibganj – College', stops: [['Habibganj', '07:15'], ['MP Nagar', '07:25'], ['Board Office', '07:35'], ['College', '07:50']] },
  { id: 'R02', name: 'Kolar – College', stops: [['Kolar', '07:05'], ['New Market', '07:25'], ['Roshanpura', '07:38'], ['College', '07:55']] },
  { id: 'R03', name: 'Bairagarh – College', stops: [['Bairagarh', '07:10'], ['Roshanpura', '07:30'], ['New Market', '07:42'], ['College', '08:00']] },
].map((r) => ({ ...r, stops: r.stops.map(([name, time]) => ({ name, time })) }));

export const STOP_NAMES = [...new Set(ROUTES.flatMap((r) => r.stops.map((s) => s.name)))].sort();

// currentIdx = index of the last stop passed, ahead = minutes travelled since it, delay = minutes late
export const BUSES = [
  { id: 1, number: 'BUS-12', routeId: 'R01', status: 'On Time', delay: 0, currentIdx: 0, ahead: 2 },
  { id: 2, number: 'BUS-07', routeId: 'R02', status: 'Delayed', delay: 10, currentIdx: 0, ahead: 3 },
  { id: 3, number: 'BUS-21', routeId: 'R03', status: 'On Time', delay: 0, currentIdx: 1, ahead: 4 },
  { id: 4, number: 'BUS-03', routeId: 'R01', status: 'Offline', delay: 0, currentIdx: -1, ahead: 0 },
];

const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
export const SCHEDULES = BUSES.filter((b) => b.status !== 'Offline').flatMap((b) => {
  const r = ROUTES.find((x) => x.id === b.routeId);
  const first = r.stops[0], last = r.stops[r.stops.length - 1];
  const rows = [
    { dep: first.time, arr: last.time, days: DAYS, label: r.name },
    { dep: '16:30', arr: '17:15', days: DAYS.slice(0, 5), label: `College – ${first.name}` },
  ];
  if (b.number === 'BUS-21') rows.push({ dep: '13:30', arr: '14:15', days: DAYS.slice(0, 5), label: `College – ${first.name}` });
  return rows.map((x, i) => ({ id: `${b.id}-${i}`, bus: b.number, route: x.label, departure: x.dep, arrival: x.arr, days: x.days }));
});

export let NOTIFICATIONS = [
  { id: 1, type: 'delayed', title: 'BUS-07 delayed', message: 'BUS-07 is running 10 minutes late due to traffic near New Market.', minsAgo: 6, read: false },
  { id: 2, type: 'arriving', title: 'BUS-12 arriving soon', message: 'BUS-12 will reach MP Nagar in about 8 minutes.', minsAgo: 12, read: false },
  { id: 3, type: 'departed', title: 'BUS-21 departed', message: 'BUS-21 left Bairagarh at 7:10 AM.', minsAgo: 55, read: true },
  { id: 4, type: 'schedule', title: 'Schedule changed', message: 'Evening trips on Route 02 now start at 4:45 PM from College.', minsAgo: 1500, read: true },
  { id: 5, type: 'emergency', title: 'Emergency announcement', message: 'Road closure on Hoshangabad Road. Route 03 will use the bypass until 6 PM.', minsAgo: 3000, read: true },
];

export let COMPLAINTS = [
  { id: 'C-1042', type: 'Bus Delay', bus: 'BUS-07', route: 'R02', stop: 'New Market', description: 'Bus arrived 20 minutes late twice this week.', status: 'Investigating', date: '2026-09-28' },
  { id: 'C-1031', type: 'Stop Problem', bus: '', route: 'R01', stop: 'Board Office', description: 'Shelter roof is broken.', status: 'Resolved', date: '2026-09-20' },
];
export const addComplaint = (c) => { COMPLAINTS = [c, ...COMPLAINTS]; };
export const setNotifications = (n) => { NOTIFICATIONS = n; };
