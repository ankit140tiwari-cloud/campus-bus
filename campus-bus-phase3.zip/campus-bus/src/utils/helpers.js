export const cx = (...c) => c.filter(Boolean).join(' ');
export const initials = (name = '') =>
  name.split(' ').filter(Boolean).slice(0, 2).map((p) => p[0].toUpperCase()).join('');

export const toMin = (hhmm) => { const [h, m] = hhmm.split(':').map(Number); return h * 60 + m; };
export const fmt12 = (hhmm) => {
  const [h, m] = hhmm.split(':').map(Number);
  return `${h % 12 || 12}:${String(m).padStart(2, '0')} ${h >= 12 ? 'PM' : 'AM'}`;
};
export const addMin = (hhmm, add) => {
  const t = toMin(hhmm) + add;
  return `${String(Math.floor(t / 60) % 24).padStart(2, '0')}:${String(t % 60).padStart(2, '0')}`;
};
export const periodOf = (hhmm) => { const h = toMin(hhmm) / 60; return h < 12 ? 'Morning' : h < 17 ? 'Afternoon' : 'Evening'; };
export const timeAgo = (mins) => (mins < 60 ? `${mins} min ago` : mins < 1440 ? `${Math.floor(mins / 60)} h ago` : `${Math.floor(mins / 1440)} d ago`);
