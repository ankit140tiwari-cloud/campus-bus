import { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from '../components/Sidebar';
import Navbar from '../components/Navbar';

export default function AppShell({ items }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="flex h-full">
      <div className="hidden lg:block"><Sidebar items={items} /></div>
      {open && (
        <div className="fixed inset-0 z-40 lg:hidden" onClick={() => setOpen(false)}>
          <div className="absolute inset-0 bg-slate-900/50" />
          <div className="relative h-full w-64" onClick={(e) => e.stopPropagation()}>
            <Sidebar items={items} onNavigate={() => setOpen(false)} />
          </div>
        </div>
      )}
      <div className="flex min-w-0 flex-1 flex-col">
        <Navbar onMenu={() => setOpen(true)} />
        <main className="flex-1 overflow-y-auto p-4 sm:p-6" style={{ paddingBottom: 'calc(1rem + env(safe-area-inset-bottom, 0px))' }}>
          <Outlet />
        </main>
      </div>
    </div>
  );
}
