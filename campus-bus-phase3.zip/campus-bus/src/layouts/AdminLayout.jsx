import AppShell from './AppShell';
import { ADMIN_NAV } from '../utils/constants';

export default function AdminLayout() {
  return <AppShell items={ADMIN_NAV} />;
}
