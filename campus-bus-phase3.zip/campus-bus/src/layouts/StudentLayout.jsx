import AppShell from './AppShell';
import { STUDENT_NAV } from '../utils/constants';

export default function StudentLayout() {
  return <AppShell items={STUDENT_NAV} />;
}
