# Campus Bus — Identification and Management System

    frontend/   React + Vite + Tailwind + Leaflet + Recharts
    backend/    FastAPI + SQLAlchemy + PostgreSQL + WebSocket + scikit-learn
    docker-compose.yml   PostgreSQL 16

The database is the source of truth. Sample data exists only if you opt in with `VITE_USE_MOCK=true`.

## First run
1. `docker compose up -d db`
2. Backend
   ```
   cd backend && python -m venv .venv && source .venv/bin/activate
   pip install -r requirements.txt
   cp .env.example .env            # set JWT_SECRET (python -c "import secrets; print(secrets.token_urlsafe(48))")
   python -m app.seed              # stops, routes (R-101..), buses, schedules, and DEMO accounts (development only)
   python -m app.create_admin --email you@your-college.edu --name "Transport Office"   # a real admin; asks for a password
   uvicorn app.main:app --reload
   ```
3. Frontend: `cd frontend && cp .env.example .env && npm install && npm run dev`

Demo accounts from the seed (admin@college.edu / admin123, student@college.edu / student123) exist for development only. The seed refuses to run when `ENVIRONMENT=production`. Do not rely on them: use Sign Up for students and `create_admin` for administrators.

**Upgrading an existing database:** nothing is wiped. On start-up the server adds the new columns (route codes, phone, theme, token versions, speed...) and gives your existing routes codes `R-101, R-102, ...`. Existing accounts count as email-verified.

## What was changed in this update
| Area | Result |
|---|---|
| Persistence | `VITE_USE_MOCK` now defaults to **off**. Routes, stops, buses, schedules, profiles and passwords all live in PostgreSQL. (Routes/stops "disappearing" came from the old default of sample-data mode.) Student stop dropdowns also read the database now. |
| Route numbers | Routes have a real, editable **route code** (R-101). Searching "R-101", "r101" or "r 101" finds it. |
| Welcome / Login / Sign Up | One full-screen welcome page. Login and Sign Up slide the brand panel to the left and the form in from the right (CSS transitions, no reload). Also forgot-password, reset-password and email-confirmation screens. |
| Accounts | Real sign-up (hashed password, student role forced), login by email or Student ID, profile edit (name, phone, department, default stop, email), password change, password reset by email, email confirmation, "sign out of all devices". Changing a password signs out other devices. |
| Settings (both roles) | Profile, Theme (Light / Dark / System, saved to the account), Password & Security, About, Sign out. Admins also get **Campus** (college and front-gate location). |
| Search | Global search in the navbar for both roles (pages, settings, "Change password", "Sign out"), keyboard friendly, works on mobile. Admin Live Monitoring has a bus search by bus number, route code, route name, **number plate**, location or status. |
| Student dashboard | Full-width grid: bus status + ETA, service overview, big live map, route information, quick actions, and a **notifications panel on the right** that scrolls on its own and drops below the content on small screens. |
| Bus Locations (student) | Every bus on one map with coordinates, status, speed, last-updated (ticking), next stop, **distance from the college front gate** and ETA to college. Idle buses show where they were last seen. |
| Live data honesty | If the WebSocket drops, pages show "Showing the last known positions" instead of "Live", and each bus shows "updated 42 s ago". After 2 minutes without a fix a bus is Offline. |
| Admin Live Monitoring | Plate, speed, ETA, last-updated columns; the table, markers and times change as positions arrive. |

## Email (real)
Set in `backend/.env`: `EMAIL_HOST, EMAIL_PORT, EMAIL_USERNAME, EMAIL_PASSWORD, EMAIL_FROM, FRONTEND_URL` (and `EMAIL_VERIFICATION_REQUIRED=true` to block sign-in until confirmed, `ALLOWED_EMAIL_DOMAINS=college.edu` to accept only college addresses). With `EMAIL_HOST` empty (development), confirmation and reset links are **printed in the server log** instead of sent. Reset links are single-use, expire in 30 minutes, and only a hash of each token is stored. The forgot-password form answers identically whether or not an account exists, and sign-in, sign-up and reset are rate limited. Nothing secret is in the frontend; only `VITE_*` values are.

## Live GPS test (no phone needed)
Admin > Trip Control > pick a bus > tick "Simulate movement" > START TRIP. Watch Student > Bus Locations, Live Tracking, or Admin > Live Monitoring. Real phones need the app served over HTTPS. Positions, speed and stop visits are saved; the ETA model (Admin > Analytics) trains from them.

## Tests
`cd backend && for t in tests/test_*.py; do python $t; done` (needs numpy, pandas, scikit-learn, joblib, PyJWT; bcrypt/dotenv optional for the tests). The frontend logic checks (search, live data, password rules) are plain Node scripts described in the change notes.

## Known limits
- Roads: straight lines between stops. No traffic data.
- Live state lives in one server process: run one worker, or add Redis (Phase 11).
- The in-memory rate limiter is per process; production should also limit at the reverse proxy.
- Behind a proxy, make sure the real client IP reaches the app (rate limits are per IP).
- Schema upgrades are handled by a small start-up migration (`app/migrate.py`); full Alembic migrations are still to do.

---

## Driver QR codes: bus location from the driver's phone (new)
Admins get one **permanent QR per bus/driver** (sidebar → **Driver QR**). The driver scans it once with the phone camera; a page opens in the phone's browser (no app). The driver reads what is shared, ticks the consent box, presses **Share My Location**, allows location in the browser, checks the preview and presses **Start sharing bus location**. The phone's GPS then becomes that bus's live position through the same pipeline as the Trip Control simulator, so Live Monitoring, student Bus Locations / Live Tracking, ETAs, delay notices and analytics all work unchanged. **Stop sharing and end trip** ends it. Students have no part in this feature.

Nothing is collected before consent, IP addresses are never used as a location, and the QR holds only a link (no password, JWT or personal data).

### Admin side
`Driver QR` lists every bus with its route, driver name and phone status: *No QR yet*, *Waiting for driver*, *Sharing now*, *Paused (no recent location)*, *Stopped by driver*, *Permission denied*. "Sharing now" is shown only while positions are actually arriving. From a bus you can create the QR, name the driver, **download the PNG**, copy the link, **Regenerate** (a lost or shared QR stops working at once) or **Remove access**.

### Driver side (`/driver/<token>`)
Explanation, consent checkbox, **Share My Location** / **Decline**, browser permission, preview (map, latitude, longitude, accuracy, time) that is still only on the phone, then **Start sharing bus location**. While sharing: last sent time, update count, offline warning, and the screen is asked to stay on (Wake Lock, where the browser allows). Handled with plain messages: permission denied (with how to switch it back on), GPS unavailable, timeout, unsupported or non-HTTPS browser, invalid or removed QR, lost internet, unreachable server, trip ended by the office, a bus that is inactive or has no route.

### Setup (Windows, PowerShell, two terminals)
Terminal 1: backend
```
docker compose up -d db
cd backend
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env          # set JWT_SECRET; see the DRIVER_* values at the end
python -m app.seed
uvicorn app.main:app --reload
```
Terminal 2: frontend (adds the `qrcode` package)
```
cd frontend
copy .env.example .env
npm install
npm run dev
```
The new table `driver_links` is created when the server starts; existing data is untouched (`backend/sql/driver_links.sql` has the same schema). If you tried the earlier student-sharing version, start-up also drops its three unused `share_*` tables.

### Test with two devices
Phones only give GPS to **HTTPS** pages, so `http://192.168.x.x:5173` will not work. Use a tunnel:
1. Start both servers. Make sure the bus you will use is **Active** and has a **route with at least two stops** (the seed data does).
2. In a third terminal: `cloudflared tunnel --url http://localhost:5173` (or `ngrok http 5173`). Copy the `https://…` address.
3. Put it in `backend/.env` as `DRIVER_LINK_BASE_URL=https://…` and restart the backend. If Vite rejects the tunnel host, add `server.allowedHosts: true` to `frontend/vite.config.js` for the test.
4. On the computer sign in as admin → **Driver QR** → *Create QR* for a bus, leave the QR on screen. Open **Live Monitoring** in another tab.
5. Scan the QR with the phone, tick the box, **Share My Location**, allow, **Start sharing bus location**. The bus appears and moves on Live Monitoring and on the student map.
No second phone? Open the copied link in another browser profile; desktop browsers can share location too.

### API (all under `/api`, JSON)
Admin (Bearer JWT, admin only):

| Method and path | Purpose |
|---|---|
| `GET /driver-links` | Every bus with its QR link (if any), driver name, state, last location time, `share_url` |
| `PUT /driver-links/{bus_id}` `{driver_name?}` | Create the bus's QR, or update the driver's name |
| `POST /driver-links/{bus_id}/regenerate` | New QR; the old one stops working, the driver must agree again |
| `DELETE /driver-links/{bus_id}` | Remove the driver's access |

Driver's phone (no account; the QR token is the credential; the device key goes in header `X-Device-Key`):

| Method and path | Purpose |
|---|---|
| `GET /driver/{token}` | Bus, route, driver name, state. `404` with `{detail, code:"invalid"}` for unknown or removed QRs |
| `POST /driver/{token}/consent` `{granted}` | Record yes/no from the phone. Yes returns a `device_key` |
| `POST /driver/{token}/start` | Start the bus's trip (same checks as Trip Control) or continue an open one |
| `POST /driver/{token}/location` `{latitude, longitude, speed?, timestamp?}` | One GPS fix, fed into live tracking |
| `POST /driver/{token}/stop` | End the trip |

### Security and privacy design
- Only a hash of the link token is used for lookup; the token is derived with HMAC-SHA256 from a random per-bus nonce (`DRIVER_TOKEN_SECRET`, defaults to `JWT_SECRET`; changing it invalidates every printed QR). Unknown, malformed and removed tokens all return the same message.
- Consent is recorded server-side before anything is accepted. The consenting phone gets a random device key (only its hash is stored). Somebody who just photographs the QR cannot inject positions while the driver is live; if the driver's phone goes quiet for `STALE_SECONDS`, a new phone can take over.
- Positions are range-checked (NaN and infinity rejected) and go through the existing tracking limits (`MIN_UPDATE_INTERVAL_S`). Rate limits on view, consent, start and stop (per IP, roomy for a shared campus Wi-Fi). Admin endpoints are admin-only.
- Only the bus's position is used, and only while the driver shares. It is stored like any bus position in `bus_locations` (needed for stop visits and the ETA model); no phone identifiers or IP-based locations are kept.

### Production notes
- Serve everything over **HTTPS** and set `DRIVER_LINK_BASE_URL=https://your-domain` (the server refuses to start in production otherwise).
- The reverse proxy must serve `index.html` for unknown paths such as `/driver/<token>` (SPA fallback), keep forwarding `/ws/`, and pass the real client IP.
- Run one backend worker (live bus state is held in memory), or add Redis first.
- The token is part of the URL path, so keep access logs for `/api/driver/*` short-lived.
- Tests: `python tests/test_driver_core.py` (token derivation, state labels, consent and device-key rules).

### Honest limits
Browsers cannot track reliably in the background: updates pause when the page is closed or the phone sleeps, and the admin then sees *Paused*, never *Sharing now*. Accuracy depends on the phone (GPS, Wi-Fi, mobile network). A QR is permanent until regenerated, so treat the printed code like a key.
