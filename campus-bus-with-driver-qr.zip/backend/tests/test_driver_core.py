"""Run with:  cd backend && python tests/test_driver_core.py   (or python -m pytest)"""
import os
import sys
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from app import driver_core as c  # noqa: E402

NOW = datetime(2026, 11, 15, 8, 0, tzinfo=timezone.utc)
STALE = 120


def test_token_is_stable_unpredictable_and_well_formed():
    a, b = c.new_nonce(), c.new_nonce()
    assert a != b and len(a) == 32
    t = c.derive_token("secret", a)
    assert t == c.derive_token("secret", a)           # the admin can re-open the same QR any time
    assert t != c.derive_token("secret", b)           # each driver gets a different QR
    assert t != c.derive_token("other-secret", a)     # a database copy without the secret cannot rebuild QRs
    assert len(t) == 43 and c.token_well_formed(t)
    assert c.hash_token(t) != t and len(c.hash_token(t)) == 64


def test_regenerating_replaces_the_old_qr():
    old = c.derive_token("s", "nonce-one")
    new = c.derive_token("s", c.new_nonce())
    assert old != new and c.hash_token(old) != c.hash_token(new)


def test_garbage_tokens_are_rejected_before_any_lookup():
    for bad in ("", "short", "x" * 44, "x" * 42, "a/b" + "x" * 40, "../etc/passwd", None, "x" * 43 + "\n"):
        assert not c.token_well_formed(bad), bad


def test_admin_sees_sharing_only_while_positions_arrive():
    fresh, old = NOW - timedelta(seconds=10), NOW - timedelta(seconds=300)
    assert c.link_state("waiting", None, NOW, STALE) == "waiting"
    assert c.link_state("active", fresh, NOW, STALE) == "sharing"
    assert c.link_state("active", old, NOW, STALE) == "paused"     # phone locked or page closed: never claim it is live
    assert c.link_state("active", None, NOW, STALE) == "paused"
    assert c.link_state("stopped", fresh, NOW, STALE) == "stopped"
    assert c.link_state("denied", None, NOW, STALE) == "denied"
    assert set(c.STATE_LABELS) == {"waiting", "sharing", "paused", "stopped", "denied"}


def test_a_second_phone_cannot_take_over_a_live_driver_but_can_replace_a_quiet_one():
    fresh, old = NOW - timedelta(seconds=10), NOW - timedelta(seconds=300)
    assert c.consent_allowed("waiting", None, NOW, STALE, False)
    assert c.consent_allowed("stopped", fresh, NOW, STALE, False)
    assert c.consent_allowed("active", fresh, NOW, STALE, True)        # the same phone again
    assert not c.consent_allowed("active", fresh, NOW, STALE, False)   # someone with a photo of the QR, while the driver is live
    assert c.consent_allowed("active", old, NOW, STALE, False)         # driver's phone died: a new phone may continue


def test_locations_need_consent_and_the_consenting_phone():
    assert c.may_send("active", True)
    assert not c.may_send("active", False)    # only the QR, no device key
    assert not c.may_send("waiting", True)    # never before consent
    assert not c.may_send("denied", True)
    assert not c.may_send("stopped", True)


def test_device_keys():
    assert c.same_secret("abc", "abc") and not c.same_secret("abc", "abd")
    assert not c.same_secret(None, "abc") and not c.same_secret("abc", None) and not c.same_secret("", "")
    assert c.new_device_key() != c.new_device_key()


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn(); print("PASS", name)
