"""Driver QR links: one permanent QR per bus. The driver scans it, agrees on their own phone, and the phone's GPS becomes the bus position.

  admin   GET /api/driver-links, PUT /api/driver-links/{bus_id}, POST .../regenerate, DELETE /api/driver-links/{bus_id}
  driver  GET /api/driver/{token}, POST .../consent, .../start, .../location, .../stop      (no account; the QR token is the credential)

Positions go through the same pipeline as the admin GPS simulator (tracking.ingest_fix), so Live Monitoring, student Bus Locations,
ETAs and analytics all work unchanged. Nothing is accepted before the driver has agreed on their phone.
"""
import logging
import time
import types
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload
from starlette.concurrency import run_in_threadpool

from .. import config, driver_core as core, ratelimit
from ..database import SessionLocal, get_db
from ..deps import require_admin
from ..models import Bus, DriverLink, Trip, User
from ..schemas import DriverConsentIn, DriverFixIn, DriverLinkIn
from ..tracking import manager
from .tracking import _end_trip, _start_trip, build_state, ingest_fix

log = logging.getLogger("driver-link")
router = APIRouter(prefix="/driver-links", tags=["driver QR (admin)"])
public_router = APIRouter(prefix="/driver", tags=["driver QR (driver's phone)"])

INVALID = "This QR code is not valid any more. Ask the transport office for a new one."
TOO_MANY = "Too many requests. Please wait a moment and try again."
MESSAGES = {
    "in_use": "Another phone is sharing this bus's location right now. Ask the transport office if you need to switch phones.",
    "not_sharing": "Location sharing has not been started on this phone. Press Share My Location first.",
    "no_trip": "The trip for this bus was ended by the transport office, so nothing more is being sent.",
}


class DriverLinkError(Exception):
    """Rendered by the handler registered in main.py as {detail, code}, so the driver page can show a friendly state."""

    def __init__(self, status: int, code: str, message: str | None = None):
        self.status, self.code, self.message = status, code, message or MESSAGES.get(code, INVALID)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _aware(dt: datetime | None) -> datetime | None:
    return dt if dt is None or dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def _iso(dt: datetime | None) -> str | None:
    return _aware(dt).astimezone(timezone.utc).isoformat() if dt else None


def _ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"


# ------------------------------------------------------------ admin API
def _link_out(link: DriverLink, now: datetime) -> dict:
    state = core.link_state(link.status, _aware(link.last_seen_at), now, config.STALE_SECONDS)
    token = core.derive_token(config.DRIVER_TOKEN_SECRET, link.nonce)
    return {"id": link.id, "driver_name": link.driver_name, "state": state, "state_label": core.STATE_LABELS[state],
            "created_at": _iso(link.created_at), "consented_at": _iso(link.consented_at), "stopped_at": _iso(link.stopped_at),
            "last_seen_at": _iso(link.last_seen_at), "share_url": f"{config.DRIVER_LINK_BASE_URL}/driver/{token}"}


def _row_out(bus: Bus, link: DriverLink | None, now: datetime) -> dict:
    return {"bus_id": bus.id, "bus_number": bus.bus_number, "registration_number": bus.registration_number, "bus_status": bus.status,
            "route_code": bus.route.code if bus.route else None, "route_name": bus.route.route_name if bus.route else None,
            "link": _link_out(link, now) if link else None}


def _one(db: Session, bus_id: int) -> dict:
    row = db.execute(select(Bus, DriverLink).outerjoin(DriverLink, DriverLink.bus_id == Bus.id).options(joinedload(Bus.route)).where(Bus.id == bus_id)).first()
    if row is None:
        raise HTTPException(404, "Bus not found.")
    return _row_out(row[0], row[1], _now())


@router.get("")
def list_links(_: User = Depends(require_admin), db: Session = Depends(get_db)):
    rows = db.execute(select(Bus, DriverLink).outerjoin(DriverLink, DriverLink.bus_id == Bus.id).options(joinedload(Bus.route)).order_by(Bus.bus_number)).all()
    now = _now()
    return [_row_out(b, l, now) for b, l in rows]


@router.put("/{bus_id}")
def save_link(bus_id: int, data: DriverLinkIn, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    """Creates the bus's QR link if it has none, otherwise just updates the driver's name. Safe to call twice."""
    if db.get(Bus, bus_id) is None:
        raise HTTPException(404, "Bus not found.")
    link = db.scalar(select(DriverLink).where(DriverLink.bus_id == bus_id))
    if link is None:
        nonce = core.new_nonce()
        link = DriverLink(bus_id=bus_id, created_by=admin.id, nonce=nonce, status="waiting",
                          token_hash=core.hash_token(core.derive_token(config.DRIVER_TOKEN_SECRET, nonce)))
        db.add(link)
    link.driver_name = data.driver_name or None
    db.commit()
    return _one(db, bus_id)


@router.post("/{bus_id}/regenerate")
def regenerate_link(bus_id: int, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    """Use when a QR was lost or shared by mistake: the old QR stops working at once and the driver must scan the new one."""
    link = db.scalar(select(DriverLink).where(DriverLink.bus_id == bus_id))
    if link is None:
        raise HTTPException(404, "This bus has no QR code yet.")
    link.nonce = core.new_nonce()
    link.token_hash = core.hash_token(core.derive_token(config.DRIVER_TOKEN_SECRET, link.nonce))
    link.status, link.consented_at, link.stopped_at, link.last_seen_at, link.device_key_hash = "waiting", None, None, None, None
    link.created_by = admin.id
    db.commit()
    return _one(db, bus_id)


@router.delete("/{bus_id}", status_code=204)
def remove_link(bus_id: int, _: User = Depends(require_admin), db: Session = Depends(get_db)):
    """Withdraws the driver's access. A trip already running is left to the admin (Trip Control) and goes Offline when positions stop."""
    link = db.scalar(select(DriverLink).where(DriverLink.bus_id == bus_id))
    if link is None:
        raise HTTPException(404, "This bus has no QR code.")
    db.delete(link)
    db.commit()


# ------------------------------------------------------------ driver's phone
def _by_token(db: Session, token: str) -> DriverLink:
    if not core.token_well_formed(token):
        raise DriverLinkError(404, "invalid")
    link = db.scalar(select(DriverLink).options(joinedload(DriverLink.bus).joinedload(Bus.route)).where(DriverLink.token_hash == core.hash_token(token)))
    if link is None:
        raise DriverLinkError(404, "invalid")  # unknown, malformed and removed links all look the same
    return link


def _key_ok(link: DriverLink, key: str | None) -> bool:
    return bool(key and link.device_key_hash and core.same_secret(core.hash_token(key), link.device_key_hash))


def _open_trip_id(db: Session, bus_id: int) -> int | None:
    return db.scalar(select(Trip.id).where(Trip.bus_id == bus_id, Trip.ended_at.is_(None)))


def _view(link: DriverLink, db: Session, now: datetime) -> dict:
    bus = link.bus
    return {"bus_number": bus.bus_number, "route_name": bus.route.route_name if bus.route else None, "driver_name": link.driver_name,
            "state": core.link_state(link.status, _aware(link.last_seen_at), now, config.STALE_SECONDS),
            "trip_active": _open_trip_id(db, bus.id) is not None, "min_interval_s": config.MIN_UPDATE_INTERVAL_S}


@public_router.get("/{token}")
def view_link(token: str, request: Request, db: Session = Depends(get_db)):
    """What the driver's page shows before anything is shared. No location is involved."""
    if not ratelimit.allow(f"driver-view:{_ip(request)}", 200, 600):
        raise HTTPException(429, TOO_MANY)
    return _view(_by_token(db, token), db, _now())


@public_router.post("/{token}/consent")
def record_consent(token: str, data: DriverConsentIn, request: Request, x_device_key: str | None = Header(default=None, max_length=100), db: Session = Depends(get_db)):
    """Called from the driver's own phone after they ticked the box and the browser allowed location (granted=true), or after they declined or
    the browser refused (granted=false). Records the answer only; no position is stored here and no trip is started."""
    if not ratelimit.allow(f"driver-consent:{_ip(request)}", 60, 600):
        raise HTTPException(429, TOO_MANY)
    link = _by_token(db, token)
    now = _now()
    if not core.consent_allowed(link.status, _aware(link.last_seen_at), now, config.STALE_SECONDS, _key_ok(link, x_device_key)):
        raise DriverLinkError(409, "in_use")
    out = None
    if data.granted:
        key = core.new_device_key()
        link.status, link.consented_at, link.stopped_at, link.last_seen_at, link.device_key_hash = "active", now, None, now, core.hash_token(key)
        out = key
    else:
        link.status, link.device_key_hash = "denied", None
    db.commit()
    view = _view(link, db, now)
    if out:
        view["device_key"] = out
    return view


def _ensure_trip(link_id: int, bus_id: int, created_by: int | None) -> dict:
    """Start the bus's trip (same checks as Trip Control) or carry on with one that is already open."""
    with SessionLocal() as db:
        trip_id = _open_trip_id(db, bus_id)
        if trip_id is None:
            started = _start_trip(db, bus_id, types.SimpleNamespace(id=created_by))  # raises 400 with a plain message if the bus is inactive or has no route
            return {"trip_id": started["trip_id"], "bus_number": started["bus_number"]}
        bus = db.get(Bus, bus_id)
        if bus_id not in manager.states:  # open trip but no live state (e.g. after a restart): rebuild it
            trip = db.get(Trip, trip_id)
            state = build_state(db, bus, trip)
            if state is None:
                raise HTTPException(400, "This bus's route needs at least two stops.")
            manager.states[bus_id] = state
        return {"trip_id": trip_id, "bus_number": bus.bus_number}


def _check_key(db: Session, token: str, key: str | None) -> DriverLink:
    link = _by_token(db, token)
    if not core.may_send(link.status, _key_ok(link, key)):
        raise DriverLinkError(403, "not_sharing")
    return link


@public_router.post("/{token}/start", status_code=201)
async def start_sharing(token: str, request: Request, x_device_key: str | None = Header(default=None, max_length=100), db: Session = Depends(get_db)):
    """After consent: the bus's trip starts, so students see it on the map."""
    if not ratelimit.allow(f"driver-start:{_ip(request)}", 60, 600):
        raise HTTPException(429, TOO_MANY)
    link = await run_in_threadpool(_check_key, db, token, x_device_key)
    return await run_in_threadpool(_ensure_trip, link.id, link.bus_id, link.created_by)


_last_touch: dict[int, float] = {}


def _touch(link_id: int, now: datetime) -> None:
    with SessionLocal() as db:
        link = db.get(DriverLink, link_id)
        if link:
            link.last_seen_at = now
            db.commit()


@public_router.post("/{token}/location")
async def receive_location(token: str, data: DriverFixIn, x_device_key: str | None = Header(default=None, max_length=100), db: Session = Depends(get_db)):
    link = await run_in_threadpool(_check_key, db, token, x_device_key)
    err = await ingest_fix(link.bus_id, data.model_dump(exclude_none=True))
    if err:
        raise DriverLinkError(409, "no_trip" if err.startswith("No active trip") else "not_sharing", MESSAGES["no_trip"] if err.startswith("No active trip") else err)
    mono = time.monotonic()
    if mono - _last_touch.get(link.id, 0) >= 10:  # "last seen" is saved every 10 s, not on every fix
        _last_touch[link.id] = mono
        await run_in_threadpool(_touch, link.id, _now())
    return {"ok": True}


def _finish(link_id: int, bus_id: int) -> tuple[int | None, str | None]:
    with SessionLocal() as db:
        link = db.get(DriverLink, link_id)
        link.status, link.stopped_at = "stopped", _now()
        trip_id = _open_trip_id(db, bus_id)
        number = None
        if trip_id is not None:
            _end_trip(db, trip_id)
            number = db.get(Bus, bus_id).bus_number
        db.commit()
        return trip_id, number


@public_router.post("/{token}/stop")
async def stop_sharing(token: str, request: Request, x_device_key: str | None = Header(default=None, max_length=100), db: Session = Depends(get_db)):
    """The driver ends the trip: the bus stops showing as running."""
    if not ratelimit.allow(f"driver-stop:{_ip(request)}", 60, 600):
        raise HTTPException(429, TOO_MANY)
    link = await run_in_threadpool(_check_key, db, token, x_device_key)
    trip_id, number = await run_in_threadpool(_finish, link.id, link.bus_id)
    if trip_id is not None:
        manager.states.pop(link.bus_id, None)
        await manager.broadcast({"type": "trip_ended", "bus_id": link.bus_id, "bus_number": number}, link.bus_id)
    return {"state": "stopped"}
