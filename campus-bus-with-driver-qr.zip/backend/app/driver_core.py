"""Pure rules for driver QR links. No database or web framework in here, so it is easy to test.

One QR per bus/driver, valid until the admin regenerates or removes it.
  * The link token is HMAC-SHA256(secret, nonce) of a random per-link nonce. Only sha256(token) is used for lookup, so a copy of
    the database cannot be turned into working links; the admin can still re-open the QR because the server can re-derive the token.
  * The QR holds only the link: no password, no sign-in token, nothing personal.
  * The driver's phone must tick consent and allow location in its browser. It then receives a random device key (only the hash is
    stored) that every location update must carry. Somebody who merely photographs the QR cannot feed positions in while the driver
    is sharing; if the driver's phone goes quiet, a new phone can take over.
"""
import base64
import hashlib
import hmac
import re
import secrets
from datetime import datetime

TOKEN_RE = re.compile(r"^[A-Za-z0-9_-]{43}$")
STORED_STATUSES = ("waiting", "active", "stopped", "denied")
STATE_LABELS = {
    "waiting": "Waiting for driver",
    "sharing": "Sharing now",
    "paused": "Paused (no recent location)",
    "stopped": "Stopped by driver",
    "denied": "Permission denied",
}


def new_nonce() -> str:
    return secrets.token_hex(16)


def derive_token(secret: str, nonce: str) -> str:
    digest = hmac.new(secret.encode(), f"driver-link:{nonce}".encode(), hashlib.sha256).digest()
    return base64.urlsafe_b64encode(digest).decode().rstrip("=")  # 43 characters


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def token_well_formed(token: str) -> bool:
    return bool(TOKEN_RE.fullmatch(token or ""))


def new_device_key() -> str:
    return secrets.token_urlsafe(32)


def same_secret(a: str | None, b: str | None) -> bool:
    return bool(a) and bool(b) and hmac.compare_digest(a.encode(), b.encode())


def is_fresh(last_seen: datetime | None, now: datetime, stale_s: float) -> bool:
    return last_seen is not None and (now - last_seen).total_seconds() < stale_s


def link_state(status: str, last_seen: datetime | None, now: datetime, stale_s: float) -> str:
    """What the admin sees. 'sharing' only while location is actually arriving; a phone that went quiet shows as paused."""
    if status == "active":
        return "sharing" if is_fresh(last_seen, now, stale_s) else "paused"
    return status


def consent_allowed(status: str, last_seen: datetime | None, now: datetime, stale_s: float, key_matches: bool) -> bool:
    """May this phone record consent? Yes unless another phone is actively sharing right now."""
    return status != "active" or key_matches or not is_fresh(last_seen, now, stale_s)


def may_send(status: str, key_matches: bool) -> bool:
    return status == "active" and key_matches
