-- Driver QR links: one permanent QR per bus. The server creates this table itself on start-up (Base.metadata.create_all);
-- this file is the same schema for people who prefer to review or apply it by hand:  psql -d campus_bus -f sql/driver_links.sql
CREATE TABLE IF NOT EXISTS driver_links (
    id              SERIAL PRIMARY KEY,
    bus_id          INTEGER NOT NULL UNIQUE REFERENCES buses (id) ON DELETE CASCADE,
    created_by      INTEGER REFERENCES users (id) ON DELETE SET NULL,
    driver_name     VARCHAR(120),
    nonce           VARCHAR(32) NOT NULL,            -- the link token is derived from this; the token itself is never stored
    token_hash      VARCHAR(64) NOT NULL UNIQUE,     -- sha256 of the token
    status          VARCHAR(10) NOT NULL DEFAULT 'waiting',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    consented_at    TIMESTAMPTZ,
    stopped_at      TIMESTAMPTZ,
    last_seen_at    TIMESTAMPTZ,
    device_key_hash VARCHAR(64),                     -- ties location updates to the phone that agreed
    CONSTRAINT ck_driver_links_status CHECK (status IN ('waiting','active','stopped','denied'))
);

-- Only if you ran the earlier student-sharing version of this feature (it was removed):
-- DROP TABLE IF EXISTS share_locations, share_consents, share_sessions;
