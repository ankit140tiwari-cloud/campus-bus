# Driver QR codes: files added or changed
(The earlier student-sharing version of this feature has been removed.)

New backend
- backend/app/driver_core.py              pure rules (tokens, state, consent, device key)
- backend/app/routers/driver_link.py      admin API + the driver's phone API
- backend/sql/driver_links.sql, backend/tests/test_driver_core.py

Changed backend
- backend/app/routers/tracking.py   the "apply one GPS fix" part is now ingest_fix(), used by the simulator socket and the driver link (behaviour unchanged)
- backend/app/models.py (DriverLink)  schemas.py  config.py  main.py  migrate.py (drops the old share_* tables)  .env.example

New frontend
- src/pages/admin/DriverQr.jsx            admin page: QR per bus
- src/pages/public/DriverPage.jsx         page the QR opens on the driver's phone
- src/components/QrCard.jsx, ShareMap.jsx, src/services/driverLinkService.js, src/utils/driverQr.js

Changed frontend
- src/App.jsx (routes)  src/utils/constants.js (admin sidebar item "Driver QR"; nothing added for students)  src/hooks/useAsync.js  package.json (adds "qrcode")

Docs: README.md (last section)
