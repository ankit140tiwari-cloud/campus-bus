import { api } from './api';

const BASE = import.meta.env.VITE_API_URL || '/api';

// ---- admin (signed in) ----
export const listDriverLinks = () => api('/driver-links');
export const saveDriverLink = (busId, driverName) => api(`/driver-links/${busId}`, { method: 'PUT', body: { driver_name: driverName || null } });
export const regenerateDriverLink = (busId) => api(`/driver-links/${busId}/regenerate`, { method: 'POST' });
export const removeDriverLink = (busId) => api(`/driver-links/${busId}`, { method: 'DELETE' });

// ---- the driver's phone (no account): never sends the admin JWT, never redirects to /login ----
// Resolves to { ok, status, data, code, message } and never throws, so the page can show a friendly state for every outcome.
async function call(path, { method = 'GET', body, key } = {}) {
  const headers = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (key) headers['X-Device-Key'] = key;
  try {
    const res = await fetch(`${BASE}/driver/${path}`, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
    const data = await res.json().catch(() => null);
    const message = typeof data?.detail === 'string' ? data.detail : Array.isArray(data?.detail) ? 'That position was not accepted.' : null;
    return { ok: res.ok, status: res.status, data, code: data?.code || null, message };
  } catch {
    return { ok: false, status: 0, data: null, code: 'network', message: 'No internet connection, or the server cannot be reached.' };
  }
}

export const driverView = (token) => call(token);
export const driverConsent = (token, granted, key) => call(`${token}/consent`, { method: 'POST', body: { granted }, key });
export const driverStart = (token, key) => call(`${token}/start`, { method: 'POST', key });
export const driverSend = (token, fix, key) => call(`${token}/location`, { method: 'POST', body: fix, key });
export const driverStop = (token, key) => call(`${token}/stop`, { method: 'POST', key });
