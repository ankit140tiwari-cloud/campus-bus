import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import { AlertTriangle, CheckCircle2, Info, Loader2, LocateFixed, ShieldCheck, WifiOff, XCircle } from 'lucide-react';
import { driverConsent, driverSend, driverStart, driverStop, driverView } from '../../services/driverLinkService';
import { fmtAccuracy, fmtCoord, fmtTime } from '../../utils/driverQr';
import { APP_NAME } from '../../utils/constants';
import Logo from '../../components/Logo';
import Card from '../../components/Card';
import Button from '../../components/Button';
import ShareMap from '../../components/ShareMap';

const keyName = (t) => `driver-key:${t}`;
const readKey = (t) => { try { return sessionStorage.getItem(keyName(t)); } catch { return null; } };
const saveKey = (t, k) => { try { sessionStorage.setItem(keyName(t), k); } catch { /* private mode: the key stays in memory only */ } };

const GEO_HELP = {
  1: 'Your browser blocked location for this page, so nothing was shared. To change that: on iPhone open Settings → Privacy & Security → Location Services → Safari Websites; on Android tap the lock icon next to the address, then Permissions → Location. Then try again.',
  2: 'Your phone could not work out where it is. Check that Location is switched on in your phone settings, move to a place with a clearer view of the sky and try again.',
  3: 'Finding your location took too long. Check that Location is switched on, move near a window or outside, and try again.',
};
const SEND_GAP_MS = 3000;
const toFix = (pos) => ({
  latitude: pos.coords.latitude, longitude: pos.coords.longitude, accuracy: Number.isFinite(pos.coords.accuracy) ? pos.coords.accuracy : null,
  speed: Number.isFinite(pos.coords.speed) && pos.coords.speed >= 0 ? pos.coords.speed : null, at: pos.timestamp,
});

function Shell({ children }) {
  return (
    <div className="min-h-full bg-slate-50 px-4 pt-6" style={{ paddingBottom: 'calc(2.5rem + env(safe-area-inset-bottom, 0px))' }}>
      <div className="mx-auto max-w-md space-y-4">
        <Logo />
        {children}
        <p className="text-center text-xs text-slate-500">{APP_NAME} · sharing is always your choice and you can stop at any time</p>
      </div>
    </div>
  );
}

const Message = ({ icon: Icon, tone = 'text-slate-400', title, text, children }) => (
  <Card>
    <div className="flex flex-col items-center gap-2 py-6 text-center" role="status">
      <Icon size={36} className={tone} aria-hidden />
      <h1 className="text-lg font-bold text-slate-900">{title}</h1>
      <p className="max-w-xs text-sm text-slate-600">{text}</p>
      {children}
    </div>
  </Card>
);

export default function DriverPage() {
  const { token } = useParams();
  const [phase, setPhase] = useState('loading'); // loading | intro | locating | preview | sharing | ended | declined | dead | error
  const [info, setInfo] = useState(null);
  const [deadText, setDeadText] = useState('');
  const [notice, setNotice] = useState('');
  const [agree, setAgree] = useState(false);
  const [fix, setFix] = useState(null);
  const [lastSent, setLastSent] = useState(null);
  const [sent, setSent] = useState(0);
  const [offline, setOffline] = useState(false);
  const [busy, setBusy] = useState(false);

  const keyRef = useRef(readKey(token));
  const watchRef = useRef(null);
  const lastPush = useRef(0);
  const inflight = useRef(false);
  const wake = useRef(null);
  const supported = typeof navigator !== 'undefined' && 'geolocation' in navigator;
  const secure = typeof window === 'undefined' || window.isSecureContext;

  const stopWatch = useCallback(() => {
    if (watchRef.current != null) { navigator.geolocation.clearWatch(watchRef.current); watchRef.current = null; }
    try { wake.current?.release(); } catch { /* ignore */ }
    wake.current = null;
  }, []);

  const load = useCallback(async () => {
    setPhase('loading');
    const r = await driverView(token);
    if (r.ok) { setInfo(r.data); setPhase('intro'); return; }
    if (r.code === 'network' || r.status === 0 || r.status >= 500 || r.status === 429) { setNotice(r.message || 'Could not reach the server.'); setPhase('error'); return; }
    setDeadText(r.message); setPhase('dead');
  }, [token]);
  useEffect(() => { load(); return stopWatch; }, [load, stopWatch]);

  // the server says this phone may no longer send (trip ended by the office, QR regenerated, another phone took over)
  const finish = useCallback((r) => {
    stopWatch();
    if (r.code === 'no_trip') { setDeadText(r.message); setPhase('ended'); return; }
    if (r.code === 'invalid') { setDeadText(r.message); setPhase('dead'); return; }
    setNotice(r.message || 'Sharing could not continue.'); setPhase('intro');
  }, [stopWatch]);

  const push = useCallback(async (f) => {
    if (inflight.current) return null;
    inflight.current = true; lastPush.current = Date.now();
    const r = await driverSend(token, { latitude: f.latitude, longitude: f.longitude, speed: f.speed, timestamp: f.at }, keyRef.current);
    inflight.current = false;
    if (r.ok) { setLastSent(Date.now()); setSent((n) => n + 1); setOffline(false); return r; }
    if (r.code === 'network' || r.status === 0) { setOffline(true); return r; }
    if (r.status === 429) return r;
    finish(r);
    return r;
  }, [token, finish]);

  const startWatch = useCallback(() => {
    if (watchRef.current != null) return;
    watchRef.current = navigator.geolocation.watchPosition(
      (pos) => { const f = toFix(pos); setFix(f); if (Date.now() - lastPush.current >= SEND_GAP_MS) push(f); },
      (err) => { setNotice(GEO_HELP[err.code] || 'Location updates paused.'); },
      { enableHighAccuracy: true, maximumAge: 2000, timeout: 30000 },
    );
    // Best effort: ask the phone to keep the screen on, since a sleeping page stops sending. Not available everywhere.
    navigator.wakeLock?.request('screen').then((l) => { wake.current = l; }).catch(() => {});
  }, [push]);

  // a wake lock is dropped when the page is hidden; take it again when the driver comes back
  useEffect(() => {
    const again = () => { if (document.visibilityState === 'visible' && watchRef.current != null) navigator.wakeLock?.request('screen').then((l) => { wake.current = l; }).catch(() => {}); };
    document.addEventListener('visibilitychange', again);
    return () => document.removeEventListener('visibilitychange', again);
  }, []);

  // 1) ask the browser for permission and read the position. Nothing is sent to anyone yet.
  const requestLocation = () => {
    setNotice(''); setPhase('locating');
    navigator.geolocation.getCurrentPosition(
      (pos) => { setFix(toFix(pos)); setPhase('preview'); },
      async (err) => {
        setPhase('intro'); setNotice(GEO_HELP[err.code] || 'Could not get your location.');
        if (err.code === 1) await driverConsent(token, false, keyRef.current); // tells the office "permission denied"; no location is involved
      },
      { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 },
    );
  };

  // 2) the driver has seen the position and confirms: record consent, start the trip, send, keep sending
  const confirmShare = async () => {
    setBusy(true); setNotice('');
    const c = await driverConsent(token, true, keyRef.current);
    if (!c.ok) { setBusy(false); if (c.code === 'network' || c.status === 0) setNotice(c.message); else finish(c); return; }
    keyRef.current = c.data.device_key; saveKey(token, c.data.device_key);
    const s = await driverStart(token, keyRef.current);
    if (!s.ok) {
      setBusy(false);
      if (s.code === 'network' || s.status === 0) setNotice(s.message); else if (s.status === 400 || s.status === 409) setNotice(s.message); else finish(s);
      return;
    }
    setSent(0); setLastSent(null);
    await push(fix);
    setBusy(false); setPhase('sharing'); startWatch();
  };

  const decline = async () => { setBusy(true); await driverConsent(token, false, keyRef.current); setBusy(false); setPhase('declined'); };
  const stop = async () => { setBusy(true); stopWatch(); await driverStop(token, keyRef.current); setBusy(false); setPhase('ended'); setDeadText(''); };
  const restart = () => { setAgree(false); setNotice(''); setFix(null); setPhase('intro'); };

  const point = useMemo(() => (fix ? [{ id: 'bus', lat: fix.latitude, lng: fix.longitude, accuracy: fix.accuracy, label: info?.bus_number || 'Bus', detail: 'This phone' }] : []), [fix, info]);

  if (phase === 'loading') return <Shell><Card><p className="flex items-center justify-center gap-2 py-8 text-sm text-slate-500" role="status"><Loader2 className="animate-spin" size={18} aria-hidden /> Checking this QR code…</p></Card></Shell>;
  if (phase === 'dead') return <Shell><Message icon={XCircle} title="QR code not valid" text={deadText} /></Shell>;
  if (phase === 'error') return <Shell><Message icon={WifiOff} title="Cannot reach the server" text={`${notice} Check your internet connection and try again.`}><Button onClick={load}>Try again</Button></Message></Shell>;
  if (phase === 'ended') return (
    <Shell><Message icon={CheckCircle2} tone="text-green-600" title="Sharing has ended" text={deadText || 'The bus is no longer being tracked from this phone. Closing this page also stops everything.'}>
      <Button variant="secondary" onClick={restart}>Start again</Button></Message></Shell>
  );
  if (phase === 'declined') return (
    <Shell><Message icon={ShieldCheck} tone="text-green-600" title="Nothing was shared" text="You chose not to share. No location was sent. You can close this page."><Button variant="secondary" onClick={restart}>I changed my mind</Button></Message></Shell>
  );

  const sharing = phase === 'sharing';
  return (
    <Shell>
      <Card>
        <p className="text-xs font-semibold uppercase tracking-wide text-brand-600">Bus {info.bus_number}{info.route_name ? ` · ${info.route_name}` : ''}</p>
        <h1 className="mt-1 text-lg font-bold text-slate-900">{sharing ? 'Sharing this bus’s location' : 'Share this bus’s location'}</h1>
        {info.driver_name && <p className="mt-1 text-sm text-slate-600">Driver: {info.driver_name}</p>}

        {notice && <p role="alert" className="mt-3 flex gap-2 rounded-lg bg-amber-50 p-3 text-sm text-amber-800"><AlertTriangle size={16} className="mt-0.5 shrink-0" aria-hidden />{notice}</p>}
        {!supported && <p role="alert" className="mt-3 rounded-lg bg-red-50 p-3 text-sm text-red-700">This browser cannot share location. Open this link in Safari, Chrome or another current browser.</p>}
        {supported && !secure && <p role="alert" className="mt-3 rounded-lg bg-red-50 p-3 text-sm text-red-700">Location only works on secure (HTTPS) pages, and this page is not secure. Ask the transport office for a new QR code.</p>}

        {(phase === 'intro' || phase === 'locating') && (
          <div className="mt-4 space-y-4">
            <ul className="space-y-2 text-sm text-slate-600">
              <li className="flex gap-2"><ShieldCheck size={16} className="mt-0.5 shrink-0 text-green-600" aria-hidden /><span><b>Nothing is shared until you say so.</b> Scanning the QR code did not reveal where you are.</span></li>
              <li className="flex gap-2"><Info size={16} className="mt-0.5 shrink-0 text-brand-600" aria-hidden /><span>While you share, this phone's location is shown as the bus's live position to the transport office and to students tracking the bus.</span></li>
              <li className="flex gap-2"><Info size={16} className="mt-0.5 shrink-0 text-brand-600" aria-hidden /><span>Your browser will ask for permission. You will see your position first, then choose whether to start. <b>Stop</b> ends the trip at any time.</span></li>
              <li className="flex gap-2"><Info size={16} className="mt-0.5 shrink-0 text-brand-600" aria-hidden /><span>Keep this page open with the screen on. A web page cannot reliably track a phone in the background, so updates pause if the page is closed or the phone sleeps. Accuracy depends on GPS, Wi-Fi and mobile signal.</span></li>
            </ul>
            <label className="flex min-h-[44px] cursor-pointer items-start gap-3 rounded-lg border border-slate-200 p-3 text-sm text-slate-800">
              <input type="checkbox" className="mt-0.5 h-5 w-5 shrink-0" checked={agree} onChange={(e) => setAgree(e.target.checked)} />
              <span>I understand, and I agree to share this phone's location as the location of bus <b>{info.bus_number}</b>.</span>
            </label>
            <div className="flex flex-col gap-2">
              <Button onClick={requestLocation} loading={phase === 'locating'} disabled={!agree || !supported || !secure} className="w-full"><LocateFixed size={16} aria-hidden /> Share My Location</Button>
              <Button variant="secondary" onClick={decline} loading={busy} disabled={phase === 'locating'} className="w-full">Decline</Button>
            </div>
          </div>
        )}

        {(phase === 'preview' || sharing) && fix && (
          <div className="mt-4 space-y-4">
            <ShareMap points={point} selectedId="bus" className="h-56" label="This phone's location" />
            <dl className="grid grid-cols-2 gap-3 text-sm">
              <div><dt className="text-xs text-slate-500">Latitude</dt><dd className="font-mono">{fmtCoord(fix.latitude)}</dd></div>
              <div><dt className="text-xs text-slate-500">Longitude</dt><dd className="font-mono">{fmtCoord(fix.longitude)}</dd></div>
              <div><dt className="text-xs text-slate-500">Accuracy</dt><dd>{fmtAccuracy(fix.accuracy)}</dd></div>
              <div><dt className="text-xs text-slate-500">Position read at</dt><dd>{fmtTime(new Date(fix.at).toISOString())}</dd></div>
            </dl>
          </div>
        )}

        {phase === 'preview' && (
          <div className="mt-4 space-y-3">
            <p className="rounded-lg bg-brand-50 p-3 text-sm text-brand-900"><b>This is only on your phone so far.</b> Pressing the button starts bus {info.bus_number}'s trip and sends your position every few seconds.</p>
            <div className="flex flex-col gap-2">
              <Button onClick={confirmShare} loading={busy} className="w-full">Start sharing bus location</Button>
              <Button variant="secondary" onClick={restart} disabled={busy} className="w-full">Cancel, share nothing</Button>
            </div>
          </div>
        )}

        {sharing && (
          <div className="mt-4 space-y-3">
            <p role="status" className="flex gap-2 rounded-lg bg-green-50 p-3 text-sm text-green-700"><CheckCircle2 size={16} className="mt-0.5 shrink-0" aria-hidden />
              <span>Live sharing is on. Last sent {lastSent ? fmtTime(new Date(lastSent).toISOString()) : '—'} · {sent} update{sent === 1 ? '' : 's'} sent.</span></p>
            {offline && <p role="alert" className="flex gap-2 rounded-lg bg-amber-50 p-3 text-sm text-amber-800"><WifiOff size={16} className="mt-0.5 shrink-0" aria-hidden />No connection. Updates are paused and will continue when you are back online.</p>}
            <Button variant="danger" onClick={stop} loading={busy} className="w-full">Stop sharing and end trip</Button>
            <p className="text-xs text-slate-500">Keep this page open and the screen on while driving. Locking the phone or switching apps can pause updates.</p>
          </div>
        )}
      </Card>
    </Shell>
  );
}
