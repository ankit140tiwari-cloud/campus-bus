import { useEffect, useState } from 'react';
import { Link2Off, QrCode, RefreshCw, ShieldCheck } from 'lucide-react';
import useAsync from '../../hooks/useAsync';
import { listDriverLinks, regenerateDriverLink, removeDriverLink, saveDriverLink } from '../../services/driverLinkService';
import { STATE_TONE, fmtDateTime } from '../../utils/driverQr';
import { useToast } from '../../components/Toast';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import Badge from '../../components/Badge';
import Button from '../../components/Button';
import Card from '../../components/Card';
import Input from '../../components/Input';
import Modal from '../../components/Modal';
import QrCard from '../../components/QrCard';
import ConfirmDialog from '../../components/ConfirmDialog';
import EmptyState from '../../components/EmptyState';
import ErrorNote from '../../components/ErrorNote';
import LoadingSkeleton from '../../components/LoadingSkeleton';

export default function DriverQr() {
  const toast = useToast();
  const { data, loading, error, reload, setData } = useAsync(listDriverLinks, []);
  const [openId, setOpenId] = useState(null);   // bus whose QR is shown
  const [confirm, setConfirm] = useState(null); // { kind: 'regen' | 'remove', row }
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);

  // quiet refresh so "Sharing now / Paused" stays current without a spinner
  useEffect(() => {
    const t = setInterval(() => { listDriverLinks().then(setData).catch(() => {}); }, 10000);
    return () => clearInterval(t);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const rows = data || [];
  const row = rows.find((r) => r.bus_id === openId);
  const replace = (updated) => setData((cur) => cur.map((r) => (r.bus_id === updated.bus_id ? updated : r)));

  const run = async (fn, okMsg) => {
    setBusy(true);
    try { const r = await fn(); if (r) replace(r); if (okMsg) toast(okMsg); return true; } catch (e) { toast(e.message, 'error'); return false; } finally { setBusy(false); }
  };

  const open = (r) => { setName(r.link?.driver_name || ''); setOpenId(r.bus_id); };
  const create = async (r) => { if (await run(() => saveDriverLink(r.bus_id, ''), 'QR code created')) { setName(''); setOpenId(r.bus_id); } };
  const saveName = () => run(() => saveDriverLink(row.bus_id, name.trim()), 'Driver name saved');
  const regenerate = async () => { if (await run(() => regenerateDriverLink(confirm.row.bus_id), 'New QR code created. The old one no longer works.')) setConfirm(null); };
  const remove = async () => {
    const id = confirm.row.bus_id;
    setBusy(true);
    try { await removeDriverLink(id); setData((cur) => cur.map((r) => (r.bus_id === id ? { ...r, link: null } : r))); toast('Driver access removed'); setConfirm(null); setOpenId(null); }
    catch (e) { toast(e.message, 'error'); } finally { setBusy(false); }
  };

  const columns = [
    { key: 'bus', label: 'Bus', render: (r) => <span>{r.bus_number}<span className="block text-xs font-normal text-slate-500">{r.registration_number}</span></span> },
    { key: 'route', label: 'Route', render: (r) => (r.route_name ? `${r.route_code} · ${r.route_name}` : 'No route') },
    { key: 'driver', label: 'Driver', render: (r) => r.link?.driver_name || (r.link ? 'Not named' : '—') },
    { key: 'state', label: 'Driver phone', render: (r) => (r.link ? <Badge tone={STATE_TONE[r.link.state] || 'neutral'}>{r.link.state_label}</Badge> : <Badge tone="neutral">No QR yet</Badge>) },
    { key: 'seen', label: 'Last location', render: (r) => (r.link?.last_seen_at ? fmtDateTime(r.link.last_seen_at) : '—') },
    { key: 'actions', label: '', render: (r) => (r.link
      ? <Button variant="secondary" className="!min-h-[36px]" onClick={(e) => { e.stopPropagation(); open(r); }}><QrCode size={14} aria-hidden /> Show QR</Button>
      : <Button className="!min-h-[36px]" loading={busy} onClick={(e) => { e.stopPropagation(); create(r); }}><QrCode size={14} aria-hidden /> Create QR</Button>) },
  ];

  return (
    <div className="space-y-4">
      <PageHeader title="Driver QR codes" subtitle="One permanent QR per bus. The driver scans it once, agrees on their phone, and the phone's GPS becomes the bus's live location." />
      {error && <ErrorNote message={error} onRetry={reload} />}
      {loading && !data ? <LoadingSkeleton rows={3} /> : rows.length === 0
        ? <Card><EmptyState icon={QrCode} title="No buses yet" message="Add a bus first (Admin > Buses), then create its driver QR here." /></Card>
        : <DataTable columns={columns} rows={rows} rowKey="bus_id" onRowClick={(r) => (r.link ? open(r) : null)} />}

      <Card>
        <div className="flex gap-3">
          <ShieldCheck size={20} className="mt-0.5 shrink-0 text-green-600" aria-hidden />
          <div className="space-y-1 text-sm text-slate-600">
            <p className="font-semibold text-slate-900">How it works and what it protects</p>
            <p>The QR only opens a page on the driver's phone. Nothing is sent until the driver ticks the consent box, presses <b>Share My Location</b> and allows location in the browser; they can stop at any time, which ends the trip. The bus appears in Live Monitoring and in the students' bus tracking while the driver shares.</p>
            <p>Updates only arrive while the driver keeps the page open with the screen on: a web page cannot reliably track a phone in the background. If the phone goes quiet the status shows <b>Paused</b>, never Live. If a QR is lost or shared by mistake, <b>Regenerate</b> it: the old one stops working immediately.</p>
          </div>
        </div>
      </Card>

      <Modal open={!!row} title={row ? `${row.bus_number} · driver QR` : ''} onClose={() => setOpenId(null)}>
        {row?.link && (
          <div className="space-y-4">
            <div className="flex items-end gap-2">
              <Input className="flex-1" label="Driver name (optional)" value={name} maxLength={120} onChange={(e) => setName(e.target.value)} placeholder="e.g. Ramesh Kumar" />
              <Button variant="secondary" loading={busy} disabled={name.trim() === (row.link.driver_name || '')} onClick={saveName}>Save</Button>
            </div>
            <QrCard url={row.link.share_url} filename={`driver-qr-${row.bus_number}.png`} title="Scan with the driver's phone" />
            <p className="text-sm text-slate-600">Status: <b>{row.link.state_label}</b>{row.link.consented_at ? ` · driver agreed ${fmtDateTime(row.link.consented_at)}` : ''}. Print it or send the PNG to the driver; they can keep it for every trip.</p>
            <div className="flex flex-col gap-2 sm:flex-row">
              <Button variant="secondary" className="flex-1" onClick={() => setConfirm({ kind: 'regen', row })}><RefreshCw size={16} aria-hidden /> Regenerate</Button>
              <Button variant="danger" className="flex-1" onClick={() => setConfirm({ kind: 'remove', row })}><Link2Off size={16} aria-hidden /> Remove access</Button>
            </div>
          </div>
        )}
      </Modal>
      <ConfirmDialog open={confirm?.kind === 'regen'} title="Create a new QR code?" message="The current QR stops working immediately. The driver must scan the new one and agree again." confirmLabel="Regenerate" loading={busy} onConfirm={regenerate} onClose={() => setConfirm(null)} />
      <ConfirmDialog open={confirm?.kind === 'remove'} title="Remove driver access?" message="The QR stops working and this bus can no longer be tracked from a phone. A trip that is already running can be ended in Trip Control." confirmLabel="Remove" loading={busy} onConfirm={remove} onClose={() => setConfirm(null)} />
    </div>
  );
}
