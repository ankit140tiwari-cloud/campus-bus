export const STATE_TONE = { sharing: 'success', waiting: 'info', paused: 'warning', stopped: 'neutral', denied: 'danger' };
export const isHttpsOrLocal = (url) => /^https:\/\//i.test(url) || /^http:\/\/(localhost|127\.0\.0\.1)(:|\/|$)/i.test(url);
export const fmtDateTime = (iso) => (iso ? new Date(iso).toLocaleString([], { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—');
export const fmtTime = (iso) => (iso ? new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '—');
export const fmtCoord = (n) => (typeof n === 'number' ? n.toFixed(6) : '—');
export const fmtAccuracy = (m) => (typeof m === 'number' ? `±${Math.round(m)} m` : 'unknown');
