import { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { Copy, Download, AlertTriangle } from 'lucide-react';
import Button from './Button';
import Card from './Card';
import { useToast } from './Toast';
import { isHttpsOrLocal } from '../utils/driverQr';

// The QR code holds only the driver's link: no password, no sign-in token, nothing personal.
export default function QrCard({ url, filename = 'driver-qr.png', title = 'QR code' }) {
  const toast = useToast();
  const [src, setSrc] = useState(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let stop = false;
    setFailed(false);
    QRCode.toDataURL(url, { width: 640, margin: 2, errorCorrectionLevel: 'M', color: { dark: '#1e1b4b', light: '#ffffff' } })
      .then((u) => { if (!stop) setSrc(u); })
      .catch(() => { if (!stop) setFailed(true); });
    return () => { stop = true; };
  }, [url]);

  const copy = async () => {
    try { await navigator.clipboard.writeText(url); toast('Link copied'); } catch { toast('Could not copy. Select the link and copy it by hand.', 'error'); }
  };

  return (
    <Card title={title}>
      <div className="flex flex-col items-center gap-3">
          <div className="grid h-56 w-56 place-items-center rounded-xl border border-slate-200 bg-white p-2">
            {src ? <img src={src} alt="QR code for the driver's phone" className="h-full w-full" />
              : <span className="text-xs text-slate-500">{failed ? 'Could not draw the QR code.' : 'Drawing QR code…'}</span>}
          </div>
          <p className="w-full break-all rounded-lg bg-slate-100 px-3 py-2 text-xs text-slate-600" data-testid="share-url">{url}</p>
          <div className="flex w-full flex-col gap-2 sm:flex-row">
            <a href={src || undefined} download={filename} aria-disabled={!src}
              className="inline-flex min-h-[44px] flex-1 items-center justify-center gap-2 rounded-lg bg-brand-600 px-4 text-sm font-semibold text-white hover:bg-brand-700 aria-disabled:pointer-events-none aria-disabled:opacity-60">
              <Download size={16} aria-hidden /> Download PNG
            </a>
            <Button variant="secondary" className="flex-1" onClick={copy}><Copy size={16} aria-hidden /> Copy link</Button>
          </div>
          {!isHttpsOrLocal(url) && (
            <p role="alert" className="flex gap-2 rounded-lg bg-amber-50 p-3 text-xs text-amber-800">
              <AlertTriangle size={16} className="mt-0.5 shrink-0" aria-hidden />
              <span>This address is not HTTPS. Phones only allow location sharing on HTTPS pages, so scanning this will not work. Set <code>DRIVER_LINK_BASE_URL</code> in backend/.env to your HTTPS address.</span>
            </p>
          )}
      </div>
    </Card>
  );
}
