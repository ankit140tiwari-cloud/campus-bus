import { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { cx } from '../utils/helpers';

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const DEFAULT_CENTER = [23.2599, 77.4126];
const pin = (selected) => L.divIcon({
  className: '',
  html: `<div style="width:${selected ? 22 : 18}px;height:${selected ? 22 : 18}px;border-radius:9999px;background:${selected ? '#0891b2' : '#4f46e5'};border:3px solid #fff;box-shadow:0 1px 5px rgba(0,0,0,.45)"></div>`,
  iconSize: [22, 22], iconAnchor: [11, 11], popupAnchor: [0, -12],
});

/**
 * points: [{ id, lat, lng, accuracy?, label?, detail? }]   selectedId: point to centre on   trail: [[lat, lng], ...] drawn as a line
 * Markers are moved in place when a new position arrives, so the page never reloads and the map is not re-fitted under your fingers.
 */
export default function ShareMap({ points = [], selectedId, trail, onSelect, className = 'h-72', label = 'Map' }) {
  const el = useRef(null);
  const map = useRef(null);
  const layer = useRef(null);
  const markers = useRef(new Map());
  const circles = useRef(new Map());
  const line = useRef(null);
  const fitted = useRef(false);
  const cb = useRef(onSelect);
  cb.current = onSelect;
  const [tileError, setTileError] = useState(false);

  useEffect(() => {
    const m = L.map(el.current).setView(DEFAULT_CENTER, 12);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    }).on('tileerror', () => setTileError(true)).addTo(m);
    layer.current = L.layerGroup().addTo(m);
    const ro = new ResizeObserver(() => m.invalidateSize());
    ro.observe(el.current);
    map.current = m;
    return () => { ro.disconnect(); m.remove(); map.current = null; markers.current = new Map(); circles.current = new Map(); line.current = null; fitted.current = false; };
  }, []);

  const sig = JSON.stringify(points.map((p) => [p.id, p.lat, p.lng, p.accuracy, p.label, p.detail, p.id === selectedId]));
  useEffect(() => {
    const g = layer.current;
    if (!g || !map.current) return;
    const seen = new Set();
    points.forEach((p) => {
      if (typeof p.lat !== 'number' || typeof p.lng !== 'number') return;
      seen.add(p.id);
      const sel = p.id === selectedId;
      const html = `<b>${esc(p.label)}</b>${p.detail ? `<br>${esc(p.detail)}` : ''}<br>${p.lat.toFixed(6)}, ${p.lng.toFixed(6)}${typeof p.accuracy === 'number' ? `<br>Accuracy ±${Math.round(p.accuracy)} m` : ''}`;
      let mk = markers.current.get(p.id);
      if (!mk) {
        mk = L.marker([p.lat, p.lng], { icon: pin(sel), title: p.label || 'Shared location', keyboard: true }).addTo(g).bindPopup(html);
        mk.on('click', () => cb.current?.(p.id));
        markers.current.set(p.id, mk);
      } else {
        mk.setLatLng([p.lat, p.lng]).setIcon(pin(sel)).setPopupContent(html);
      }
      const r = typeof p.accuracy === 'number' ? Math.min(p.accuracy, 5000) : 0;
      let c = circles.current.get(p.id);
      if (r > 0) {
        if (!c) { c = L.circle([p.lat, p.lng], { radius: r, color: '#0891b2', weight: 1, fillOpacity: 0.12, interactive: false }).addTo(g); circles.current.set(p.id, c); }
        else c.setLatLng([p.lat, p.lng]).setRadius(r);
      } else if (c) { g.removeLayer(c); circles.current.delete(p.id); }
    });
    markers.current.forEach((mk, id) => { if (!seen.has(id)) { g.removeLayer(mk); markers.current.delete(id); const c = circles.current.get(id); if (c) { g.removeLayer(c); circles.current.delete(id); } } });
    const live = points.filter((p) => typeof p.lat === 'number' && typeof p.lng === 'number');
    if (!live.length) { fitted.current = false; return; }
    const target = live.find((p) => p.id === selectedId);
    if (target) map.current.setView([target.lat, target.lng], Math.max(map.current.getZoom(), 16));
    else if (!fitted.current) { map.current.fitBounds(live.map((p) => [p.lat, p.lng]), { padding: [40, 40], maxZoom: 16 }); fitted.current = true; }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sig]);

  const trailSig = JSON.stringify(trail || []);
  useEffect(() => {
    const g = layer.current;
    if (!g) return;
    if (line.current) { g.removeLayer(line.current); line.current = null; }
    if (trail && trail.length > 1) line.current = L.polyline(trail, { color: '#4f46e5', weight: 3, opacity: 0.6, dashArray: '6 6' }).addTo(g);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [trailSig]);

  return (
    <div className={cx('relative isolate w-full overflow-hidden rounded-xl border border-slate-200 bg-slate-100', className)}>
      <div ref={el} role="region" aria-label={label} className="h-full w-full" />
      {points.length === 0 && (
        <p className="pointer-events-none absolute inset-x-3 top-3 z-[500] rounded-lg bg-white/95 p-2 text-center text-xs text-slate-600 shadow">No shared location to show yet.</p>
      )}
      {tileError && (
        <p role="status" className="absolute bottom-6 left-2 right-2 z-[500] rounded-lg bg-white/95 p-2 text-xs text-slate-700 shadow">Map tiles could not load. Check your internet connection.</p>
      )}
    </div>
  );
}
