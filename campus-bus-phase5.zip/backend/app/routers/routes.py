from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import delete, func, select, update
from sqlalchemy.orm import Session, joinedload, selectinload

from ..database import get_db
from ..deps import get_current_user, require_admin
from ..models import Bus, Route, RouteStop, Stop, User
from ..schemas import RouteIn
from ..utils import get_or_404, hhmm

router = APIRouter(prefix="/routes", tags=["routes"])

_OPTS = (selectinload(Route.route_stops).joinedload(RouteStop.stop), selectinload(Route.buses))


def route_out(r: Route) -> dict:
    links = sorted(r.route_stops, key=lambda l: l.stop_order)
    return {"id": r.id, "route_name": r.route_name, "start_point": r.start_point, "destination": r.destination, "status": r.status,
            "stops": [{"stop_id": l.stop_id, "stop_name": l.stop.stop_name, "stop_order": l.stop_order, "expected_time": hhmm(l.expected_time)} for l in links],
            "buses": [{"id": b.id, "bus_number": b.bus_number} for b in sorted(r.buses, key=lambda b: b.bus_number)]}


def _load(db: Session, route_id: int) -> Route:
    r = db.scalar(select(Route).where(Route.id == route_id).options(*_OPTS))
    if r is None:
        raise HTTPException(404, "Route not found.")
    return r


def _save(db: Session, route: Route, data: RouteIn) -> None:
    # ---- validate everything before touching the database ----
    clash = select(Route.id).where(func.lower(Route.route_name) == data.route_name.lower())
    if route.id:
        clash = clash.where(Route.id != route.id)
    if db.scalar(clash) is not None:
        raise HTTPException(409, "A route with this name already exists.")
    if len(data.stops) < 2:
        raise HTTPException(400, "Add at least two stops to the route.")
    ids = [s.stop_id for s in data.stops]
    if len(set(ids)) != len(ids):
        raise HTTPException(400, "A stop can only appear once on a route.")
    stops = {s.id: s for s in db.scalars(select(Stop).where(Stop.id.in_(ids))).all()}
    if len(stops) != len(ids):
        raise HTTPException(400, "One of the selected stops does not exist.")
    for a, b in zip(data.stops, data.stops[1:]):
        if b.expected_time <= a.expected_time:
            raise HTTPException(400, "Stop times must increase along the route.")
    bus_ids = list(set(data.bus_ids))
    if bus_ids and (db.scalar(select(func.count()).select_from(Bus).where(Bus.id.in_(bus_ids))) or 0) != len(bus_ids):
        raise HTTPException(400, "One of the selected buses does not exist.")

    route.route_name = data.route_name
    route.start_point = data.start_point or stops[ids[0]].stop_name
    route.destination = data.destination or stops[ids[-1]].stop_name
    route.status = data.status
    if route.id is None:
        db.add(route)
    db.flush()

    db.execute(delete(RouteStop).where(RouteStop.route_id == route.id))
    for i, s in enumerate(data.stops, 1):
        db.add(RouteStop(route_id=route.id, stop_id=s.stop_id, stop_order=i, expected_time=s.expected_time))

    db.execute(update(Bus).where(Bus.route_id == route.id, Bus.id.notin_(bus_ids or [0])).values(route_id=None))
    if bus_ids:
        db.execute(update(Bus).where(Bus.id.in_(bus_ids)).values(route_id=route.id))
    db.commit()


@router.get("")
def list_routes(db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    return [route_out(r) for r in db.scalars(select(Route).options(*_OPTS).order_by(Route.id)).all()]


@router.get("/{route_id}")
def get_route(route_id: int, db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    return route_out(_load(db, route_id))


@router.post("", status_code=201)
def create_route(data: RouteIn, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    route = Route(route_name="", start_point="", destination="")
    _save(db, route, data)
    db.expire_all()
    return route_out(_load(db, route.id))


@router.put("/{route_id}")
def update_route(route_id: int, data: RouteIn, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    route = get_or_404(db, Route, route_id, "Route")
    _save(db, route, data)
    db.expire_all()
    return route_out(_load(db, route_id))


@router.delete("/{route_id}", status_code=204)
def delete_route(route_id: int, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    route = get_or_404(db, Route, route_id, "Route")
    db.execute(update(Bus).where(Bus.route_id == route_id).values(route_id=None))
    db.delete(route)  # route_stops and schedules cascade
    db.commit()
