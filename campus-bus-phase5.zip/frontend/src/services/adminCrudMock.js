import { ROUTES, BUSES, STOP_NAMES, SCHEDULES, delay } from './mockData';

// MOCK implementation (used when VITE_USE_MOCK is not 'false'). In-memory store behind async functions. Phase 5 swaps each function body for a
// call to the matching FastAPI endpoint (/api/buses, /api/routes, /api/stops, /api/schedules).
// Components only ever call these functions, so they will not change.

const COORDS = { Habibganj: [23.2296, 77.4393], 'MP Nagar': [23.2332, 77.4344], 'Board Office': [23.23, 77.43], College: [23.2599, 77.4126], Kolar: [23.17, 77.42], 'New Market': [23.233, 77.399], Roshanpura: [23.238, 77.405], Bairagarh: [23.279, 77.338] };
const clone = (v) => JSON.parse(JSON.stringify(v));
const fail = (m) => { throw new Error(m); };
const isTime = (t) => /^\d{2}:\d{2}$/.test(t || '');

let stops = STOP_NAMES.map((name, i) => ({ id: i + 1, name, lat: COORDS[name][0], lng: COORDS[name][1], status: 'Active' }));
const sid = (n) => stops.find((s) => s.name === n).id;
let routes = ROUTES.map((r) => ({ id: r.id, name: r.name, start: r.stops[0].name, destination: r.stops.at(-1).name, status: 'Active', stops: r.stops.map((s) => ({ stopId: sid(s.name), time: s.time })) }));
let buses = BUSES.map((b) => ({ id: b.id, number: b.number, registration: `MP04 BU ${1000 + b.id * 37}`, capacity: 40 + b.id * 4, routeId: b.routeId, status: b.status === 'Offline' ? 'Inactive' : 'Active' }));
let schedules = SCHEDULES.flatMap((s) => {
  const bus = buses.find((b) => b.number === s.bus);
  return s.days.map((day) => ({ busId: bus.id, routeId: bus.routeId, day, departure: s.departure, arrival: s.arrival, active: true }));
}).map((s, i) => ({ ...s, id: i + 1 }));

const nextId = (list) => Math.max(0, ...list.map((x) => x.id)) + 1;
const stopName = (id) => stops.find((s) => s.id === id)?.name || '?';

// ---------- Stops ----------
export const listStops = () => delay(clone(stops.map((s) => {
  const inRoutes = routes.filter((r) => r.stops.some((x) => x.stopId === s.id));
  const first = inRoutes[0];
  return { ...s, routeNames: inRoutes.map((r) => r.name), routeId: first?.id || '', order: first ? first.stops.findIndex((x) => x.stopId === s.id) + 1 : '' };
})));

export function saveStop({ id, name, lat, lng, status, routeId, order }) {
  name = (name || '').trim();
  if (!name) fail('Stop name is required.');
  if (stops.some((s) => s.id !== id && s.name.toLowerCase() === name.toLowerCase())) fail('A stop with this name already exists.');
  const la = Number(lat), lo = Number(lng);
  if (lat === '' || Number.isNaN(la) || la < -90 || la > 90) fail('Latitude must be a number between -90 and 90.');
  if (lng === '' || Number.isNaN(lo) || lo < -180 || lo > 180) fail('Longitude must be a number between -180 and 180.');
  let stop;
  if (id) {
    stop = stops.find((s) => s.id === id);
    routes.forEach((r) => { if (r.start === stop.name) r.start = name; if (r.destination === stop.name) r.destination = name; });
    Object.assign(stop, { name, lat: la, lng: lo, status });
  } else {
    stop = { id: nextId(stops), name, lat: la, lng: lo, status };
    stops.push(stop);
  }
  // route assignment: remove everywhere, then place in chosen route at the chosen order
  let time = '07:00';
  routes.forEach((r) => { const e = r.stops.find((x) => x.stopId === stop.id); if (e && r.id === routeId) time = e.time; r.stops = r.stops.filter((x) => x.stopId !== stop.id); });
  const r = routes.find((x) => x.id === routeId);
  if (r) {
    const at = Math.min(Math.max((Number(order) || r.stops.length + 1) - 1, 0), r.stops.length);
    r.stops.splice(at, 0, { stopId: stop.id, time });
  }
  return delay(true);
}

export function deleteStop(id) {
  stops = stops.filter((s) => s.id !== id);
  routes.forEach((r) => { r.stops = r.stops.filter((x) => x.stopId !== id); });
  return delay(true);
}

// ---------- Routes ----------
export const listRoutes = () => delay(clone(routes.map((r) => ({
  ...r, code: r.id, stopList: r.stops.map((x) => ({ ...x, name: stopName(x.stopId) })),
  busIds: buses.filter((b) => b.routeId === r.id).map((b) => b.id), busNumbers: buses.filter((b) => b.routeId === r.id).map((b) => b.number),
}))));

export const listStopOptions = () => delay(clone(stops.filter((s) => s.status === 'Active').map((s) => ({ id: s.id, name: s.name }))), 100);
export const listBusOptions = () => delay(clone(buses.map((b) => ({ id: b.id, number: b.number, routeId: b.routeId }))), 100);

export function saveRoute({ id, name, start, destination, status, stops: rs, busIds }) {
  name = (name || '').trim();
  if (!name) fail('Route name is required.');
  if (routes.some((r) => r.id !== id && r.name.toLowerCase() === name.toLowerCase())) fail('A route with this name already exists.');
  if (rs.length < 2) fail('Add at least two stops to the route.');
  if (rs.some((s) => !isTime(s.time))) fail('Every stop needs an expected arrival time.');
  for (let i = 1; i < rs.length; i++) if (rs[i].time <= rs[i - 1].time) fail('Stop times must increase along the route.');
  const data = { name, start: (start || '').trim() || stopName(rs[0].stopId), destination: (destination || '').trim() || stopName(rs.at(-1).stopId), status, stops: rs.map((s) => ({ stopId: s.stopId, time: s.time })) };
  let route;
  if (id) route = Object.assign(routes.find((r) => r.id === id), data);
  else {
    const n = Math.max(0, ...routes.map((r) => Number(r.id.slice(1)))) + 1;
    route = { id: `R${String(n).padStart(2, '0')}`, ...data };
    routes.push(route);
  }
  buses.forEach((b) => { if (busIds.includes(b.id)) b.routeId = route.id; else if (b.routeId === route.id) b.routeId = ''; });
  return delay(true);
}

export function deleteRoute(id) {
  routes = routes.filter((r) => r.id !== id);
  buses.forEach((b) => { if (b.routeId === id) b.routeId = ''; });
  schedules = schedules.filter((s) => s.routeId !== id);
  return delay(true);
}

// ---------- Buses ----------
export const listBuses = () => delay(clone(buses.map((b) => ({ ...b, routeName: routes.find((r) => r.id === b.routeId)?.name || 'Unassigned' }))));

export function saveBus({ id, number, registration, capacity, routeId, status }) {
  number = (number || '').trim(); registration = (registration || '').trim();
  const cap = Number(capacity);
  if (!number) fail('Bus number is required.');
  if (!registration) fail('Registration number is required.');
  if (!Number.isInteger(cap) || cap < 1 || cap > 100) fail('Capacity must be a whole number from 1 to 100.');
  if (buses.some((b) => b.id !== id && b.number.toLowerCase() === number.toLowerCase())) fail('This bus number already exists.');
  if (buses.some((b) => b.id !== id && b.registration.toLowerCase() === registration.toLowerCase())) fail('This registration number already exists.');
  const data = { number, registration, capacity: cap, routeId: routeId || '', status };
  if (id) Object.assign(buses.find((b) => b.id === id), data); else buses.push({ id: nextId(buses), ...data });
  return delay(true);
}
export const setBusStatus = (id, status) => { buses.find((b) => b.id === id).status = status; return delay(true, 150); };
export function deleteBus(id) { buses = buses.filter((b) => b.id !== id); schedules = schedules.filter((s) => s.busId !== id); return delay(true); }

// ---------- Schedules ----------
export const listSchedules = () => delay(clone(schedules.map((s) => ({
  ...s, busNumber: buses.find((b) => b.id === s.busId)?.number || '?', routeName: routes.find((r) => r.id === s.routeId)?.name || '?',
}))));

export function saveSchedule({ id, busId, routeId, day, departure, arrival, active }) {
  if (!busId) fail('Choose a bus.');
  if (!routeId) fail('Choose a route.');
  if (!isTime(departure) || !isTime(arrival)) fail('Enter departure and arrival times.');
  if (arrival <= departure) fail('Arrival must be after departure.');
  if (schedules.some((s) => s.id !== id && s.busId === busId && s.day === day && s.departure === departure)) fail('This bus already has a trip at that time on that day.');
  const data = { busId, routeId, day, departure, arrival, active };
  if (id) Object.assign(schedules.find((s) => s.id === id), data); else schedules.push({ id: nextId(schedules), ...data });
  return delay(true);
}
export const setScheduleActive = (id, active) => { schedules.find((s) => s.id === id).active = active; return delay(true, 150); };
export const deleteSchedule = (id) => { schedules = schedules.filter((s) => s.id !== id); return delay(true); };
