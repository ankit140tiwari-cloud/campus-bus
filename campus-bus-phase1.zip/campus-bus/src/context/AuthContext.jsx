import { createContext, useState, useCallback } from 'react';
import * as authService from '../services/authService';
import { getStoredAuth } from '../services/api';

export const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [auth, setAuth] = useState(() => getStoredAuth());

  const login = useCallback(async (creds) => {
    const result = await authService.login(creds);
    setAuth(result);
    return result.user;
  }, []);

  const logout = useCallback(() => {
    authService.logout();
    setAuth(null);
  }, []);

  return (
    <AuthContext.Provider value={{ user: auth?.user ?? null, token: auth?.token ?? null, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}
