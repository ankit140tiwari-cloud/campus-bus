import Card from '../../components/Card';

const KPIS = [['Total Buses', 25], ['Active', 18], ['Delayed', 2], ['Offline', 5]];

export default function AdminDashboard() {
  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold text-slate-900">Transport overview</h1>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {KPIS.map(([label, value]) => (
          <Card key={label}><p className="text-sm text-slate-500">{label}</p><p className="text-2xl font-bold text-slate-900">{value}</p></Card>
        ))}
      </div>
      <p className="text-xs text-slate-400">Sample numbers. Full KPIs and live data arrive in Phases 3 and 5.</p>
    </div>
  );
}
