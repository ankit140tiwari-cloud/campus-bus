import { Bus } from 'lucide-react';
import useAuth from '../../hooks/useAuth';
import Card from '../../components/Card';
import Badge from '../../components/Badge';
import Button from '../../components/Button';

export default function StudentDashboard() {
  const { user } = useAuth();
  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <div>
        <h1 className="text-xl font-bold text-slate-900">Hi, {user.name.split(' ')[0]}</h1>
        <p className="text-sm text-slate-500">Your stop: {user.defaultStop}</p>
      </div>
      <Card title="Next bus (sample data)">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-lg bg-brand-50 text-brand-600"><Bus /></span>
            <div>
              <p className="font-bold text-slate-900">BUS-12</p>
              <p className="text-sm text-slate-500">MP Nagar → College</p>
            </div>
          </div>
          <Badge>On Time</Badge>
        </div>
        <dl className="mt-4 grid grid-cols-3 gap-3 text-sm">
          <div><dt className="text-slate-500">ETA</dt><dd className="font-semibold">8 min</dd></div>
          <div><dt className="text-slate-500">Now at</dt><dd className="font-semibold">Board Office</dd></div>
          <div><dt className="text-slate-500">Next stop</dt><dd className="font-semibold">MP Nagar</dd></div>
        </dl>
        <Button className="mt-4 w-full">Track Live</Button>
      </Card>
      <p className="text-xs text-slate-400">Full dashboard arrives in Phase 2.</p>
    </div>
  );
}
