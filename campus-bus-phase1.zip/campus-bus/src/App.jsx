import { Routes, Route, Navigate } from 'react-router-dom';
import useAuth from './hooks/useAuth';
import Login from './pages/auth/Login';
import StudentLayout from './layouts/StudentLayout';
import AdminLayout from './layouts/AdminLayout';
import StudentDashboard from './pages/student/Dashboard';
import AdminDashboard from './pages/admin/Dashboard';
import ComingSoon from './pages/ComingSoon';
import { HOME_BY_ROLE, STUDENT_NAV, ADMIN_NAV } from './utils/constants';

function RequireRole({ role, children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (user.role !== role) return <Navigate to={HOME_BY_ROLE[user.role]} replace />;
  return children;
}

const stubs = (items) =>
  items.filter((i) => !i.end).map((i) => <Route key={i.to} path={i.to.split('/')[2]} element={<ComingSoon />} />);

export default function App() {
  const { user } = useAuth();
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/student" element={<RequireRole role="student"><StudentLayout /></RequireRole>}>
        <Route index element={<StudentDashboard />} />
        {stubs(STUDENT_NAV)}
      </Route>
      <Route path="/admin" element={<RequireRole role="admin"><AdminLayout /></RequireRole>}>
        <Route index element={<AdminDashboard />} />
        {stubs(ADMIN_NAV)}
      </Route>
      <Route path="*" element={<Navigate to={user ? HOME_BY_ROLE[user.role] : '/login'} replace />} />
    </Routes>
  );
}
