export const cx = (...c) => c.filter(Boolean).join(' ');
export const initials = (name = '') =>
  name.split(' ').filter(Boolean).slice(0, 2).map((p) => p[0].toUpperCase()).join('');
