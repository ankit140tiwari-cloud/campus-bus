import os
import sys
from datetime import date

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from app import analytics_core as ac  # noqa: E402

TODAY = date(2026, 10, 7)  # a Wednesday


def test_date_ranges_end_today_and_have_the_right_length():
    assert ac.date_range("today", TODAY) == [TODAY]
    d7, d30 = ac.date_range("7d", TODAY), ac.date_range("30d", TODAY)
    assert len(d7) == 7 and d7[-1] == TODAY and d7[0] == date(2026, 10, 1)
    assert len(d30) == 30 and d30[0] == date(2026, 9, 8)


def test_per_day_fills_gaps_with_zero():
    days = ac.date_range("7d", TODAY)
    out = ac.per_day(days, [TODAY, TODAY, date(2026, 10, 5)])
    assert out == [0, 0, 0, 0, 1, 0, 2] and sum(out) == 3


def test_averages_ignore_empty_days():
    days = ac.date_range("7d", TODAY)
    out = ac.avg_per_day(days, [(TODAY, 4), (TODAY, 7), (date(2026, 10, 5), 0)])
    assert out[-1] == 5.5 and out[-3] == 0.0 and out[0] is None
    assert ac.average([]) is None


def test_scheduled_count_follows_weekdays():
    days = ac.date_range("7d", TODAY)  # Thu 1 Oct .. Wed 7 Oct: every weekday once
    assert ac.scheduled_count(days, ["Mon", "Tue", "Wed", "Thu", "Fri"]) == 5
    assert ac.scheduled_count(days, ["Mon", "Mon"]) == 2
    assert ac.scheduled_count(ac.date_range("today", TODAY), ["Wed", "Fri"]) == 1  # TODAY is a Wednesday


def test_utilization_is_capped_and_none_without_a_schedule():
    assert ac.utilization_pct(0, 3) is None
    assert ac.utilization_pct(10, 5) == 50 and ac.utilization_pct(4, 9) == 100


def test_on_time_threshold():
    assert ac.on_time_pct([0, 2, 4, 5, 12]) == 60
    assert ac.on_time_pct([]) is None


def test_hour_labels():
    assert [ac.hour_label(h) for h in (0, 7, 12, 13, 23)] == ["12 AM", "7 AM", "12 PM", "1 PM", "11 PM"]


def test_student_demand_per_route_stop_and_pickup_hour():
    links = [(1, 10, 7 * 60 + 15), (1, 11, 7 * 60 + 25), (2, 11, 8 * 60 + 5), (2, 12, 8 * 60 + 20)]  # stop 11 is on both routes
    per_route, per_stop, per_hour = ac.student_demand([10, 11, 11, 12, 99], links)
    assert per_stop[11] == 2 and per_stop[99] == 1
    assert per_route[1] == 3 and per_route[2] == 3          # the two stop-11 students count for both routes
    assert per_hour[7] == 3 and per_hour[8] == 1            # stop 11 uses its earliest pickup (7:25); stop 99 is on no route


if __name__ == "__main__":
    for n, f in list(globals().items()):
        if n.startswith("test_"):
            f(); print("PASS", n)
