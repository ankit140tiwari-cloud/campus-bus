"""Run:  cd backend && python tests/test_eta_core.py   (needs numpy, pandas, scikit-learn, joblib)"""
import os
import sys
import tempfile
import types
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

try:
    import dotenv  # noqa: F401
except ImportError:  # only the test environment may lack it; the app installs python-dotenv
    sys.modules["dotenv"] = types.SimpleNamespace(load_dotenv=lambda *a, **k: None)

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from app.ml import eta_core, geo, predictor  # noqa: E402
from app.tracking_core import BusState, apply_location, pace_ratio  # noqa: E402

TZ = ZoneInfo("Asia/Kolkata")
ROUTE_STOPS = {  # route_id -> [(lat, lng, expected minutes)]
    1: [(23.2296, 77.4393, 435), (23.2332, 77.4344, 445), (23.2300, 77.4300, 455), (23.2599, 77.4126, 470)],
    2: [(23.1700, 77.4200, 425), (23.2330, 77.3990, 445), (23.2380, 77.4050, 458), (23.2599, 77.4126, 475)],
    3: [(23.2790, 77.3380, 430), (23.2380, 77.4050, 450), (23.2330, 77.3990, 462), (23.2599, 77.4126, 480)],
}


def routes_df() -> pd.DataFrame:
    return pd.DataFrame([(rid, i + 1, lat, lng, m) for rid, st in ROUTE_STOPS.items() for i, (lat, lng, m) in enumerate(st)], columns=["route_id", "stop_order", "lat", "lng", "expected_min"])


def make_visits(days=40, structured=True, seed=3) -> pd.DataFrame:
    """Synthetic history. structured=True: a slow second leg and slow Mondays/Fridays that the timetable does not know about.
    structured=False: trips run exactly to the timetable plus noise, so there is nothing for a model to learn."""
    rng = np.random.default_rng(seed)
    rows, trip = [], 0
    start_day = datetime(2026, 8, 1, tzinfo=TZ)
    for d in range(days):
        day = start_day + timedelta(days=d)
        if day.weekday() > 4:
            continue
        busy = {0: 1.6, 4: 1.3}.get(day.weekday(), 1.0)
        for rid, st in ROUTE_STOPS.items():
            for _ in range(2):
                trip += 1
                base, extra = rng.choice([0, 0, 1, 2, 3, 4, 6, 9]), 0.0
                for k, (_, _, minutes) in enumerate(st):
                    if structured and k == 1:
                        extra += 3 * busy
                    if structured and k == len(st) - 1:
                        extra += 2 * busy
                    delay = max(0, round(base + extra + rng.choice([-1, 0, 0, 1, 2])))
                    at = (day.replace(hour=0, minute=0) + timedelta(minutes=minutes + delay)).astimezone(timezone.utc)
                    rows.append((trip, rid, k + 1, at, delay))
    return pd.DataFrame(rows, columns=["trip_id", "route_id", "stop_order", "arrived_at", "delay_min"])


def test_examples_pair_every_later_stop_with_the_real_travel_time():
    at = lambda m: datetime(2026, 9, 7, tzinfo=TZ).replace(hour=m // 60, minute=m % 60).astimezone(timezone.utc)  # noqa: E731
    v = pd.DataFrame([(1, 1, 1, at(435), 0), (1, 1, 2, at(448), 3), (1, 1, 4, at(480), 10)], columns=["trip_id", "route_id", "stop_order", "arrived_at", "delay_min"])
    ex = eta_core.build_examples(v, routes_df(), "Asia/Kolkata")
    assert len(ex) == 3  # (1->2), (1->4), (2->4)
    first = ex[(ex.stops_remaining == 1)].iloc[0]
    assert first.target == 13 and first.sched_minutes == 10 and first.current_delay == 0 and first.pace_ratio == 1.0
    last = ex[(ex.stops_remaining == 2)].iloc[0]
    assert last.target == 32 and last.dow == 0 and last.current_delay == 3 and last.distance_km > 3  # Monday; 3 km or more along the route
    assert abs(last.pace_ratio - 13 / 10) < 1e-9  # 13 real minutes for 10 scheduled


def test_a_model_is_promoted_only_when_it_beats_the_timetable():
    bundle, meta = eta_core.train_from_frames(make_visits(structured=True), routes_df(), "Asia/Kolkata")
    assert meta["status"] == "trained" and bundle is not None, meta
    assert meta["mae_model"] < meta["mae_baseline"] * 0.95 and meta["improvement_pct"] >= 5


def test_no_promotion_when_there_is_nothing_to_learn():
    bundle, meta = eta_core.train_from_frames(make_visits(structured=False), routes_df(), "Asia/Kolkata")
    assert bundle is None and meta["status"] == "demo" and "not better than the timetable" in meta["reason"]


def test_no_promotion_with_too_little_history():
    bundle, meta = eta_core.train_from_frames(make_visits(days=4), routes_df(), "Asia/Kolkata")
    assert bundle is None and meta["status"] == "demo" and "Not enough history" in meta["reason"]
    bundle, meta = eta_core.train_from_frames(make_visits(days=1).head(3), routes_df(), "Asia/Kolkata")
    assert bundle is None and "Only" in meta["reason"]


def test_predictions_are_sane_and_confidence_is_labelled():
    bundle, _ = eta_core.train_from_frames(make_visits(), routes_df(), "Asia/Kolkata")
    rows = [dict(distance_km=2.4, stops_remaining=1, sched_minutes=10, minute_of_day=7 * 60 + 40, dow=2, current_delay=1, pace_ratio=1.0, route_id=1),
            dict(distance_km=6.5, stops_remaining=3, sched_minutes=35, minute_of_day=7 * 60 + 40, dow=0, current_delay=3, pace_ratio=1.2, route_id=1)]
    (m1, c1), (m2, c2) = eta_core.predict(bundle, rows)
    assert 0 <= m1 < m2 < 90 and c1 in ("High", "Medium", "Low") and c2 in ("High", "Medium", "Low")
    assert eta_core.predict(bundle, []) == []
    # a slow Monday should be predicted slower than the same trip on a Wednesday
    mon, wed = rows[1], dict(rows[1], dow=2)
    assert eta_core.predict(bundle, [mon])[0][0] > eta_core.predict(bundle, [wed])[0][0]


def test_geometry_and_pace():
    stops = [{"lat": a, "lng": b, "minutes": m} for a, b, m in ROUTE_STOPS[1]]
    cum = geo.cumulative_km(stops)
    assert cum[0] == 0 and all(x < y for x, y in zip(cum, cum[1:]))
    ahead = geo.distances_ahead(stops[0]["lat"], stops[0]["lng"], stops, 0)
    assert abs(ahead[1] - cum[1]) < 1e-6 and set(ahead) == {1, 2, 3}  # standing on stop 0, the next stop is one leg away
    assert geo.distances_ahead(0, 0, stops, 3) == {}
    mid = geo.scheduled_minutes_now((stops[0]["lat"] + stops[1]["lat"]) / 2, (stops[0]["lng"] + stops[1]["lng"]) / 2, stops, 0)
    assert 435 < mid < 445
    s = BusState(1, "BUS-1", 1, "R", 1, [dict(x, name=str(i)) for i, x in enumerate(stops)])
    t0 = datetime.now(timezone.utc)
    apply_location(s, stops[0]["lat"], stops[0]["lng"], t0, 435)
    apply_location(s, stops[1]["lat"], stops[1]["lng"], t0 + timedelta(minutes=15), 450)
    assert abs(pace_ratio(s) - 1.5) < 1e-9  # 15 real minutes for 10 scheduled


def test_predictor_labels_timetable_estimates_as_demo_and_uses_a_trained_model_when_present():
    stops = [{"name": n, "lat": a, "lng": b, "minutes": m, "stop_id": i} for i, (n, (a, b, m)) in enumerate(zip("ABCD", ROUTE_STOPS[1]))]
    s = BusState(1, "BUS-12", 1, "R1", 1, stops)
    apply_location(s, stops[0]["lat"], stops[0]["lng"], datetime.now(timezone.utc), 435)
    with tempfile.TemporaryDirectory() as tmp:
        predictor.MODEL_PATH, predictor.META_PATH = Path(tmp) / "m.joblib", Path(tmp) / "m.json"
        predictor.reload()
        est = predictor.estimate(s, now_min=436, dow=2)
        assert est["source"] == "schedule" and est["is_demo"] is True and est["model_version"] is None
        assert set(est["per_stop"]) == {"B", "C", "D"} and est["per_stop"]["B"]["distance_km"] > 0
        assert est["per_stop"]["B"]["eta_min"] == 445 - 436 and est["per_stop"]["B"]["confidence"] in ("Medium", "Low")
        assert est["per_stop"]["D"]["confidence"] == "Low"  # a far stop on a timetable rule is never trusted

        import joblib, json
        bundle, meta = eta_core.train_from_frames(make_visits(), routes_df(), "Asia/Kolkata")
        joblib.dump(bundle, predictor.MODEL_PATH)
        predictor.META_PATH.write_text(json.dumps(meta))
        predictor.reload()
        est = predictor.estimate(s, now_min=436, dow=2)
        assert est["source"] == "model" and est["is_demo"] is False and est["model_version"].startswith("rf-")
        assert est["per_stop"]["B"]["confidence"] in ("High", "Medium", "Low") and est["per_stop"]["B"]["eta_min"] >= 0

        # at the last stop there is nothing left to predict; before reaching any stop the model is not used
        done = BusState(2, "B2", 1, "R", 2, stops, visited_idx=3, lat=stops[3]["lat"], lng=stops[3]["lng"])
        assert predictor.estimate(done, 480, 2)["per_stop"] == {}
        early = BusState(3, "B3", 1, "R", 3, stops, lat=23.22, lng=77.44)
        assert predictor.estimate(early, 430, 2)["source"] == "schedule"
    predictor.MODEL_PATH, predictor.META_PATH = Path("models/eta_model.joblib"), Path("models/eta_model.json")


if __name__ == "__main__":
    for n, f in list(globals().items()):
        if n.startswith("test_"):
            f(); print("PASS", n)
