"""Train the ETA model from recorded stop visits.   python -m app.ml.train"""
import json
import logging
import threading
from pathlib import Path

import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import config
from ..database import SessionLocal
from ..models import RouteStop, Stop, StopVisit
from . import eta_core, predictor

log = logging.getLogger("eta")
_train_lock = threading.Lock()


def load_frames(db: Session) -> tuple[pd.DataFrame, pd.DataFrame]:
    v = db.execute(select(StopVisit.trip_id, StopVisit.route_id, StopVisit.stop_order, StopVisit.arrived_at, StopVisit.delay_min).where(StopVisit.route_id.is_not(None))).all()
    visits = pd.DataFrame([tuple(r) for r in v], columns=["trip_id", "route_id", "stop_order", "arrived_at", "delay_min"])
    r = db.execute(select(RouteStop.route_id, RouteStop.stop_order, Stop.latitude, Stop.longitude, RouteStop.expected_time).join(Stop, Stop.id == RouteStop.stop_id)).all()
    routes = pd.DataFrame([(a, b, c, d, e.hour * 60 + e.minute) for a, b, c, d, e in r], columns=["route_id", "stop_order", "lat", "lng", "expected_min"])
    return visits, routes


def run_training() -> dict:
    """Train, save if the model earned its place, reload the live predictor. Returns the metadata. Raises if one is already running."""
    if not _train_lock.acquire(blocking=False):
        raise RuntimeError("Training is already running.")
    try:
        with SessionLocal() as db:
            visits, routes = load_frames(db)
        bundle, meta = eta_core.train_from_frames(visits, routes, config.APP_TIMEZONE)
        out = Path(config.MODEL_DIR)
        out.mkdir(parents=True, exist_ok=True)
        if bundle is not None:
            import joblib
            joblib.dump(bundle, out / "eta_model.joblib", compress=3)
        elif (out / "eta_model.joblib").exists():
            (out / "eta_model.joblib").unlink()  # an older model that no longer qualifies must not keep serving
        (out / "eta_model.json").write_text(json.dumps(meta, indent=2))
        predictor.reload()
        log.info("ETA training finished: %s", meta["reason"])
        return meta
    finally:
        _train_lock.release()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    m = run_training()
    print(json.dumps(m, indent=2))
