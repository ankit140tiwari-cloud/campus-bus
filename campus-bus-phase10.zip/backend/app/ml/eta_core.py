"""ETA model: pandas builds the training table, scikit-learn fits a random forest, NumPy does the prediction maths.
No database or web imports here, so the whole pipeline can be tested with plain DataFrames."""
from datetime import datetime, timezone

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor

from . import geo

FEATURES = ["distance_km", "stops_remaining", "sched_minutes", "hist_minutes", "minute_of_day", "dow", "current_delay", "pace_ratio", "route_id"]
MIN_TRIPS, MIN_EXAMPLES, MIN_GAIN = 30, 200, 0.05  # a model is used only if it has this much data AND beats the timetable by 5%


def build_examples(visits: pd.DataFrame, routes: pd.DataFrame, tz: str) -> pd.DataFrame:
    """One row per (stop a reached, later stop b reached) on the same trip.
    Features describe the moment the bus reached stop a; the target is the real minutes it then took to reach b.
    visits: trip_id, route_id, stop_order, arrived_at (UTC), delay_min.   routes: route_id, stop_order, lat, lng, expected_min."""
    geom: dict = {}
    for rid, g in routes.sort_values("stop_order").groupby("route_id"):
        stops = [{"lat": r.lat, "lng": r.lng} for r in g.itertuples()]
        cum = geo.cumulative_km(stops)
        geom[rid] = {int(o): (c, float(e)) for o, c, e in zip(g.stop_order, cum, g.expected_min)}

    v = visits.copy()
    v["local"] = pd.to_datetime(v["arrived_at"], utc=True).dt.tz_convert(tz)
    rows = []
    for trip_id, g in v.sort_values(["trip_id", "stop_order"]).groupby("trip_id"):
        rid = g["route_id"].iloc[0]
        if rid not in geom or len(g) < 2:
            continue
        recs = g.to_dict("records")
        try:
            first = recs[0]
            first_sched = geom[rid][int(first["stop_order"])][1]
            for ai, a in enumerate(recs):
                ca, ea = geom[rid][int(a["stop_order"])]
                elapsed = (a["local"] - first["local"]).total_seconds() / 60
                sched_elapsed = ea - first_sched
                pace = 1.0 if ai == 0 or sched_elapsed <= 0 else float(np.clip(elapsed / sched_elapsed, 0.3, 3.0))
                for b in recs[ai + 1:]:
                    cb, eb = geom[rid][int(b["stop_order"])]
                    rows.append({
                        "trip_id": trip_id, "route_id": int(rid), "started": first["local"],
                        "distance_km": cb - ca, "stops_remaining": int(b["stop_order"]) - int(a["stop_order"]), "sched_minutes": eb - ea,
                        "minute_of_day": a["local"].hour * 60 + a["local"].minute, "dow": a["local"].dayofweek,
                        "current_delay": float(a["delay_min"]), "pace_ratio": pace,
                        "target": (b["local"] - a["local"]).total_seconds() / 60,
                    })
        except KeyError:  # the route was edited after this trip; its stop order no longer matches
            continue
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    return df[(df["distance_km"] > 0) & (df["target"] > 0) & (df["target"] < 180)].reset_index(drop=True)


def _rates(df: pd.DataFrame) -> tuple[dict, float]:
    """Historical minutes per km, per route and overall. This is the 'historical travel time' feature."""
    per_km = df["target"] / df["distance_km"]
    return {int(k): float(x) for k, x in per_km.groupby(df["route_id"]).median().items()}, float(per_km.median())


def _matrix(df: pd.DataFrame, rates: dict, fallback: float) -> np.ndarray:
    d = df.copy()
    d["hist_minutes"] = d["distance_km"] * d["route_id"].map(rates).fillna(fallback)
    return d[FEATURES].to_numpy(dtype=float)


def _tree_std(model: RandomForestRegressor, X: np.ndarray) -> np.ndarray:
    return np.std(np.stack([t.predict(X) for t in model.estimators_]), axis=0)


def _forest() -> RandomForestRegressor:
    return RandomForestRegressor(n_estimators=120, min_samples_leaf=3, random_state=7, n_jobs=1)


def train_from_frames(visits: pd.DataFrame, routes: pd.DataFrame, tz: str) -> tuple[dict | None, dict]:
    """Returns (bundle, metadata). The bundle is None unless the model earned its place; metadata always explains why."""
    ex = build_examples(visits, routes, tz)
    n_trips = int(ex["trip_id"].nunique()) if len(ex) else 0
    meta = {"status": "demo", "reason": "", "trained_at": datetime.now(timezone.utc).isoformat(), "n_trips": n_trips, "n_examples": len(ex),
            "mae_model": None, "mae_baseline": None, "improvement_pct": None,
            "thresholds": {"min_trips": MIN_TRIPS, "min_examples": MIN_EXAMPLES, "min_gain_pct": int(MIN_GAIN * 100)}}
    if n_trips < 5:
        meta["reason"] = f"Only {n_trips} tracked trips with stop records. At least {MIN_TRIPS} are needed."
        return None, meta

    # judge the model on the most recent 20% of trips, which it never saw, like it will face real future trips
    order = ex.groupby("trip_id")["started"].min().sort_values()
    cut = max(1, int(len(order) * 0.8))
    train_ids = set(order.index[:cut])
    tr, te = ex[ex["trip_id"].isin(train_ids)], ex[~ex["trip_id"].isin(train_ids)]
    rates, fb = _rates(tr)
    model = _forest().fit(_matrix(tr, rates, fb), tr["target"].to_numpy(float))
    pred = model.predict(_matrix(te, rates, fb))
    mae_model = float(np.mean(np.abs(pred - te["target"])))
    mae_base = float(np.mean(np.abs(te["sched_minutes"] - te["target"])))  # the timetable (plus carried delay) is the number to beat
    gain = (mae_base - mae_model) / mae_base if mae_base > 0 else 0.0
    meta.update(mae_model=round(mae_model, 2), mae_baseline=round(mae_base, 2), improvement_pct=round(100 * gain, 1), n_train=len(tr), n_test=len(te))

    if n_trips < MIN_TRIPS or len(ex) < MIN_EXAMPLES:
        meta["reason"] = f"Not enough history yet: {n_trips} trips and {len(ex)} examples (need {MIN_TRIPS} and {MIN_EXAMPLES}). Predictions stay timetable-based demo estimates."
        return None, meta
    if gain < MIN_GAIN:
        meta["reason"] = f"The model is not better than the timetable on recent trips ({mae_model:.2f} vs {mae_base:.2f} min average error), so it is not used."
        return None, meta

    # confidence: rank the forest's disagreement on unseen trips; the calmest third is High, the next third Medium
    std = _tree_std(model, _matrix(te, rates, fb))
    conf = {"p33": float(np.percentile(std, 33)), "p66": float(np.percentile(std, 66))}
    rates_all, fb_all = _rates(ex)
    final = _forest().fit(_matrix(ex, rates_all, fb_all), ex["target"].to_numpy(float))
    version = "rf-" + datetime.now(timezone.utc).strftime("%Y%m%d%H%M")
    meta.update(status="trained", reason=f"Beats the timetable by {100 * gain:.0f}% on recent trips.", model_version=version)
    return {"model": final, "rates": rates_all, "fallback_rate": fb_all, "conf": conf, "version": version, "features": FEATURES}, meta


def confidence_label(std: float, conf: dict) -> str:
    return "High" if std <= conf["p33"] else "Medium" if std <= conf["p66"] else "Low"


def predict(bundle: dict, rows: list[dict]) -> list[tuple[float, str]]:
    """rows: dicts with the FEATURES except hist_minutes. Returns (minutes, confidence) per row."""
    if not rows:
        return []
    df = pd.DataFrame(rows)
    X = _matrix(df, bundle["rates"], bundle["fallback_rate"])
    mins = np.maximum(0.0, bundle["model"].predict(X))
    std = _tree_std(bundle["model"], X)
    return [(float(m), confidence_label(float(s), bundle["conf"])) for m, s in zip(mins, std)]
