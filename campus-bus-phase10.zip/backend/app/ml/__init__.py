# Mirrors eta_core.MIN_TRIPS / MIN_EXAMPLES / MIN_GAIN so the status endpoint does not need to import scikit-learn.
eta_core_limits = {"min_trips": 30, "min_examples": 200, "min_gain_pct": 5}
