"""Runtime ETA estimates for a running bus. Uses the trained model when one has earned its place, otherwise the timetable.
Every estimate says which, so the UI can label timetable-based numbers as demo estimates."""
import json
import logging
import threading
from pathlib import Path

from .. import config
from ..tracking_core import BusState, current_delay, pace_ratio
from . import geo

log = logging.getLogger("eta")
MODEL_PATH = Path(config.MODEL_DIR) / "eta_model.joblib"
META_PATH = Path(config.MODEL_DIR) / "eta_model.json"

_lock = threading.Lock()
_bundle: dict | None = None
_loaded = False


def reload() -> None:
    """(Re)read the model from disk. Called at startup and after training."""
    global _bundle, _loaded
    with _lock:
        _bundle, _loaded = None, True
        meta = status()
        if meta.get("status") == "trained" and MODEL_PATH.is_file():
            try:
                import joblib  # imported lazily: the timetable fallback does not need scikit-learn at all
                _bundle = joblib.load(MODEL_PATH)  # our own file written by train.py; never load a model from an untrusted source
            except Exception:
                log.exception("Could not load the ETA model; using timetable estimates.")


def status() -> dict:
    if not META_PATH.is_file():
        return {"status": "none", "reason": "No model has been trained yet. Estimates come from the timetable and are demo estimates."}
    try:
        return json.loads(META_PATH.read_text())
    except (OSError, json.JSONDecodeError):
        return {"status": "none", "reason": "The model description could not be read."}


def _bundle_now() -> dict | None:
    if not _loaded:
        reload()
    return _bundle


def estimate(s: BusState, now_min: int, dow: int, threshold: int = 5) -> dict:
    """{'source', 'is_demo', 'model_version', 'per_stop': {stop name: {eta_min, distance_km, confidence}}}"""
    out = {"source": "schedule", "is_demo": True, "model_version": None, "per_stop": {}}
    if s.lat is None or s.visited_idx + 1 >= len(s.stops):
        return out
    ahead = geo.distances_ahead(s.lat, s.lng, s.stops, s.visited_idx)
    delay = current_delay(s, now_min)
    bundle = _bundle_now()

    if bundle is not None and s.visited_idx >= 0:
        from . import eta_core  # lazy: pulls in pandas and scikit-learn
        sched_now = geo.scheduled_minutes_now(s.lat, s.lng, s.stops, s.visited_idx)
        pace = pace_ratio(s)
        idxs = list(ahead)
        rows = [{"distance_km": ahead[j], "stops_remaining": j - s.visited_idx, "sched_minutes": s.stops[j]["minutes"] - sched_now,
                 "minute_of_day": now_min, "dow": dow, "current_delay": delay, "pace_ratio": pace, "route_id": s.route_id} for j in idxs]
        try:
            for j, (mins, conf) in zip(idxs, eta_core.predict(bundle, rows)):
                out["per_stop"][s.stops[j]["name"]] = {"eta_min": int(round(mins)), "distance_km": round(ahead[j], 1), "confidence": conf}
            out.update(source="model", is_demo=False, model_version=bundle.get("version"))
            return out
        except Exception:
            log.exception("Model prediction failed; falling back to the timetable.")
            out["per_stop"] = {}

    for j, km in ahead.items():
        remaining = j - s.visited_idx
        # a timetable rule is never "High": Medium only when the next stop or two is close and the bus is on time
        conf = "Medium" if remaining <= 2 and delay < threshold else "Low"
        out["per_stop"][s.stops[j]["name"]] = {"eta_min": max(0, s.stops[j]["minutes"] + delay - now_min), "distance_km": round(km, 1), "confidence": conf}
    return out
