"""Route geometry for ETA features. Pure Python: the schedule-based fallback uses this without needing scikit-learn."""
from ..tracking_core import haversine_m


def km(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    return haversine_m(lat1, lng1, lat2, lng2) / 1000


def cumulative_km(stops: list[dict]) -> list[float]:
    """Distance along the route from the first stop to each stop (straight lines between stops)."""
    out = [0.0]
    for a, b in zip(stops, stops[1:]):
        out.append(out[-1] + km(a["lat"], a["lng"], b["lat"], b["lng"]))
    return out


def distances_ahead(lat: float, lng: float, stops: list[dict], visited: int) -> dict[int, float]:
    """Distance from the bus's position to every stop it has not reached yet: first to the next stop, then along the route."""
    nxt = visited + 1
    if nxt >= len(stops):
        return {}
    cum = cumulative_km(stops)
    to_next = km(lat, lng, stops[nxt]["lat"], stops[nxt]["lng"])
    return {j: to_next + (cum[j] - cum[nxt]) for j in range(nxt, len(stops))}


def scheduled_minutes_now(lat: float, lng: float, stops: list[dict], visited: int) -> float:
    """The timetable's clock at the bus's current position: interpolated between the last stop reached and the next one."""
    nxt = visited + 1
    if visited < 0 or nxt >= len(stops):
        return float(stops[max(visited, 0)]["minutes"])
    a, b = stops[visited], stops[nxt]
    leg = km(a["lat"], a["lng"], b["lat"], b["lng"])
    if leg <= 0:
        return float(a["minutes"])
    progress = min(1.0, max(0.0, 1 - km(lat, lng, b["lat"], b["lng"]) / leg))
    return a["minutes"] + progress * (b["minutes"] - a["minutes"])
