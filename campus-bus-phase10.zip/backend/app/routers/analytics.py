from collections import Counter
from datetime import datetime, time, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import analytics_core as ac
from .. import config
from ..database import get_db
from ..deps import require_admin
from ..models import Bus, Complaint, Route, RouteStop, Schedule, Stop, StopVisit, Trip, User
from ..tracking import TZ, manager

router = APIRouter(prefix="/analytics", tags=["analytics"])


@router.get("/overview")
def overview(db: Session = Depends(get_db), _: User = Depends(require_admin)):
    def n(stmt):
        return db.scalar(stmt) or 0

    snaps = manager.all_snaps()
    return {
        "total_buses": n(select(func.count()).select_from(Bus)),
        "active_buses": n(select(func.count()).select_from(Bus).where(Bus.status == "Active")),
        "inactive_buses": n(select(func.count()).select_from(Bus).where(Bus.status == "Inactive")),
        "total_routes": n(select(func.count()).select_from(Route)),
        "total_stops": n(select(func.count()).select_from(Stop)),
        "students": n(select(func.count()).select_from(User).where(User.role == "student")),
        "pending_complaints": n(select(func.count()).select_from(Complaint).where(Complaint.status == "Pending")),
        "running_buses": sum(1 for x in snaps if x["status"] != "Offline"),
        "delayed_buses": sum(1 for x in snaps if x["status"] == "Delayed"),
    }


def build_dashboard(db: Session, key: str) -> dict:
    if key not in ac.RANGE_DAYS:
        raise HTTPException(400, "range must be today, 7d or 30d.")
    days = ac.date_range(key, datetime.now(TZ).date())
    start = datetime.combine(days[0], time.min, tzinfo=TZ).astimezone(timezone.utc)
    local = lambda dt: dt.astimezone(TZ).date()  # noqa: E731  (day boundaries follow the college's timezone, not the server's)

    routes = {r.id: r.route_name for r in db.execute(select(Route.id, Route.route_name))}
    stops = {s.id: s.stop_name for s in db.execute(select(Stop.id, Stop.stop_name))}
    buses = db.execute(select(Bus.id, Bus.bus_number).where(Bus.status == "Active").order_by(Bus.bus_number)).all()
    trips = db.execute(select(Trip.bus_id, Trip.route_id, Trip.started_at).where(Trip.started_at >= start)).all()
    visits = db.execute(select(StopVisit.route_id, StopVisit.delay_min, StopVisit.arrived_at).where(StopVisit.arrived_at >= start)).all()
    comps = db.execute(select(Complaint.issue_type, Complaint.status, Complaint.created_at).where(Complaint.created_at >= start)).all()
    sched = db.execute(select(Schedule.bus_id, Schedule.day).where(Schedule.status == "Active")).all()
    student_stops = [r[0] for r in db.execute(select(User.default_stop_id).where(User.role == "student", User.status == "Active", User.default_stop_id.is_not(None)))]
    links = [(r.route_id, r.stop_id, r.expected_time.hour * 60 + r.expected_time.minute) for r in db.execute(select(RouteStop.route_id, RouteStop.stop_id, RouteStop.expected_time))]

    per_route_students, per_stop_students, per_hour = ac.student_demand(student_stops, links)
    trips_by_route = Counter(t.route_id for t in trips)
    trips_by_bus = Counter(t.bus_id for t in trips)
    delays_by_route: dict[int, list[int]] = {}
    for v in visits:
        delays_by_route.setdefault(v.route_id, []).append(v.delay_min)
    all_delays = [v.delay_min for v in visits]
    resolved = sum(1 for c in comps if c.status == "Resolved")

    route_rows = [{"route": name, "trips": trips_by_route.get(rid, 0), "students": per_route_students.get(rid, 0)} for rid, name in routes.items()]
    util = []
    for bus_id, number in buses:
        scheduled = ac.scheduled_count(days, [d for b, d in sched if b == bus_id])
        run = trips_by_bus.get(bus_id, 0)
        util.append({"bus": number, "scheduled": scheduled, "run": run, "pct": ac.utilization_pct(scheduled, run)})
    util.sort(key=lambda u: (u["pct"] is None, -(u["pct"] or 0), u["bus"]))

    return {
        "range": key, "from": days[0].isoformat(), "to": days[-1].isoformat(), "timezone": config.APP_TIMEZONE,
        "summary": {"trips": len(trips), "buses_used": len(trips_by_bus), "avg_delay_min": ac.average(all_delays), "on_time_pct": ac.on_time_pct(all_delays, config.DELAY_THRESHOLD_MIN),
                    "complaints": len(comps), "resolved_pct": round(100 * resolved / len(comps)) if comps else None},
        "daily": {"labels": [d.isoformat() for d in days], "trips": ac.per_day(days, [local(t.started_at) for t in trips]),
                  "avg_delay": ac.avg_per_day(days, [(local(v.arrived_at), v.delay_min) for v in visits]),
                  "complaints": ac.per_day(days, [local(c.created_at) for c in comps])},
        "routes": sorted(route_rows, key=lambda r: (-r["trips"], -r["students"], r["route"])),
        "stops": [{"stop": stops.get(sid, "Removed stop"), "students": n} for sid, n in per_stop_students.most_common(8)],
        "delays_by_route": sorted(({"route": routes.get(rid, "Removed route"), "avg_delay": ac.average(v), "visits": len(v)} for rid, v in delays_by_route.items()), key=lambda r: -(r["avg_delay"] or 0)),
        "utilization": util,
        "complaints": {"by_status": [{"label": s, "value": sum(1 for c in comps if c.status == s)} for s in ("Pending", "Investigating", "Resolved")],
                       "by_type": [{"label": t, "value": n} for t, n in Counter(c.issue_type for c in comps).most_common()]},
        "demand": [{"hour": ac.hour_label(h), "students": per_hour[h]} for h in sorted(per_hour)],
    }


@router.get("/dashboard")
def dashboard(range: str = "7d", db: Session = Depends(get_db), _: User = Depends(require_admin)):
    return build_dashboard(db, range)


# Spec-listed endpoints, as focused views of the same data
@router.get("/routes")
def routes_analytics(range: str = "7d", db: Session = Depends(get_db), _: User = Depends(require_admin)):
    d = build_dashboard(db, range)
    return {"range": d["range"], "routes": d["routes"], "stops": d["stops"]}


@router.get("/delays")
def delays_analytics(range: str = "7d", db: Session = Depends(get_db), _: User = Depends(require_admin)):
    d = build_dashboard(db, range)
    return {"range": d["range"], "avg_delay_min": d["summary"]["avg_delay_min"], "on_time_pct": d["summary"]["on_time_pct"],
            "daily": {"labels": d["daily"]["labels"], "avg_delay": d["daily"]["avg_delay"]}, "by_route": d["delays_by_route"]}
