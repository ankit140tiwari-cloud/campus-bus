from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from starlette.concurrency import run_in_threadpool

from ..database import get_db
from ..deps import require_admin
from ..ml import eta_core_limits, predictor
from ..models import StopVisit, Trip, User

router = APIRouter(prefix="/ml", tags=["ml"])


@router.get("/status")
def status(db: Session = Depends(get_db), _: User = Depends(require_admin)):
    trips_with_visits = db.scalar(select(func.count(func.distinct(StopVisit.trip_id)))) or 0
    return {**predictor.status(), "available_trips": trips_with_visits, "available_visits": db.scalar(select(func.count()).select_from(StopVisit)) or 0,
            "total_trips": db.scalar(select(func.count()).select_from(Trip)) or 0, "limits": eta_core_limits}


@router.post("/train")
async def train(_: User = Depends(require_admin)):
    from ..ml import train as trainer  # lazy: imports pandas and scikit-learn
    try:
        return await run_in_threadpool(trainer.run_training)
    except RuntimeError as e:
        raise HTTPException(409, str(e))
