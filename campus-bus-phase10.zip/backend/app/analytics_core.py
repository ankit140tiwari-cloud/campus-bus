"""Pure analytics maths on plain Python values (no framework imports, so it is unit-tested anywhere)."""
from collections import Counter
from datetime import date, timedelta

DAY = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
RANGE_DAYS = {"today": 1, "7d": 7, "30d": 30}


def date_range(key: str, today: date) -> list[date]:
    n = RANGE_DAYS[key]
    return [today - timedelta(days=n - 1 - i) for i in range(n)]


def per_day(days: list[date], items: list[date]) -> list[int]:
    c = Counter(items)
    return [c.get(d, 0) for d in days]


def average(values: list[float]) -> float | None:
    return round(sum(values) / len(values), 1) if values else None


def avg_per_day(days: list[date], items: list[tuple[date, float]]) -> list[float | None]:
    by: dict[date, list[float]] = {}
    for d, v in items:
        by.setdefault(d, []).append(v)
    return [average(by.get(d, [])) for d in days]


def scheduled_count(days: list[date], sched_days: list[str]) -> int:
    """How many trips a bus was scheduled to run over `days`, given the weekday of each of its active schedule rows."""
    c = Counter(sched_days)
    return sum(c.get(DAY[d.weekday()], 0) for d in days)


def utilization_pct(scheduled: int, run: int) -> int | None:
    return None if scheduled == 0 else min(100, round(100 * run / scheduled))


def on_time_pct(delays: list[int], threshold: int = 5) -> int | None:
    return round(100 * sum(1 for d in delays if d < threshold) / len(delays)) if delays else None


def hour_label(h: int) -> str:
    return f"{h % 12 or 12} {'AM' if h < 12 else 'PM'}"


def student_demand(student_stops: list[int], links: list[tuple[int, int, int]]):
    """Registered demand. `links` = (route_id, stop_id, expected minutes after midnight).
    Returns (students per route, students per stop, students per scheduled pickup hour).
    A student counts for every route that serves their stop, and for the earliest pickup time at that stop."""
    routes_of: dict[int, set[int]] = {}
    earliest: dict[int, int] = {}
    for route_id, stop_id, minutes in links:
        routes_of.setdefault(stop_id, set()).add(route_id)
        earliest[stop_id] = min(minutes, earliest.get(stop_id, minutes))
    per_route, per_stop, per_hour = Counter(), Counter(), Counter()
    for stop in student_stops:
        per_stop[stop] += 1
        for r in routes_of.get(stop, ()):
            per_route[r] += 1
        if stop in earliest:
            per_hour[earliest[stop] // 60] += 1
    return per_route, per_stop, per_hour
