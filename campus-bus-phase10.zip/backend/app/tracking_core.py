"""Pure live-tracking logic: stop detection, delay and ETA. No framework imports on purpose."""
import math
from dataclasses import dataclass, field
from datetime import datetime


def haversine_m(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    r = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    a = math.sin((p2 - p1) / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(math.radians(lng2 - lng1) / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


@dataclass
class BusState:
    bus_id: int
    bus_number: str
    route_id: int
    route_name: str
    trip_id: int
    stops: list[dict]  # ordered: name, lat, lng, minutes (expected time as minutes after midnight, local)
    visited_idx: int = -1
    delay_at_visit: int = 0
    lat: float | None = None
    lng: float | None = None
    ts: datetime | None = None  # timezone-aware UTC time of the last accepted fix
    last_accept: float = 0.0
    last_db_write: float = 0.0
    offline_sent: bool = False
    last_status: str | None = None
    last_delay_notice: float = 0.0
    visit_ts: dict = field(default_factory=dict)  # stop index -> time the bus reached it
    ml: dict | None = None                        # latest ETA estimate (see app/ml/predictor.py)
    last_ml: float = 0.0


def apply_location(s: BusState, lat: float, lng: float, ts: datetime, now_min: int, radius_m: float = 150) -> None:
    s.lat, s.lng, s.ts, s.offline_sent = lat, lng, ts, False
    reached = s.visited_idx
    for i in range(s.visited_idx + 1, len(s.stops)):
        if haversine_m(lat, lng, s.stops[i]["lat"], s.stops[i]["lng"]) <= radius_m:
            reached = i  # keeps the furthest stop in range, so a skipped stop is not a problem
    if reached != s.visited_idx:
        s.visited_idx = reached
        s.visit_ts[reached] = ts
        s.delay_at_visit = max(0, now_min - s.stops[reached]["minutes"])


def current_delay(s: BusState, now_min: int) -> int:
    """Delay fixed when the last stop was reached, growing once the next stop is overdue."""
    d = s.delay_at_visit
    nxt = s.visited_idx + 1
    if nxt < len(s.stops):
        d = max(d, now_min - s.stops[nxt]["minutes"])
    return max(0, d)


def snapshot(s: BusState, now_utc: datetime, now_min: int, stale_seconds: int = 120, delay_threshold: int = 5) -> dict:
    stale = s.ts is None or (now_utc - s.ts).total_seconds() > stale_seconds
    delay = current_delay(s, now_min)
    nxt = s.visited_idx + 1
    status = "Offline" if stale else ("Delayed" if delay >= delay_threshold else "On Time")
    return {
        "bus_id": s.bus_id, "bus_number": s.bus_number, "route_id": s.route_id, "route_name": s.route_name, "trip_id": s.trip_id,
        "status": status, "delay_min": delay, "trip_active": True,
        "latitude": s.lat, "longitude": s.lng, "timestamp": s.ts.isoformat() if s.ts else None,
        "current_stop": s.stops[s.visited_idx]["name"] if s.visited_idx >= 0 else None,
        "next_stop": s.stops[nxt]["name"] if nxt < len(s.stops) else None,
        # schedule-based ETA that carries the current delay forward. Phase 10 replaces this with the ML model.
        "etas": {st["name"]: max(0, st["minutes"] + delay - now_min) for st in s.stops[nxt:]},
    }


def pace_ratio(s: BusState) -> float:
    """Observed minutes divided by scheduled minutes between the first stop seen on this trip and the last one reached.
    Above 1 means the bus is running slower than the timetable. 1.0 when there is not enough to tell."""
    last = s.visited_idx
    if last < 0 or len(s.visit_ts) < 2 or last not in s.visit_ts:
        return 1.0
    first = min(s.visit_ts)
    sched = s.stops[last]["minutes"] - s.stops[first]["minutes"]
    if last == first or sched <= 0:
        return 1.0
    elapsed = (s.visit_ts[last] - s.visit_ts[first]).total_seconds() / 60
    return min(3.0, max(0.3, elapsed / sched))
