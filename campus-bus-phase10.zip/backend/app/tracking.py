import asyncio
import time
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from fastapi import WebSocket

from . import config
from .ml import predictor
from .tracking_core import BusState, apply_location, snapshot

TZ = ZoneInfo(config.APP_TIMEZONE)


def local_minutes() -> int:
    n = datetime.now(TZ)
    return n.hour * 60 + n.minute


class TrackingManager:
    """In-memory current state of every running trip plus the connected sockets.
    Single-process only: running several workers needs a shared bus (Redis pub/sub) -- see README."""

    def __init__(self) -> None:
        self.states: dict[int, BusState] = {}
        self.fleet: set[WebSocket] = set()
        self.bus_subs: dict[int, set[WebSocket]] = {}

    def snap(self, s: BusState) -> dict:
        d = snapshot(s, datetime.now(timezone.utc), local_minutes(), config.STALE_SECONDS, config.DELAY_THRESHOLD_MIN)
        ml = s.ml
        meta = {"source": "schedule", "is_demo": True, "model_version": None, "per_stop": {}}
        if ml and time.monotonic() - s.last_ml < 30:  # a fresh estimate replaces the plain timetable numbers for stops still ahead
            d["etas"] = {name: (ml["per_stop"][name]["eta_min"] if name in ml["per_stop"] else eta) for name, eta in d["etas"].items()}
            meta = {**ml, "per_stop": {n: v for n, v in ml["per_stop"].items() if n in d["etas"]}}
        d["eta_meta"] = meta
        return d

    def refresh_ml(self, s: BusState) -> None:
        now = datetime.now(TZ)
        s.ml = predictor.estimate(s, local_minutes(), now.weekday(), config.DELAY_THRESHOLD_MIN)
        s.last_ml = time.monotonic()

    def all_snaps(self) -> list[dict]:
        return [self.snap(s) for s in self.states.values() if s.ts]

    def apply(self, s: BusState, lat: float, lng: float, ts: datetime) -> None:
        apply_location(s, lat, lng, ts, local_minutes(), config.VISIT_RADIUS_M)

    def drop(self, ws: WebSocket) -> None:
        self.fleet.discard(ws)
        for subs in self.bus_subs.values():
            subs.discard(ws)

    @staticmethod
    async def _send(ws: WebSocket, msg: dict) -> bool:
        try:
            await asyncio.wait_for(ws.send_json(msg), timeout=2)
            return True
        except Exception:
            return False

    async def broadcast(self, msg: dict, bus_id: int) -> None:
        targets = list(self.fleet | self.bus_subs.get(bus_id, set()))
        results = await asyncio.gather(*(self._send(ws, msg) for ws in targets))
        for ws, ok in zip(targets, results):
            if not ok:
                self.drop(ws)


manager = TrackingManager()
