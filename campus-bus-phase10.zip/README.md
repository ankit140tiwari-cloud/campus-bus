# Campus Bus — Identification and Management System

    frontend/   React + Vite + Tailwind + Leaflet
    backend/    FastAPI + SQLAlchemy + PostgreSQL + WebSocket
    docker-compose.yml   PostgreSQL 16

## Run with the real database and live tracking
1. `docker compose up -d db`
2. Backend (`backend/README.md`): install, `cp .env.example .env`, `python -m app.seed`, `uvicorn app.main:app --reload`
3. Frontend: `cd frontend && cp .env.example .env && npm install && npm run dev`

## Try live tracking (no phone needed)
1. Sign in as admin (admin@college.edu / admin123) and open **Trip Control**.
2. Pick BUS-12, tick **Simulate movement along the route**, press **START TRIP**.
3. In another tab, sign in as student@college.edu and open Live Tracking (or open admin Live Monitoring). The bus moves in real time.
4. Press **END TRIP**: the bus goes Offline everywhere.
Note: the simulation compares against the schedule times in your clock, so outside the 7-8 AM window the bus will show as Delayed. That is correct behaviour, not a bug.

For a real phone, open the app over HTTPS (browsers only give GPS to secure pages), sign in as admin, untick Simulate.

## Run frontend only (sample data)
`cd frontend && npm install && npm run dev` (VITE_USE_MOCK defaults to true; nothing is sent anywhere).

## Upgrading from the Phase 7 database
Phase 8 adds columns, and tables are created once rather than migrated. Reseed once: `python -m app.seed --reset` (this wipes the dev data). Proper migrations arrive in Phase 11.

## Notifications, complaints and push
- Admin: **Notifications** sends to all students, a route, or a bus. **Complaints** shows every report; changing the status notifies the student. **Students** activates or deactivates accounts.
- Automatic notifications: "departed" when a trip starts, "delayed" when a bus falls 5+ minutes behind (at most one per bus per 10 minutes). "Arriving soon" is not built yet.
- A student receives a notification when it targets all students, their route (a route that includes their default stop), a bus on such a route, or them personally. Their notification preferences filter the automatic ones; emergencies, announcements and complaint updates are always delivered.
- Complaint photos: JPEG, PNG or WebP up to 5 MB, checked by file content, stored under `backend/uploads/` and served only to the student who sent it and to admins.
- Browser push (optional): create a Firebase project, put the service-account JSON path in `backend/.env` (`FIREBASE_CREDENTIALS`), put the web-app keys in `frontend/.env` (`VITE_FIREBASE_*`), restart both, then students turn push on in Profile. Without this, everything else still works.

## Analytics (Phase 9)
Admin > Analytics shows nine charts for Today / Last 7 days / Last 30 days, computed from the database (`GET /api/analytics/dashboard?range=7d`). Each chart has a "View as table" fallback.
- **What the data can and cannot say:** boardings are not recorded, so "usage" means trips run and "demand" means students registered at a stop (and their scheduled pickup hour). Real ridership counts would need a boarding signal such as a tap or a student check-in.
- **Delays** come from stop visits, saved each time a tracked bus reaches a stop. Utilization is trips run divided by scheduled trips.
- **Empty at first?** A fresh database has no trips. Run `python -m app.seed --reset --demo-history` to invent 30 days of history (development only), or run trips from Trip Control.
- Day boundaries follow `APP_TIMEZONE`, not the server's clock.
- Existing dev databases need `python -m app.seed --reset` (new `stop_visits` table).

## ETA prediction (Phase 10)
Every ETA now carries its distance, a confidence label and an honest source tag: **Demo estimate** (timetable plus the bus's current delay) or **AI estimate** (trained model).
- **Model:** a scikit-learn random forest trained on recorded stop visits. Features: distance along the route, stops remaining, scheduled minutes, historical minutes per km for the route, time of day, day of week, current delay, and the pace the bus has kept so far on this trip.
- **It must earn its place.** It is judged on the most recent 20% of trips it never saw, and used only with 30+ tracked trips, 200+ examples, and an average error at least 5% better than the timetable. Otherwise estimates stay demo-labelled and the Analytics page says why.
- **Confidence** (High / Medium / Low) is how much the forest's trees disagree, ranked against its own behaviour on unseen trips. A timetable estimate is never "High".
- **Train it:** Admin > Analytics > "Train now", or `python -m app.ml.train`. Retrain as history grows. Try it on development data with `python -m app.seed --reset --demo-history` (the synthetic history has slow legs and busy Mondays built in, so the model has something to find; real data decides how well it works for you).
- Estimates refresh at most every 5 s per bus. `GET /api/buses/{id}/eta?stop_id=` returns one stop's ETA with distance, confidence and source.
- The model file is written and read only by the server (`backend/models/`). Do not load model files from untrusted sources.
- Model-and-timetable limits: straight-line distances between stops (no road routing), no traffic or weather data, and a bus that has not yet reached its first stop gets a timetable estimate.

## Still to come
Phase 11: testing, security hardening and deployment (migrations, HTTPS, rate limiting, running more than one worker).
