import { useState } from 'react';
import { Bar, BarChart, CartesianGrid, Cell, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { Info } from 'lucide-react';
import useAsync from '../../hooks/useAsync';
import { getAnalytics } from '../../services/analyticsService';
import { cx } from '../../utils/helpers';
import KpiCard from '../../components/KpiCard';
import ChartCard from '../../components/ChartCard';
import ErrorNote from '../../components/ErrorNote';
import EtaModelCard from '../../components/EtaModelCard';
import LoadingSkeleton from '../../components/LoadingSkeleton';

const RANGES = [['today', 'Today'], ['7d', 'Last 7 days'], ['30d', 'Last 30 days']];
const C = { primary: '#4f46e5', success: '#16a34a', warning: '#d97706', danger: '#dc2626', muted: '#94a3b8' };
const STATUS_COLOR = { Pending: C.warning, Investigating: C.primary, Resolved: C.success };
const AXIS = { fontSize: 12, fill: '#64748b' };
const GRID = <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />;

const day = (iso) => new Date(`${iso}T00:00:00`).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric' });
const cut = (s, n = 16) => (s.length > n ? `${s.slice(0, n - 1)}…` : s);
const val = (v, unit = '') => (v == null ? '—' : `${v}${unit}`);

// vertical-list bar chart: names on the left, so long route names stay readable on a phone
const HBar = ({ data, x, y, color = C.primary, domain, unit = '' }) => (
  <ResponsiveContainer width="100%" height="100%">
    <BarChart data={data} layout="vertical" margin={{ left: 0, right: 16, top: 4, bottom: 4 }}>
      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" horizontal={false} />
      <XAxis type="number" tick={AXIS} domain={domain} allowDecimals={false} />
      <YAxis type="category" dataKey={x} tick={AXIS} width={96} tickFormatter={(s) => cut(String(s))} />
      <Tooltip formatter={(v) => [`${v}${unit}`, '']} separator="" />
      <Bar dataKey={y} fill={color} radius={[0, 4, 4, 0]} />
    </BarChart>
  </ResponsiveContainer>
);

export default function Analytics() {
  const [range, setRange] = useState('7d');
  const { data: d, loading, error, reload } = useAsync(() => getAnalytics(range), [range]);

  const daily = d && d.daily.labels.map((l, i) => ({ label: day(l), date: l, trips: d.daily.trips[i], avg_delay: d.daily.avg_delay[i], complaints: d.daily.complaints[i] }));
  const util = d && d.utilization.filter((u) => u.pct != null);
  const unscheduled = d ? d.utilization.length - util.length : 0;
  const statusTotal = d ? d.complaints.by_status.reduce((a, b) => a + b.value, 0) : 0;
  const xInterval = daily && daily.length > 10 ? 3 : 0;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div><h1 className="text-xl font-bold text-slate-900">Analytics</h1>{d && <p className="text-sm text-slate-500">{d.from === d.to ? d.from : `${d.from} to ${d.to}`}</p>}</div>
        <div className="flex gap-2" role="group" aria-label="Time range">
          {RANGES.map(([k, l]) => (
            <button key={k} onClick={() => setRange(k)} aria-pressed={range === k}
              className={cx('min-h-[44px] rounded-full px-4 text-sm font-medium', range === k ? 'bg-brand-600 text-white' : 'border border-slate-300 bg-white text-slate-700 hover:bg-slate-50')}>{l}</button>
          ))}
        </div>
      </div>

      <div className="flex items-start gap-2 rounded-lg bg-brand-50 p-3 text-sm text-brand-700">
        <Info size={16} className="mt-0.5 shrink-0" aria-hidden />
        <p>{d?.sample ? 'Sample numbers (mock mode). ' : ''}Boardings are not recorded yet, so <b>usage</b> means trips run and <b>demand</b> means students registered at a stop. Delays come from buses reaching stops while tracked.</p>
      </div>

      {error ? <ErrorNote message={error} onRetry={reload} /> : loading || !d ? <div className="space-y-4"><LoadingSkeleton rows={2} /><LoadingSkeleton rows={3} /></div> : (
        <>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-6">
            <KpiCard label="Trips run" value={d.summary.trips} />
            <KpiCard label="Buses used" value={d.summary.buses_used} />
            <KpiCard label="Avg delay" value={val(d.summary.avg_delay_min, ' min')} tone={d.summary.avg_delay_min > 5 ? 'warning' : 'neutral'} />
            <KpiCard label="On time" value={val(d.summary.on_time_pct, '%')} tone={d.summary.on_time_pct != null && d.summary.on_time_pct < 70 ? 'danger' : 'success'} />
            <KpiCard label="Complaints" value={d.summary.complaints} />
            <KpiCard label="Resolved" value={val(d.summary.resolved_pct, '%')} />
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <ChartCard title="Daily bus usage" subtitle="Trips run per day" empty={!d.summary.trips} rows={daily} columns={[['label', 'Day'], ['trips', 'Trips']]}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={daily} margin={{ left: -16, right: 8, top: 4 }}>{GRID}<XAxis dataKey="label" tick={AXIS} interval={xInterval} /><YAxis tick={AXIS} allowDecimals={false} /><Tooltip /><Bar dataKey="trips" name="Trips" fill={C.primary} radius={[4, 4, 0, 0]} /></BarChart>
              </ResponsiveContainer>
            </ChartCard>

            <ChartCard title="Average delay" subtitle="Minutes behind schedule when reaching a stop, by day" empty={d.summary.avg_delay_min == null} rows={daily} columns={[['label', 'Day'], ['avg_delay', 'Avg delay (min)']]}>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={daily} margin={{ left: -16, right: 8, top: 4 }}>{GRID}<XAxis dataKey="label" tick={AXIS} interval={xInterval} /><YAxis tick={AXIS} /><Tooltip /><Line dataKey="avg_delay" name="Avg delay (min)" stroke={C.warning} strokeWidth={2} dot={{ r: 3 }} connectNulls={false} /></LineChart>
              </ResponsiveContainer>
            </ChartCard>

            <ChartCard title="Route-wise usage" subtitle="Trips run per route" empty={!d.summary.trips} rows={d.routes} columns={[['route', 'Route'], ['trips', 'Trips']]}>
              <HBar data={d.routes} x="route" y="trips" />
            </ChartCard>

            <ChartCard title="Most-used routes" subtitle="Registered students whose stop is on the route" empty={!d.routes.some((r) => r.students)} rows={d.routes} columns={[['route', 'Route'], ['students', 'Students']]}>
              <HBar data={[...d.routes].sort((a, b) => b.students - a.students)} x="route" y="students" color={C.success} />
            </ChartCard>

            <ChartCard title="Most-used stops" subtitle="Students with this as their default stop" empty={!d.stops.length} rows={d.stops} columns={[['stop', 'Stop'], ['students', 'Students']]}>
              <HBar data={d.stops} x="stop" y="students" color={C.primary} />
            </ChartCard>

            <ChartCard title="Delay by route" subtitle="Average minutes behind schedule" empty={!d.delays_by_route.length} rows={d.delays_by_route} columns={[['route', 'Route'], ['avg_delay', 'Avg delay (min)'], ['visits', 'Stop visits']]}>
              <HBar data={d.delays_by_route} x="route" y="avg_delay" color={C.warning} unit=" min" />
            </ChartCard>

            <ChartCard title="Bus utilization" subtitle={`Trips run as a share of scheduled trips${unscheduled ? ` (${unscheduled} bus${unscheduled > 1 ? 'es' : ''} with no schedule not shown)` : ''}`}
              empty={!util.length} rows={d.utilization} columns={[['bus', 'Bus'], ['scheduled', 'Scheduled'], ['run', 'Run'], ['pct', 'Utilization %']]}>
              <HBar data={util} x="bus" y="pct" color={C.primary} domain={[0, 100]} unit="%" />
            </ChartCard>

            <ChartCard title="Student demand by time" subtitle="Students by the scheduled pickup hour at their stop" empty={!d.demand.length} rows={d.demand} columns={[['hour', 'Hour'], ['students', 'Students']]}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={d.demand} margin={{ left: -16, right: 8, top: 4 }}>{GRID}<XAxis dataKey="hour" tick={AXIS} /><YAxis tick={AXIS} allowDecimals={false} /><Tooltip /><Bar dataKey="students" name="Students" fill={C.success} radius={[4, 4, 0, 0]} /></BarChart>
              </ResponsiveContainer>
            </ChartCard>

            <ChartCard title="Complaints by status" empty={!statusTotal} rows={d.complaints.by_status} columns={[['label', 'Status'], ['value', 'Complaints']]}>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={d.complaints.by_status} dataKey="value" nameKey="label" innerRadius={50} outerRadius={82} paddingAngle={2} label={({ label, value }) => (value ? `${label} ${value}` : '')} labelLine={false}>
                    {d.complaints.by_status.map((s) => <Cell key={s.label} fill={STATUS_COLOR[s.label]} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </ChartCard>

            <ChartCard title="Complaints by type" empty={!d.complaints.by_type.length} rows={d.complaints.by_type} columns={[['label', 'Type'], ['value', 'Complaints']]}>
              <HBar data={d.complaints.by_type} x="label" y="value" color={C.danger} />
            </ChartCard>
          </div>
          <EtaModelCard />
        </>
      )}
    </div>
  );
}
