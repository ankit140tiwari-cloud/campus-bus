import Card from './Card';

// A titled chart with a text fallback: `rows` + `columns` ([[key, label], ...]) become a "View as table" section for screen readers and print.
export default function ChartCard({ title, subtitle, empty, emptyText = 'No data for this period.', rows, columns, className, children }) {
  return (
    <Card title={title} className={className}>
      {subtitle && <p className="-mt-2 mb-3 text-xs text-slate-500">{subtitle}</p>}
      {empty ? <p className="grid h-56 place-items-center text-sm text-slate-500">{emptyText}</p> : <div className="h-56 w-full sm:h-64">{children}</div>}
      {!empty && rows && columns && (
        <details className="mt-3 text-sm">
          <summary className="cursor-pointer text-brand-600">View as table</summary>
          <div className="mt-2 max-h-48 overflow-auto">
            <table className="w-full text-left text-xs">
              <thead className="text-slate-500"><tr>{columns.map(([k, l]) => <th key={k} className="py-1 pr-3 font-medium">{l}</th>)}</tr></thead>
              <tbody>{rows.map((r, i) => <tr key={i} className="border-t border-slate-100">{columns.map(([k]) => <td key={k} className="py-1 pr-3">{r[k] ?? '—'}</td>)}</tr>)}</tbody>
            </table>
          </div>
        </details>
      )}
    </Card>
  );
}
