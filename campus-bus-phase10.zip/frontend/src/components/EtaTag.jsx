// The small line under an ETA: distance, whether it is a timetable-based demo estimate or a trained-model estimate, and confidence.
export default function EtaTag({ meta, km }) {
  if (!meta && km == null) return null;
  const demo = !meta || meta.isDemo;
  const why = demo
    ? 'Demo estimate: based on the timetable and the bus’s current delay, not a trained prediction.'
    : 'Estimate from a model trained on past trips of this route.';
  return (
    <span className="mt-0.5 block text-xs font-normal text-slate-500" title={why}>
      {km != null && `${km} km · `}{demo ? 'Demo estimate' : 'AI estimate'}{meta?.confidence && ` · ${meta.confidence} confidence`}
    </span>
  );
}
