import { useState } from 'react';
import useAsync from '../hooks/useAsync';
import { getEtaModel, trainEtaModel } from '../services/analyticsService';
import { useToast } from './Toast';
import Card from './Card';
import Badge from './Badge';
import Button from './Button';
import ErrorNote from './ErrorNote';

const TONE = { trained: 'success', demo: 'warning', none: 'neutral' };
const LABEL = { trained: 'Trained model in use', demo: 'Not used (demo estimates)', none: 'No model yet' };

export default function EtaModelCard() {
  const { data: m, loading, error, reload } = useAsync(getEtaModel, []);
  const toast = useToast();
  const [busy, setBusy] = useState(false);

  const train = async () => {
    setBusy(true);
    try { const r = await trainEtaModel(); toast(r.status === 'trained' ? 'Model trained and now in use' : 'Training finished. The model was not used.'); reload(); }
    catch (e) { toast(e.message, 'error'); } finally { setBusy(false); }
  };

  return (
    <Card title="ETA prediction model" action={m && <Badge tone={TONE[m.status]}>{LABEL[m.status]}</Badge>}>
      {error ? <ErrorNote message={error} onRetry={reload} /> : loading || !m ? <p className="text-sm text-slate-500">Loading…</p> : (
        <div className="space-y-3 text-sm">
          <p className="text-slate-600">{m.reason}</p>
          <dl className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <div><dt className="text-slate-500">Trips with stop records</dt><dd className="font-semibold">{m.available_trips} <span className="font-normal text-slate-500">of {m.limits.min_trips} needed</span></dd></div>
            <div><dt className="text-slate-500">Error, model</dt><dd className="font-semibold">{m.mae_model != null ? `${m.mae_model} min` : '—'}</dd></div>
            <div><dt className="text-slate-500">Error, timetable</dt><dd className="font-semibold">{m.mae_baseline != null ? `${m.mae_baseline} min` : '—'}</dd></div>
            <div><dt className="text-slate-500">Trained</dt><dd className="font-semibold">{m.trained_at ? new Date(m.trained_at).toLocaleDateString('en-IN') : '—'}</dd></div>
          </dl>
          <p className="text-xs text-slate-500">Error is the average minutes off on recent trips the model had not seen. A model is used only after {m.limits.min_trips}+ trips and when it beats the timetable by {m.limits.min_gain_pct}% or more. Confidence labels are relative to this model's usual uncertainty.</p>
          <Button variant="secondary" loading={busy} onClick={train}>Train now</Button>
        </div>
      )}
    </Card>
  );
}
