const R = 6371;
const rad = (d) => (d * Math.PI) / 180;

export function haversineKm(a, b) {
  const h = Math.sin(rad(b.lat - a.lat) / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(rad(b.lng - a.lng) / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

// Distance along the route from a bus's position to a later stop: to the next stop first, then stop to stop.
export function routeDistanceKm(pos, stops, curIdx, targetIdx) {
  if (!pos || targetIdx <= curIdx || !stops[curIdx + 1]) return undefined;
  let km = haversineKm(pos, stops[curIdx + 1]);
  for (let i = curIdx + 1; i < targetIdx; i++) km += haversineKm(stops[i], stops[i + 1]);
  return Math.round(km * 10) / 10;
}
