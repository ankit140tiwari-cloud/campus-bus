"""Loads demo data matching the frontend sample data.  Run:  python -m app.seed   (add --reset to wipe first)"""
import os
import sys
from datetime import time

from sqlalchemy import select

from . import models as m
from .database import Base, SessionLocal, engine
from .security import hash_password

COORDS = {"Habibganj": (23.2296, 77.4393), "MP Nagar": (23.2332, 77.4344), "Board Office": (23.23, 77.43), "College": (23.2599, 77.4126),
          "Kolar": (23.17, 77.42), "New Market": (23.233, 77.399), "Roshanpura": (23.238, 77.405), "Bairagarh": (23.279, 77.338)}
ROUTES = [
    ("Habibganj – College", [("Habibganj", "07:15"), ("MP Nagar", "07:25"), ("Board Office", "07:35"), ("College", "07:50")]),
    ("Kolar – College", [("Kolar", "07:05"), ("New Market", "07:25"), ("Roshanpura", "07:38"), ("College", "07:55")]),
    ("Bairagarh – College", [("Bairagarh", "07:10"), ("Roshanpura", "07:30"), ("New Market", "07:42"), ("College", "08:00")]),
]
BUSES = [("BUS-12", 1, "Active"), ("BUS-07", 2, "Active"), ("BUS-21", 3, "Active"), ("BUS-03", 1, "Inactive"), ("BUS-05", 1, "Active"),
         ("BUS-09", 2, "Active"), ("BUS-14", 3, "Active"), ("BUS-18", 2, "Inactive"), ("BUS-25", 3, "Active")]
DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]


def t(s: str) -> time:
    h, mi = s.split(":")
    return time(int(h), int(mi))


def main() -> None:
    if "--reset" in sys.argv:
        Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        if db.scalar(select(m.User.id).limit(1)):
            print("Database already has data. Use --reset to wipe and reseed.")
            return
        stops = {n: m.Stop(stop_name=n, latitude=lat, longitude=lng) for n, (lat, lng) in COORDS.items()}
        db.add_all(stops.values())
        routes = []
        for name, plan in ROUTES:
            r = m.Route(route_name=name, start_point=plan[0][0], destination=plan[-1][0])
            db.add(r)
            db.flush()
            for i, (sn, tm) in enumerate(plan, 1):
                db.add(m.RouteStop(route_id=r.id, stop_id=stops[sn].id, stop_order=i, expected_time=t(tm)))
            routes.append((r, plan))
        db.flush()
        for i, (num, ridx, status) in enumerate(BUSES, 1):
            route, plan = routes[ridx - 1]
            bus = m.Bus(bus_number=num, registration_number=f"MP04 BU {1000 + i * 37}", capacity=40 + i * 4, route_id=route.id, status=status)
            db.add(bus)
            db.flush()
            if status != "Active":
                continue
            trips = [(plan[0][1], plan[-1][1], DAYS), ("16:30", "17:15", DAYS[:5])]
            if num == "BUS-21":
                trips.append(("13:30", "14:15", DAYS[:5]))
            for dep, arr, days in trips:
                for d in days:
                    db.add(m.Schedule(bus_id=bus.id, route_id=route.id, day=d, departure_time=t(dep), arrival_time=t(arr)))
        db.add(m.User(name="Transport Office", email="admin@college.edu", role="admin", password_hash=hash_password(os.getenv("SEED_ADMIN_PASSWORD", "admin123"))))
        db.add(m.User(name="Aarav Sharma", email="student@college.edu", role="student", student_id="CS2021045", department="Computer Science",
                      default_stop_id=stops["MP Nagar"].id, password_hash=hash_password(os.getenv("SEED_STUDENT_PASSWORD", "student123"))))
        db.commit()
        print("Seeded: 8 stops, 3 routes, 9 buses, schedules, 1 admin, 1 student.")


if __name__ == "__main__":
    main()
