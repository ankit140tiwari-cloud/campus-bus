from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from . import models  # noqa: F401  (registers tables on Base.metadata)
from .config import CORS_ORIGINS
from .database import Base, engine
from .routers import analytics, auth, buses, routes, schedules, stops, students


@asynccontextmanager
async def lifespan(_: FastAPI):
    Base.metadata.create_all(engine)  # dev convenience; Phase 11 moves this to Alembic migrations
    yield


app = FastAPI(title="Campus Bus API", description="Identification and Management System", version="0.5.0", lifespan=lifespan)

app.add_middleware(CORSMiddleware, allow_origins=CORS_ORIGINS, allow_credentials=False, allow_methods=["*"], allow_headers=["*"])

for r in (auth.router, buses.router, routes.router, stops.router, schedules.router, students.router, analytics.router):
    app.include_router(r, prefix="/api")


@app.get("/api/health")
def health():
    return {"status": "ok"}
