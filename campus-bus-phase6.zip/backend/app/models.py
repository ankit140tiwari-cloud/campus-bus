from datetime import datetime, time
from typing import Optional

from sqlalchemy import (Boolean, DateTime, Float, ForeignKey, Integer, String, Text, Time,
                        UniqueConstraint, func)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(20), default="student")  # student | admin
    student_id: Mapped[str | None] = mapped_column(String(40), unique=True, nullable=True)
    department: Mapped[str | None] = mapped_column(String(120), nullable=True)
    default_stop_id: Mapped[int | None] = mapped_column(ForeignKey("stops.id", ondelete="SET NULL"), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="Active")  # Active | Inactive
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    default_stop: Mapped[Optional["Stop"]] = relationship()


class Stop(Base):
    __tablename__ = "stops"
    id: Mapped[int] = mapped_column(primary_key=True)
    stop_name: Mapped[str] = mapped_column(String(120), unique=True)
    latitude: Mapped[float] = mapped_column(Float)
    longitude: Mapped[float] = mapped_column(Float)
    status: Mapped[str] = mapped_column(String(20), default="Active")

    route_links: Mapped[list["RouteStop"]] = relationship(back_populates="stop", cascade="all, delete-orphan")


class Route(Base):
    __tablename__ = "routes"
    id: Mapped[int] = mapped_column(primary_key=True)
    route_name: Mapped[str] = mapped_column(String(120), unique=True)
    start_point: Mapped[str] = mapped_column(String(120))
    destination: Mapped[str] = mapped_column(String(120))
    status: Mapped[str] = mapped_column(String(20), default="Active")

    route_stops: Mapped[list["RouteStop"]] = relationship(back_populates="route", cascade="all, delete-orphan")
    buses: Mapped[list["Bus"]] = relationship(back_populates="route")
    schedules: Mapped[list["Schedule"]] = relationship(back_populates="route", cascade="all, delete-orphan")


class RouteStop(Base):
    __tablename__ = "route_stops"
    __table_args__ = (UniqueConstraint("route_id", "stop_id", name="uq_route_stop"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    route_id: Mapped[int] = mapped_column(ForeignKey("routes.id", ondelete="CASCADE"), index=True)
    stop_id: Mapped[int] = mapped_column(ForeignKey("stops.id", ondelete="CASCADE"), index=True)
    stop_order: Mapped[int] = mapped_column(Integer)
    expected_time: Mapped[time] = mapped_column(Time)

    route: Mapped[Route] = relationship(back_populates="route_stops")
    stop: Mapped[Stop] = relationship(back_populates="route_links")


class Bus(Base):
    __tablename__ = "buses"
    id: Mapped[int] = mapped_column(primary_key=True)
    bus_number: Mapped[str] = mapped_column(String(40), unique=True)
    registration_number: Mapped[str] = mapped_column(String(40), unique=True)
    capacity: Mapped[int] = mapped_column(Integer)
    # Practical addition to the spec'd columns: the route a bus is normally assigned to.
    route_id: Mapped[int | None] = mapped_column(ForeignKey("routes.id", ondelete="SET NULL"), nullable=True, index=True)
    status: Mapped[str] = mapped_column(String(20), default="Active")  # Active | Inactive

    route: Mapped[Optional[Route]] = relationship(back_populates="buses")
    schedules: Mapped[list["Schedule"]] = relationship(back_populates="bus", cascade="all, delete-orphan")
    locations: Mapped[list["BusLocation"]] = relationship(cascade="all, delete-orphan")


class Schedule(Base):
    __tablename__ = "schedules"
    __table_args__ = (UniqueConstraint("bus_id", "day", "departure_time", name="uq_bus_day_departure"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    bus_id: Mapped[int] = mapped_column(ForeignKey("buses.id", ondelete="CASCADE"), index=True)
    route_id: Mapped[int] = mapped_column(ForeignKey("routes.id", ondelete="CASCADE"), index=True)
    day: Mapped[str] = mapped_column(String(3))  # Mon..Sun
    departure_time: Mapped[time] = mapped_column(Time)
    arrival_time: Mapped[time] = mapped_column(Time)
    status: Mapped[str] = mapped_column(String(20), default="Active")

    bus: Mapped[Bus] = relationship(back_populates="schedules")
    route: Mapped[Route] = relationship(back_populates="schedules")


# ---- Tables used by later phases (created now so the schema matches the spec) ----

class BusLocation(Base):  # Phase 7
    __tablename__ = "bus_locations"
    id: Mapped[int] = mapped_column(primary_key=True)
    bus_id: Mapped[int] = mapped_column(ForeignKey("buses.id", ondelete="CASCADE"), index=True)
    latitude: Mapped[float] = mapped_column(Float)
    longitude: Mapped[float] = mapped_column(Float)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), index=True)


class Notification(Base):  # Phase 8
    __tablename__ = "notifications"
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(160))
    message: Mapped[str] = mapped_column(Text)
    priority: Mapped[str] = mapped_column(String(20), default="Normal")
    target_type: Mapped[str] = mapped_column(String(20), default="all")  # all | route | bus
    target_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class NotificationRead(Base):
    """Per-student read state. The spec's single read_status column on notifications cannot work
    when one announcement goes to many students, so read state lives here instead."""
    __tablename__ = "notification_reads"
    notification_id: Mapped[int] = mapped_column(ForeignKey("notifications.id", ondelete="CASCADE"), primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)


class Complaint(Base):  # Phase 8
    __tablename__ = "complaints"
    id: Mapped[int] = mapped_column(primary_key=True)
    student_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    bus_id: Mapped[int | None] = mapped_column(ForeignKey("buses.id", ondelete="SET NULL"), nullable=True)
    route_id: Mapped[int | None] = mapped_column(ForeignKey("routes.id", ondelete="SET NULL"), nullable=True)
    stop_id: Mapped[int | None] = mapped_column(ForeignKey("stops.id", ondelete="SET NULL"), nullable=True)
    issue_type: Mapped[str] = mapped_column(String(40))
    description: Mapped[str] = mapped_column(Text)
    image_path: Mapped[str | None] = mapped_column(String(255), nullable=True)
    priority: Mapped[str] = mapped_column(String(20), default="Medium")
    status: Mapped[str] = mapped_column(String(20), default="Pending")  # Pending | Investigating | Resolved
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
