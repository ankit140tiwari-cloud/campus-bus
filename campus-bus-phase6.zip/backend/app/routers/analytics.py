from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import require_admin
from ..models import Bus, Complaint, Route, Stop, User

router = APIRouter(prefix="/analytics", tags=["analytics"])


@router.get("/overview")
def overview(db: Session = Depends(get_db), _: User = Depends(require_admin)):
    def n(stmt):
        return db.scalar(stmt) or 0

    return {
        "total_buses": n(select(func.count()).select_from(Bus)),
        "active_buses": n(select(func.count()).select_from(Bus).where(Bus.status == "Active")),
        "inactive_buses": n(select(func.count()).select_from(Bus).where(Bus.status == "Inactive")),
        "total_routes": n(select(func.count()).select_from(Route)),
        "total_stops": n(select(func.count()).select_from(Stop)),
        "students": n(select(func.count()).select_from(User).where(User.role == "student")),
        "pending_complaints": n(select(func.count()).select_from(Complaint).where(Complaint.status == "Pending")),
        # delayed / offline need live GPS data, which arrives in Phase 7
    }
