from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user
from ..models import Stop, User
from ..schemas import LoginIn, PasswordIn, ProfileIn, RegisterIn
from ..security import DUMMY_HASH, create_token, hash_password, verify_password

router = APIRouter(prefix="/auth", tags=["auth"])


def user_out(u: User) -> dict:
    return {"id": u.id, "name": u.name, "email": u.email, "role": u.role, "student_id": u.student_id,
            "department": u.department, "default_stop_id": u.default_stop_id,
            "default_stop": u.default_stop.stop_name if u.default_stop else None, "status": u.status}


@router.post("/login")
def login(data: LoginIn, db: Session = Depends(get_db)):
    ident = data.identifier.lower()
    user = db.scalar(select(User).where((func.lower(User.email) == ident) | (func.lower(User.student_id) == ident)))
    ok = verify_password(data.password, user.password_hash if user else DUMMY_HASH)
    if not user or not ok:
        raise HTTPException(401, "Email / Student ID or password is incorrect.")
    if user.status != "Active":
        raise HTTPException(403, "This account is deactivated. Contact the transport office.")
    return {"token": create_token(user.id, user.role, data.remember), "user": user_out(user)}


@router.post("/register", status_code=201)
def register(data: RegisterIn, db: Session = Depends(get_db)):
    """Self-registration always creates a student. Admin accounts are created by seed/admin tooling only."""
    if db.scalar(select(User).where(func.lower(User.email) == data.email.lower())):
        raise HTTPException(409, "An account with this email already exists.")
    if db.scalar(select(User).where(func.lower(User.student_id) == data.student_id.lower())):
        raise HTTPException(409, "An account with this Student ID already exists.")
    if data.default_stop_id is not None and db.get(Stop, data.default_stop_id) is None:
        raise HTTPException(400, "Default stop does not exist.")
    user = User(name=data.name, email=data.email.lower(), password_hash=hash_password(data.password), role="student",
                student_id=data.student_id, department=data.department, default_stop_id=data.default_stop_id)
    db.add(user)
    db.commit()
    db.refresh(user)
    return {"token": create_token(user.id, user.role), "user": user_out(user)}


@router.get("/me")
def me(user: User = Depends(get_current_user)):
    return user_out(user)


@router.put("/me")
def update_me(data: ProfileIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if data.name is not None:
        user.name = data.name
    if data.department is not None:
        user.department = data.department
    if data.default_stop_name is not None:
        stop = db.scalar(select(Stop).where(Stop.stop_name == data.default_stop_name))
        if stop is None:
            raise HTTPException(400, "That stop does not exist.")
        user.default_stop_id = stop.id
    db.commit()
    db.refresh(user)
    return user_out(user)


@router.post("/change-password", status_code=204)
def change_password(data: PasswordIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not verify_password(data.current_password, user.password_hash):
        raise HTTPException(400, "Current password is incorrect.")
    user.password_hash = hash_password(data.new_password)
    db.commit()
