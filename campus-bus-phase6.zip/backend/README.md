# Campus Bus API (FastAPI + PostgreSQL)

    docker compose up -d db            # from the project root
    cd backend
    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    cp .env.example .env               # then set SECRET_KEY
    python -m app.seed                 # demo data (add --reset to wipe)
    uvicorn app.main:app --reload      # http://localhost:8000/docs

Demo logins: admin@college.edu / admin123, student@college.edu / student123 (dev seed only).
