import { STORAGE_KEY } from '../utils/constants';
import { USE_MOCK } from '../utils/config';
import { api } from './api';

const DEMO_USERS = [
  { identifier: 'student@college.edu', studentId: 'CS2021045', password: 'student123', user: { id: 1, name: 'Aarav Sharma', role: 'student', studentId: 'CS2021045', email: 'student@college.edu', department: 'Computer Science', defaultStop: 'MP Nagar' } },
  { identifier: 'admin@college.edu', studentId: null, password: 'admin123', user: { id: 2, name: 'Transport Office', role: 'admin', email: 'admin@college.edu' } },
];

const mapUser = (u) => ({ id: u.id, name: u.name, email: u.email, role: u.role, studentId: u.student_id, department: u.department, defaultStop: u.default_stop });

export async function login({ identifier, password, remember }) {
  let result;
  if (USE_MOCK) {
    await new Promise((r) => setTimeout(r, 600));
    const id = identifier.trim().toLowerCase();
    const match = DEMO_USERS.find((u) => (u.identifier === id || u.studentId?.toLowerCase() === id) && u.password === password);
    if (!match) throw new Error('Email / Student ID or password is incorrect.');
    result = { token: 'demo-token', user: match.user };
  } else {
    const r = await api('/auth/login', { method: 'POST', body: { identifier, password, remember: !!remember } });
    result = { token: r.token, user: mapUser(r.user) };
  }
  localStorage.removeItem(STORAGE_KEY);
  sessionStorage.removeItem(STORAGE_KEY);
  (remember ? localStorage : sessionStorage).setItem(STORAGE_KEY, JSON.stringify(result));
  return result;
}

export function logout() {
  localStorage.removeItem(STORAGE_KEY);
  sessionStorage.removeItem(STORAGE_KEY);
}

// Returns the fields to merge into the signed-in user.
export async function updateProfile({ name, department, defaultStop }) {
  if (USE_MOCK) return { name, department, defaultStop };
  const u = mapUser(await api('/auth/me', { method: 'PUT', body: { name, department, default_stop_name: defaultStop } }));
  return { name: u.name, department: u.department, defaultStop: u.defaultStop };
}
