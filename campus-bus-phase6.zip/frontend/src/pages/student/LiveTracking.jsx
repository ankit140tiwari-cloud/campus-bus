import { useSearchParams } from 'react-router-dom';
import { Info } from 'lucide-react';
import useAuth from '../../hooks/useAuth';
import useAsync from '../../hooks/useAsync';
import { getBuses, getBusDetail } from '../../services/busService';
import { stopsForMap, lineFor, busForMap } from '../../utils/mapHelpers';
import Card from '../../components/Card';
import Badge from '../../components/Badge';
import Select from '../../components/Select';
import StopTimeline from '../../components/StopTimeline';
import MapComponent from '../../components/MapComponent';
import LoadingSkeleton from '../../components/LoadingSkeleton';

export default function LiveTracking() {
  const { user } = useAuth();
  const [params, setParams] = useSearchParams();
  const buses = useAsync(getBuses, []);
  const number = params.get('bus') || 'BUS-12';
  const stop = params.get('stop') || user.defaultStop;
  const detail = useAsync(() => getBusDetail(number, stop), [number, stop]);
  const d = detail.data;
  const bus = d && busForMap(d);

  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <h1 className="text-xl font-bold text-slate-900">Live tracking</h1>
      <Select label="Bus" value={number} onChange={(e) => setParams({ bus: e.target.value, stop })}
        options={(buses.data || []).filter((b) => b.status !== 'Offline').map((b) => ({ value: b.number, label: `${b.number} · ${b.routeName}` }))} />

      {detail.loading || !d ? <LoadingSkeleton rows={3} /> : (
        <>
          <MapComponent className="h-72 sm:h-96" label={`Map showing ${d.number} on ${d.routeName}`} stops={stopsForMap(d.stops)} lines={[lineFor(d.routeId, d.stops)]}
            buses={bus ? [bus] : []} highlight={stop} />
          <div className="flex items-start gap-2 rounded-lg bg-brand-50 p-3 text-sm text-brand-700">
            <Info size={16} className="mt-0.5 shrink-0" aria-hidden />
            <p>The bus position is simulated from sample data. Real GPS tracking arrives in Phase 7.</p>
          </div>
          <Card>
            <div className="flex items-center justify-between"><p className="font-bold text-slate-900">{d.number}</p><Badge>{d.status}</Badge></div>
            <dl className="mt-3 grid grid-cols-3 gap-3 text-sm">
              <div><dt className="text-slate-500">Now at</dt><dd className="font-semibold">{d.currentLocation}</dd></div>
              <div><dt className="text-slate-500">Next stop</dt><dd className="font-semibold">{d.nextStop}</dd></div>
              <div><dt className="text-slate-500">ETA to {stop}</dt><dd className="font-semibold">{d.eta !== undefined ? `${d.eta} min` : 'Passed'}</dd></div>
            </dl>
          </Card>
          <Card title={d.routeName}><StopTimeline stops={d.stops} currentIdx={d.currentIdx} highlight={stop} /></Card>
        </>
      )}
    </div>
  );
}
