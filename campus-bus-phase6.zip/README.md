# Campus Bus — Identification and Management System

    frontend/   React + Vite + Tailwind
    backend/    FastAPI + SQLAlchemy + PostgreSQL
    docker-compose.yml   PostgreSQL 16

## Run with the real database (Phase 5)
1. `docker compose up -d db`
2. Backend: see `backend/README.md` (install, `cp .env.example .env`, `python -m app.seed`, `uvicorn app.main:app --reload`)
3. Frontend: `cd frontend && cp .env.example .env && npm install && npm run dev`

## Run frontend only (sample data)
`cd frontend && npm install && npm run dev` (no .env needed; VITE_USE_MOCK defaults to true)

## What uses the database in Phase 5
Login, profile, password change, buses, routes, stops, schedules, student Routes and Schedule pages.
Still sample data until later phases: Find Bus / Live Tracking / ETA (Phase 7), student notifications and complaints (Phase 8),
admin Dashboard fleet status, Live Monitoring (Phase 7), Students, Notifications, Complaints (Phase 8), Analytics (Phase 9).
