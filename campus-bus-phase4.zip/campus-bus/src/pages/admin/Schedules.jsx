import { useState } from 'react';
import { Pencil, Trash2, Power, CalendarX } from 'lucide-react';
import useAsync from '../../hooks/useAsync';
import { listSchedules, listRoutes, listBusOptions, saveSchedule, setScheduleActive, deleteSchedule } from '../../services/adminCrudService';
import { useToast } from '../../components/Toast';
import { fmt12 } from '../../utils/helpers';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import RowActions from '../../components/RowActions';
import ConfirmDialog from '../../components/ConfirmDialog';
import ErrorNote from '../../components/ErrorNote';
import Modal from '../../components/Modal';
import Input from '../../components/Input';
import Select from '../../components/Select';
import Badge from '../../components/Badge';
import Button from '../../components/Button';
import Card from '../../components/Card';
import EmptyState from '../../components/EmptyState';
import LoadingSkeleton from '../../components/LoadingSkeleton';

const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const blank = { busId: '', routeId: '', day: 'Mon', departure: '', arrival: '', active: true };

export default function Schedules() {
  const { data, loading, error, reload } = useAsync(listSchedules, []);
  const routes = useAsync(listRoutes, []);
  const buses = useAsync(listBusOptions, []);
  const toast = useToast();
  const [day, setDay] = useState('All');
  const [modal, setModal] = useState(null);
  const [form, setForm] = useState(blank);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [del, setDel] = useState(null);

  const openForm = (s) => { setForm(s ? { ...s } : blank); setErr(''); setModal({ schedule: s }); };
  const run = async (fn, okMsg) => {
    setBusy(true); setErr('');
    try { await fn(); toast(okMsg); setModal(null); setDel(null); await reload(); }
    catch (e) { setErr(e.message); toast(e.message, 'error'); }
    finally { setBusy(false); }
  };
  const pickBus = (e) => {
    const bus = (buses.data || []).find((b) => String(b.id) === e.target.value);
    setForm({ ...form, busId: bus ? bus.id : '', routeId: form.routeId || bus?.routeId || '' });
  };

  const rows = (data || []).filter((s) => day === 'All' || s.day === day).sort((a, b) => a.busNumber.localeCompare(b.busNumber) || DAYS.indexOf(a.day) - DAYS.indexOf(b.day) || a.departure.localeCompare(b.departure));
  const columns = [
    { key: 'busNumber', label: 'Bus' }, { key: 'routeName', label: 'Route' }, { key: 'day', label: 'Day' },
    { key: 'departure', label: 'Departure', render: (s) => fmt12(s.departure) }, { key: 'arrival', label: 'Expected arrival', render: (s) => fmt12(s.arrival) },
    { key: 'active', label: 'Status', render: (s) => <Badge>{s.active ? 'Active' : 'Inactive'}</Badge> },
    { key: 'actions', label: 'Actions', render: (s) => (
      <RowActions actions={[{ label: 'Edit schedule', icon: Pencil, onClick: () => openForm(s) },
        { label: s.active ? 'Disable schedule' : 'Enable schedule', icon: Power, onClick: () => run(() => setScheduleActive(s.id, !s.active), s.active ? 'Schedule disabled' : 'Schedule enabled') },
        { label: 'Delete schedule', icon: Trash2, danger: true, onClick: () => setDel(s) }]} />) },
  ];

  return (
    <div className="space-y-4">
      <PageHeader title="Schedule management" subtitle="Sample data until Phase 5." addLabel="Add schedule" onAdd={() => openForm(null)} />
      <Select label="Day" options={['All', ...DAYS]} value={day} onChange={(e) => setDay(e.target.value)} className="max-w-[180px]" />
      {loading ? <LoadingSkeleton rows={4} /> : error ? <ErrorNote message={error} onRetry={reload} /> : rows.length
        ? <DataTable columns={columns} rows={rows} /> : <Card><EmptyState icon={CalendarX} title="No schedules" message="Add a schedule or choose another day." /></Card>}

      <Modal open={!!modal} title={modal?.schedule ? 'Edit schedule' : 'Add schedule'} onClose={() => setModal(null)}
        footer={<><Button variant="secondary" onClick={() => setModal(null)}>Cancel</Button><Button loading={busy} onClick={() => run(() => saveSchedule({ ...form, id: modal.schedule?.id }), 'Schedule saved')}>Save schedule</Button></>}>
        <div className="grid gap-4 sm:grid-cols-2">
          {err && <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700 sm:col-span-2">{err}</p>}
          <Select label="Bus" placeholder="Select bus" options={(buses.data || []).map((b) => ({ value: String(b.id), label: b.number }))} value={String(form.busId)} onChange={pickBus} />
          <Select label="Route" placeholder="Select route" options={(routes.data || []).map((r) => ({ value: r.id, label: `${r.id} · ${r.name}` }))} value={form.routeId} onChange={(e) => setForm({ ...form, routeId: e.target.value })} />
          <Select label="Day" options={DAYS} value={form.day} onChange={(e) => setForm({ ...form, day: e.target.value })} />
          <label className="flex min-h-[44px] items-center gap-2 self-end text-sm"><input type="checkbox" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} className="h-4 w-4 rounded border-slate-300" />Schedule is active</label>
          <Input label="Departure time" type="time" value={form.departure} onChange={(e) => setForm({ ...form, departure: e.target.value })} />
          <Input label="Expected arrival time" type="time" value={form.arrival} onChange={(e) => setForm({ ...form, arrival: e.target.value })} />
        </div>
      </Modal>

      <ConfirmDialog open={!!del} title="Delete schedule?" loading={busy}
        message={`Delete the ${del ? fmt12(del.departure) : ''} trip for ${del?.busNumber} on ${del?.day}? This cannot be undone.`}
        onClose={() => setDel(null)} onConfirm={() => run(() => deleteSchedule(del.id), 'Schedule deleted')} />
    </div>
  );
}
