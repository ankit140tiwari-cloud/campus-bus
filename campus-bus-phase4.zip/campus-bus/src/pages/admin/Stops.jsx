import { useState } from 'react';
import { Pencil, Trash2, MapPin } from 'lucide-react';
import useAsync from '../../hooks/useAsync';
import { listStops, listRoutes, saveStop, deleteStop } from '../../services/adminCrudService';
import { useToast } from '../../components/Toast';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import RowActions from '../../components/RowActions';
import ConfirmDialog from '../../components/ConfirmDialog';
import ErrorNote from '../../components/ErrorNote';
import Modal from '../../components/Modal';
import Input from '../../components/Input';
import Select from '../../components/Select';
import Badge from '../../components/Badge';
import Button from '../../components/Button';
import Card from '../../components/Card';
import EmptyState from '../../components/EmptyState';
import LoadingSkeleton from '../../components/LoadingSkeleton';

const blank = { name: '', lat: '', lng: '', status: 'Active', routeId: '', order: '' };

export default function Stops() {
  const { data, loading, error, reload } = useAsync(listStops, []);
  const routes = useAsync(listRoutes, []);
  const toast = useToast();
  const [q, setQ] = useState('');
  const [modal, setModal] = useState(null);
  const [form, setForm] = useState(blank);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [del, setDel] = useState(null);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const openForm = (s) => { setForm(s ? { ...s, lat: String(s.lat), lng: String(s.lng), order: String(s.order) } : blank); setErr(''); setModal({ stop: s }); };
  const run = async (fn, okMsg) => {
    setBusy(true); setErr('');
    try { await fn(); toast(okMsg); setModal(null); setDel(null); await reload(); }
    catch (e) { setErr(e.message); toast(e.message, 'error'); }
    finally { setBusy(false); }
  };

  const rows = (data || []).filter((s) => `${s.name} ${s.routeNames.join(' ')}`.toLowerCase().includes(q.toLowerCase()));
  const columns = [
    { key: 'name', label: 'Stop' }, { key: 'id', label: 'Stop ID' },
    { key: 'lat', label: 'Latitude' }, { key: 'lng', label: 'Longitude' },
    { key: 'route', label: 'Route', render: (s) => s.routeNames.join(', ') || 'Unassigned' },
    { key: 'order', label: 'Order', render: (s) => s.order || '—' },
    { key: 'status', label: 'Status', render: (s) => <Badge>{s.status}</Badge> },
    { key: 'actions', label: 'Actions', render: (s) => <RowActions actions={[{ label: 'Edit stop', icon: Pencil, onClick: () => openForm(s) }, { label: 'Delete stop', icon: Trash2, danger: true, onClick: () => setDel(s) }]} /> },
  ];

  return (
    <div className="space-y-4">
      <PageHeader title="Stop management" subtitle="Stops appear on the map in Phase 6. Coordinates are sample values." addLabel="Add stop" onAdd={() => openForm(null)} />
      <Input placeholder="Search stop or route" aria-label="Search stops" value={q} onChange={(e) => setQ(e.target.value)} />
      {loading ? <LoadingSkeleton rows={4} /> : error ? <ErrorNote message={error} onRetry={reload} /> : rows.length
        ? <DataTable columns={columns} rows={rows} /> : <Card><EmptyState icon={MapPin} title="No stops found" message="Add a stop or change your search." /></Card>}

      <Modal open={!!modal} title={modal?.stop ? `Edit ${modal.stop.name}` : 'Add stop'} onClose={() => setModal(null)}
        footer={<><Button variant="secondary" onClick={() => setModal(null)}>Cancel</Button><Button loading={busy} onClick={() => run(() => saveStop({ ...form, id: modal.stop?.id }), 'Stop saved')}>Save stop</Button></>}>
        <div className="grid gap-4 sm:grid-cols-2">
          {err && <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700 sm:col-span-2">{err}</p>}
          <Input label="Stop name" value={form.name} onChange={set('name')} className="sm:col-span-2" />
          <Input label="Latitude" inputMode="decimal" placeholder="23.2599" value={form.lat} onChange={set('lat')} />
          <Input label="Longitude" inputMode="decimal" placeholder="77.4126" value={form.lng} onChange={set('lng')} />
          <Select label="Assign to route" placeholder="No route" options={(routes.data || []).map((r) => ({ value: r.id, label: `${r.id} · ${r.name}` }))} value={form.routeId} onChange={set('routeId')} />
          <Input label="Stop order" type="number" min="1" placeholder="Last" value={form.order} onChange={set('order')} hint="Leave blank to add at the end." />
          <Select label="Status" options={['Active', 'Inactive']} value={form.status} onChange={set('status')} />
        </div>
      </Modal>

      <ConfirmDialog open={!!del} title="Delete stop?" loading={busy}
        message={`Delete ${del?.name}?${del?.routeNames.length ? ` It will also be removed from ${del.routeNames.join(', ')}.` : ''} This cannot be undone.`}
        onClose={() => setDel(null)} onConfirm={() => run(() => deleteStop(del.id), `${del.name} deleted`)} />
    </div>
  );
}
