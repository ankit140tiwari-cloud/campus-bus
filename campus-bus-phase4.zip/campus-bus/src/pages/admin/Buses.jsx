import { useState } from 'react';
import { Eye, Pencil, Power, Trash2, BusFront } from 'lucide-react';
import useAsync from '../../hooks/useAsync';
import { listBuses, listRoutes, saveBus, setBusStatus, deleteBus } from '../../services/adminCrudService';
import { useToast } from '../../components/Toast';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import RowActions from '../../components/RowActions';
import ConfirmDialog from '../../components/ConfirmDialog';
import ErrorNote from '../../components/ErrorNote';
import Modal from '../../components/Modal';
import Input from '../../components/Input';
import Select from '../../components/Select';
import Badge from '../../components/Badge';
import Button from '../../components/Button';
import Card from '../../components/Card';
import EmptyState from '../../components/EmptyState';
import LoadingSkeleton from '../../components/LoadingSkeleton';

const blank = { number: '', registration: '', capacity: '40', routeId: '', status: 'Active' };

export default function Buses() {
  const { data, loading, error, reload } = useAsync(listBuses, []);
  const routes = useAsync(listRoutes, []);
  const toast = useToast();
  const [q, setQ] = useState('');
  const [modal, setModal] = useState(null); // { mode: 'view' | 'form', bus }
  const [form, setForm] = useState(blank);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [del, setDel] = useState(null);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const openForm = (bus) => { setForm(bus ? { ...bus, capacity: String(bus.capacity) } : blank); setErr(''); setModal({ mode: 'form', bus }); };
  const run = async (fn, okMsg) => {
    setBusy(true); setErr('');
    try { await fn(); toast(okMsg); setModal(null); setDel(null); await reload(); }
    catch (e) { setErr(e.message); toast(e.message, 'error'); }
    finally { setBusy(false); }
  };
  const toggle = (b) => run(() => setBusStatus(b.id, b.status === 'Active' ? 'Inactive' : 'Active'), `${b.number} ${b.status === 'Active' ? 'deactivated' : 'activated'}`);

  const rows = (data || []).filter((b) => `${b.number} ${b.registration} ${b.routeName}`.toLowerCase().includes(q.toLowerCase()));
  const columns = [
    { key: 'number', label: 'Bus' }, { key: 'registration', label: 'Registration' }, { key: 'capacity', label: 'Capacity' }, { key: 'routeName', label: 'Route' },
    { key: 'status', label: 'Status', render: (b) => <Badge>{b.status}</Badge> },
    { key: 'actions', label: 'Actions', render: (b) => (
      <RowActions actions={[{ label: 'View bus', icon: Eye, onClick: () => setModal({ mode: 'view', bus: b }) }, { label: 'Edit bus', icon: Pencil, onClick: () => openForm(b) },
        { label: b.status === 'Active' ? 'Deactivate bus' : 'Activate bus', icon: Power, onClick: () => toggle(b) }, { label: 'Delete bus', icon: Trash2, danger: true, onClick: () => setDel(b) }]} />) },
  ];

  return (
    <div className="space-y-4">
      <PageHeader title="Bus management" subtitle="Sample data until Phase 5." addLabel="Add bus" onAdd={() => openForm(null)} />
      <Input placeholder="Search bus, registration or route" aria-label="Search buses" value={q} onChange={(e) => setQ(e.target.value)} />
      {loading ? <LoadingSkeleton rows={4} /> : error ? <ErrorNote message={error} onRetry={reload} /> : rows.length
        ? <DataTable columns={columns} rows={rows} /> : <Card><EmptyState icon={BusFront} title="No buses found" message="Add a bus or change your search." /></Card>}

      <Modal open={modal?.mode === 'form'} title={modal?.bus ? `Edit ${modal.bus.number}` : 'Add bus'} onClose={() => setModal(null)}
        footer={<><Button variant="secondary" onClick={() => setModal(null)}>Cancel</Button><Button loading={busy} onClick={() => run(() => saveBus({ ...form, id: modal.bus?.id }), 'Bus saved')}>Save bus</Button></>}>
        <div className="grid gap-4 sm:grid-cols-2">
          {err && <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700 sm:col-span-2">{err}</p>}
          <Input label="Bus number" placeholder="BUS-12" value={form.number} onChange={set('number')} />
          <Input label="Registration number" value={form.registration} onChange={set('registration')} />
          <Input label="Capacity" type="number" min="1" max="100" value={form.capacity} onChange={set('capacity')} />
          <Select label="Status" options={['Active', 'Inactive']} value={form.status} onChange={set('status')} />
          <Select label="Assigned route" placeholder="Unassigned" options={(routes.data || []).map((r) => ({ value: r.id, label: `${r.id} · ${r.name}` }))} value={form.routeId} onChange={set('routeId')} className="sm:col-span-2" />
        </div>
      </Modal>

      <Modal open={modal?.mode === 'view'} title={modal?.bus?.number || ''} onClose={() => setModal(null)} footer={<Button variant="secondary" onClick={() => setModal(null)}>Close</Button>}>
        {modal?.bus && <dl className="grid grid-cols-2 gap-4 text-sm">{[['Bus ID', modal.bus.id], ['Registration', modal.bus.registration], ['Capacity', `${modal.bus.capacity} seats`], ['Route', modal.bus.routeName], ['Status', modal.bus.status]].map(([l, v]) => <div key={l}><dt className="text-slate-500">{l}</dt><dd className="font-semibold">{v}</dd></div>)}</dl>}
      </Modal>

      <ConfirmDialog open={!!del} title="Delete bus?" loading={busy} message={`Delete ${del?.number}? Its schedules will be removed too. This cannot be undone.`}
        onClose={() => setDel(null)} onConfirm={() => run(() => deleteBus(del.id), `${del.number} deleted`)} />
    </div>
  );
}
