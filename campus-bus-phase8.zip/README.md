# Campus Bus — Identification and Management System

    frontend/   React + Vite + Tailwind + Leaflet
    backend/    FastAPI + SQLAlchemy + PostgreSQL + WebSocket
    docker-compose.yml   PostgreSQL 16

## Run with the real database and live tracking
1. `docker compose up -d db`
2. Backend (`backend/README.md`): install, `cp .env.example .env`, `python -m app.seed`, `uvicorn app.main:app --reload`
3. Frontend: `cd frontend && cp .env.example .env && npm install && npm run dev`

## Try live tracking (no phone needed)
1. Sign in as admin (admin@college.edu / admin123) and open **Trip Control**.
2. Pick BUS-12, tick **Simulate movement along the route**, press **START TRIP**.
3. In another tab, sign in as student@college.edu and open Live Tracking (or open admin Live Monitoring). The bus moves in real time.
4. Press **END TRIP**: the bus goes Offline everywhere.
Note: the simulation compares against the schedule times in your clock, so outside the 7-8 AM window the bus will show as Delayed. That is correct behaviour, not a bug.

For a real phone, open the app over HTTPS (browsers only give GPS to secure pages), sign in as admin, untick Simulate.

## Run frontend only (sample data)
`cd frontend && npm install && npm run dev` (VITE_USE_MOCK defaults to true; nothing is sent anywhere).

## Upgrading from the Phase 7 database
Phase 8 adds columns, and tables are created once rather than migrated. Reseed once: `python -m app.seed --reset` (this wipes the dev data). Proper migrations arrive in Phase 11.

## Notifications, complaints and push
- Admin: **Notifications** sends to all students, a route, or a bus. **Complaints** shows every report; changing the status notifies the student. **Students** activates or deactivates accounts.
- Automatic notifications: "departed" when a trip starts, "delayed" when a bus falls 5+ minutes behind (at most one per bus per 10 minutes). "Arriving soon" is not built yet.
- A student receives a notification when it targets all students, their route (a route that includes their default stop), a bus on such a route, or them personally. Their notification preferences filter the automatic ones; emergencies, announcements and complaint updates are always delivered.
- Complaint photos: JPEG, PNG or WebP up to 5 MB, checked by file content, stored under `backend/uploads/` and served only to the student who sent it and to admins.
- Browser push (optional): create a Firebase project, put the service-account JSON path in `backend/.env` (`FIREBASE_CREDENTIALS`), put the web-app keys in `frontend/.env` (`VITE_FIREBASE_*`), restart both, then students turn push on in Profile. Without this, everything else still works.

## Still sample data
Analytics (Phase 9), ML ETA (Phase 10).
