/* Shows push notifications while the app is closed. Config arrives in the query string, because a
   service worker cannot read Vite env variables. Messages from the server are data-only, so this is the only place that shows them. */
importScripts('https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.12.2/firebase-messaging-compat.js');

const p = new URL(self.location.href).searchParams;
firebase.initializeApp({ apiKey: p.get('apiKey'), projectId: p.get('projectId'), messagingSenderId: p.get('messagingSenderId'), appId: p.get('appId') });
const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  const d = payload.data || {};
  self.registration.showNotification(d.title || 'Campus Bus', { body: d.body || '', tag: d.notification_id ? `cb-${d.notification_id}` : undefined, data: d });
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(clients.openWindow('/student/notifications'));
});
