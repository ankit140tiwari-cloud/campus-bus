import { useState } from 'react';
import { Check } from 'lucide-react';
import useAsync from '../../hooks/useAsync';
import { getComplaints, createComplaint, getReportOptions } from '../../services/studentService';
import { useToast } from '../../components/Toast';
import Select from '../../components/Select';
import Button from '../../components/Button';
import Card from '../../components/Card';
import EmptyState from '../../components/EmptyState';
import { cx } from '../../utils/helpers';

const TYPES = ['Bus Delay', 'Bus Overcrowding', 'Bus Not Available', 'Stop Problem', 'Route Problem', 'Other'];
const STEPS = ['Pending', 'Investigating', 'Resolved'];
const blank = { type: '', bus: '', route: '', stop: '', description: '' };

function Progress({ status }) {
  const at = STEPS.indexOf(status);
  return (
    <ol className="mt-3 flex items-center gap-2 text-xs">
      {STEPS.map((s, i) => (
        <li key={s} className="flex items-center gap-2">
          <span className={cx('flex items-center gap-1 rounded-full px-2 py-1 font-medium', i <= at ? 'bg-brand-600 text-white' : 'bg-slate-100 text-slate-500')}>{i < at && <Check size={12} />}{s}</span>
          {i < STEPS.length - 1 && <span className="h-px w-3 bg-slate-300" />}
        </li>
      ))}
    </ol>
  );
}

export default function ReportIssue() {
  const list = useAsync(getComplaints, []);
  const opts = useAsync(getReportOptions, []);
  const o = opts.data || { buses: [], routes: [], stops: [] };
  const toast = useToast();
  const [form, setForm] = useState(blank);
  const [image, setImage] = useState(null);
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const pickImage = (e) => {
    const f = e.target.files[0] || null;
    if (f && !['image/jpeg', 'image/png', 'image/webp'].includes(f.type)) { setErrors({ ...errors, image: 'Choose a JPEG, PNG or WebP photo.' }); e.target.value = ''; return; }
    if (f && f.size > 5 * 1024 * 1024) { setErrors({ ...errors, image: 'The photo must be 5 MB or smaller.' }); e.target.value = ''; return; }
    setErrors({ ...errors, image: undefined });
    setImage(f);
  };

  const submit = async (e) => {
    e.preventDefault();
    const err = {};
    if (!form.type) err.type = 'Choose an issue type.';
    if (form.description.trim().length < 10) err.description = 'Describe the problem in at least 10 characters.';
    setErrors(err);
    if (Object.keys(err).length) return;
    setSaving(true);
    try {
      const c = await createComplaint({ ...form, image });
      list.setData([c, ...(list.data || [])]);
      setForm(blank); setImage(null);
      toast(`Issue ${c.id} submitted`);
    } catch (ex) { toast(ex.message, 'error'); } finally { setSaving(false); }
  };

  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <h1 className="text-xl font-bold text-slate-900">Report an issue</h1>
      <Card>
        <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2" noValidate>
          <Select label="Issue type" options={TYPES} placeholder="Select type" value={form.type} onChange={set('type')} error={errors.type} className="sm:col-span-2" />
          <Select label="Bus (optional)" options={o.buses} placeholder="Any" value={form.bus} onChange={set('bus')} />
          <Select label="Route (optional)" options={o.routes} placeholder="Any" value={form.route} onChange={set('route')} />
          <Select label="Stop (optional)" options={o.stops} placeholder="Any" value={form.stop} onChange={set('stop')} className="sm:col-span-2" />
          <div className="sm:col-span-2">
            <label htmlFor="desc" className="mb-1.5 block text-sm font-medium text-slate-700">Description</label>
            <textarea id="desc" rows={4} value={form.description} onChange={set('description')} aria-invalid={!!errors.description}
              className={cx('w-full rounded-lg border bg-white p-3 text-sm', errors.description ? 'border-red-500' : 'border-slate-300')} />
            {errors.description && <p className="mt-1 text-xs text-red-600">{errors.description}</p>}
          </div>
          <div className="sm:col-span-2">
            <label htmlFor="img" className="mb-1.5 block text-sm font-medium text-slate-700">Photo (optional)</label>
            <input id="img" type="file" onChange={pickImage} accept="image/jpeg,image/png,image/webp" className="w-full text-sm file:mr-3 file:rounded-lg file:border-0 file:bg-slate-100 file:px-3 file:py-2.5 file:text-sm file:font-medium" />
            {errors.image && <p className="mt-1 text-xs text-red-600">{errors.image}</p>}
          </div>
          <Button type="submit" loading={saving} className="sm:col-span-2">Submit issue</Button>
        </form>
      </Card>

      <h2 className="pt-2 text-sm font-semibold text-slate-900">Your reports</h2>
      {list.loading ? <p className="text-sm text-slate-500">Loading your reports…</p> : list.data?.length ? (
        <ul className="space-y-3">
          {list.data.map((c) => (
            <li key={c.id} className="rounded-xl border border-slate-200 bg-white p-4">
              <div className="flex items-center justify-between"><p className="font-semibold text-slate-900">{c.type}</p><span className="text-xs text-slate-500">{c.id} · {c.date}</span></div>
              <p className="mt-1 text-sm text-slate-600">{c.description}</p>
              <Progress status={c.status} />
            </li>
          ))}
        </ul>
      ) : <Card><EmptyState title="No reports yet" message="Issues you submit will be tracked here." /></Card>}
    </div>
  );
}
