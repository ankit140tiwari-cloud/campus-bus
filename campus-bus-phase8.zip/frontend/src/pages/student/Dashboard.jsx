import { Link, useNavigate } from 'react-router-dom';
import { Search, Bell } from 'lucide-react';
import useAuth from '../../hooks/useAuth';
import useAsync from '../../hooks/useAsync';
import { getNextBus } from '../../services/busService';
import { useMemo } from 'react';
import useBusLocation from '../../hooks/useBusLocation';
import { applySnapshot } from '../../utils/liveHelpers';
import { getNotifications } from '../../services/studentService';
import BusCard from '../../components/BusCard';
import Card from '../../components/Card';
import Button from '../../components/Button';
import EmptyState from '../../components/EmptyState';
import LoadingSkeleton from '../../components/LoadingSkeleton';
import NotificationItem from '../../components/NotificationItem';
import MapComponent from '../../components/MapComponent';
import { stopsForMap, lineFor, busForMap } from '../../utils/mapHelpers';

export default function StudentDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const next = useAsync(() => getNextBus(user.defaultStop), [user.defaultStop]);
  const notes = useAsync(getNotifications, []);
  const { updates } = useBusLocation();
  const nextBus = useMemo(() => next.data && applySnapshot(next.data, updates[next.data.number], user.defaultStop), [next.data, updates, user.defaultStop]);
  const unread = (notes.data || []).filter((n) => !n.read);

  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <div>
        <h1 className="text-xl font-bold text-slate-900">Hi, {user.name.split(' ')[0]}</h1>
        <p className="text-sm text-slate-500">Your stop: <b className="text-slate-700">{user.defaultStop}</b></p>
      </div>

      <h2 className="text-sm font-semibold text-slate-900">Next bus to your stop</h2>
      {next.loading ? <LoadingSkeleton rows={1} /> : next.error ? (
        <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700">{next.error} <button className="font-semibold underline" onClick={next.reload}>Try again</button></p>
      ) : nextBus ? (
        <BusCard bus={nextBus} onTrack={(b) => navigate(`/student/live?bus=${b.number}`)} />
      ) : (
        <Card><EmptyState icon={Search} title="No bus is heading to your stop" message="Try Find Bus to search another stop or time." action={<Link to="/student/find-bus"><Button>Find Bus</Button></Link>} /></Card>
      )}

      {nextBus && (
        <MapComponent className="h-64 sm:h-80" label={`Map showing ${nextBus.number}`} stops={stopsForMap(nextBus.routeStops)}
          lines={[lineFor(nextBus.routeId, nextBus.routeStops)]} buses={[busForMap(nextBus)].filter(Boolean)} highlight={user.defaultStop} />
      )}

      <Link to="/student/find-bus" className="flex min-h-[44px] items-center justify-center gap-2 rounded-lg border border-brand-500 bg-white text-sm font-semibold text-brand-700 hover:bg-brand-50">
        <Search size={16} aria-hidden /> Quick Find Bus
      </Link>

      <Card title="Notifications" action={<Link to="/student/notifications" className="text-sm font-medium text-brand-600 hover:underline">View all</Link>}>
        {notes.loading ? <LoadingSkeleton rows={2} /> : unread.length ? (
          <ul className="space-y-2">{unread.slice(0, 3).map((n) => <NotificationItem key={n.id} n={n} onRead={() => navigate('/student/notifications')} />)}</ul>
        ) : <EmptyState icon={Bell} title="You're all caught up" message="New bus alerts will show up here." />}
      </Card>
    </div>
  );
}
