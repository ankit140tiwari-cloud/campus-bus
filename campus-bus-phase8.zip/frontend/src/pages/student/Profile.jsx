import { useState } from 'react';
import { USE_MOCK } from '../../utils/config';
import { pushConfigured, pushSupported, pushEnabled, enablePush, disablePush } from '../../services/pushService';
import useAuth from '../../hooks/useAuth';
import { changePassword } from '../../services/studentService';
import { updateProfile } from '../../services/authService';
import { stopNames } from '../../services/routeService';
import { useToast } from '../../components/Toast';
import { initials } from '../../utils/helpers';
import Input from '../../components/Input';
import Select from '../../components/Select';
import Button from '../../components/Button';
import Card from '../../components/Card';

const PREFS = [['departed', 'Bus departed'], ['delayed', 'Bus delayed'], ['arriving', 'Bus arriving soon'], ['changes', 'Route or schedule changes'], ['emergency', 'Emergency announcements']];

export default function Profile() {
  const { user, updateUser } = useAuth();
  const toast = useToast();
  const [form, setForm] = useState({ name: user.name, department: user.department, defaultStop: user.defaultStop });
  const [prefs, setPrefs] = useState({ ...Object.fromEntries(PREFS.map(([k]) => [k, true])), ...(user.prefs || {}) });
  const [push, setPush] = useState(pushEnabled());
  const [pushBusy, setPushBusy] = useState(false);
  const [pw, setPw] = useState({ current: '', next: '', confirm: '' });
  const [pwErr, setPwErr] = useState('');
  const [pwBusy, setPwBusy] = useState(false);

  const saveProfile = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) return toast('Name cannot be empty', 'error');
    try {
      const saved = await updateProfile({ ...form, prefs });
      updateUser({ ...saved, prefs: saved.prefs ?? prefs });
      toast('Profile saved');
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  const togglePush = async () => {
    setPushBusy(true);
    try {
      if (push) { await disablePush(); setPush(false); toast('Push notifications turned off on this device'); }
      else { await enablePush(); setPush(true); toast('Push notifications turned on for this device'); }
    } catch (err) { toast(err.message, 'error'); } finally { setPushBusy(false); }
  };

  const savePw = async (e) => {
    e.preventDefault();
    setPwErr('');
    if (pw.next.length < 8) return setPwErr('New password must be at least 8 characters.');
    if (pw.next !== pw.confirm) return setPwErr('New passwords do not match.');
    setPwBusy(true);
    try { await changePassword(pw); setPw({ current: '', next: '', confirm: '' }); toast('Password changed'); }
    catch (err) { setPwErr(err.message); }
    finally { setPwBusy(false); }
  };

  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <div className="flex items-center gap-4">
        <span className="grid h-14 w-14 place-items-center rounded-full bg-brand-100 text-lg font-bold text-brand-700">{initials(user.name)}</span>
        <div><h1 className="text-xl font-bold text-slate-900">{user.name}</h1><p className="text-sm text-slate-500">{user.studentId} · {user.email}</p></div>
      </div>

      <form onSubmit={saveProfile} className="space-y-4">
        <Card title="Profile">
          <div className="grid gap-4 sm:grid-cols-2">
            <Input label="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <Input label="Department" value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })} />
            <Input label="Student ID" value={user.studentId} disabled hint="Contact the transport office to change this." />
            <Input label="Email" value={user.email} disabled />
            <Select label="Default bus stop" options={stopNames} value={form.defaultStop} onChange={(e) => setForm({ ...form, defaultStop: e.target.value })} className="sm:col-span-2" />
          </div>
        </Card>
        <Card title="Notification preferences">
          <ul className="divide-y divide-slate-100">
            {PREFS.map(([k, label]) => (
              <li key={k}><label className="flex min-h-[44px] items-center justify-between text-sm"><span>{label}</span>
                <input type="checkbox" checked={!!prefs[k]} disabled={k === 'emergency'} onChange={(e) => setPrefs({ ...prefs, [k]: e.target.checked })} className="h-5 w-5 rounded border-slate-300" /></label></li>
            ))}
          </ul>
          <p className="mt-2 text-xs text-slate-500">Emergency announcements are always delivered.</p>
        </Card>
        {!USE_MOCK && (
          <Card title="Push notifications">
            {!pushSupported() ? <p className="text-sm text-slate-500">This browser does not support push notifications.</p>
              : !pushConfigured() ? <p className="text-sm text-slate-500">Push is not set up on this server yet. You will still see notifications inside the app.</p>
              : (
                <div className="flex items-center justify-between gap-3">
                  <p className="text-sm text-slate-600">{push ? 'On for this device.' : 'Get bus alerts even when the app is closed.'}</p>
                  <Button type="button" variant="secondary" loading={pushBusy} onClick={togglePush}>{push ? 'Turn off' : 'Turn on'}</Button>
                </div>
              )}
          </Card>
        )}
        <Button type="submit" className="w-full sm:w-auto">Save changes</Button>
      </form>

      <Card title="Change password">
        <form onSubmit={savePw} className="space-y-4" noValidate>
          {pwErr && <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700">{pwErr}</p>}
          <Input label="Current password" type="password" autoComplete="current-password" value={pw.current} onChange={(e) => setPw({ ...pw, current: e.target.value })} />
          <Input label="New password" type="password" autoComplete="new-password" value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} />
          <Input label="Confirm new password" type="password" autoComplete="new-password" value={pw.confirm} onChange={(e) => setPw({ ...pw, confirm: e.target.value })} />
          <Button type="submit" variant="secondary" loading={pwBusy}>Change password</Button>
        </form>
      </Card>
    </div>
  );
}
