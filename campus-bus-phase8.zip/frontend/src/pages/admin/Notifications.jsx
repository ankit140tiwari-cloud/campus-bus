import { useState } from 'react';
import { Send, Megaphone } from 'lucide-react';
import useAsync from '../../hooks/useAsync';
import { getTargetOptions, listAnnouncements, sendAnnouncement } from '../../services/adminOpsService';
import { timeAgo } from '../../utils/helpers';
import { useToast } from '../../components/Toast';
import PageHeader from '../../components/PageHeader';
import ConfirmDialog from '../../components/ConfirmDialog';
import ErrorNote from '../../components/ErrorNote';
import Input from '../../components/Input';
import Select from '../../components/Select';
import Badge from '../../components/Badge';
import Button from '../../components/Button';
import Card from '../../components/Card';
import EmptyState from '../../components/EmptyState';
import LoadingSkeleton from '../../components/LoadingSkeleton';
import { cx } from '../../utils/helpers';

const AUDIENCES = [{ value: 'all', label: 'All students' }, { value: 'route', label: 'Specific route' }, { value: 'bus', label: 'Specific bus' }];
const blank = { title: '', message: '', priority: 'Normal', targetType: 'all', targetId: '' };
const tone = { Normal: 'neutral', High: 'warning', Emergency: 'danger' };

export default function AdminNotifications() {
  const history = useAsync(listAnnouncements, []);
  const targets = useAsync(getTargetOptions, []);
  const toast = useToast();
  const [form, setForm] = useState(blank);
  const [errors, setErrors] = useState({});
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const validate = () => {
    const err = {};
    if (!form.title.trim()) err.title = 'Enter a title.';
    if (!form.message.trim()) err.message = 'Enter the message.';
    if (form.targetType !== 'all' && !form.targetId) err.targetId = form.targetType === 'route' ? 'Choose a route.' : 'Choose a bus.';
    setErrors(err);
    return Object.keys(err).length === 0;
  };

  const send = async () => {
    setBusy(true);
    try {
      const r = await sendAnnouncement(form);
      toast(`Sent to ${r.recipients} student${r.recipients === 1 ? '' : 's'}${r.pushed ? `, ${r.pushed} push` : ''}`);
      setForm(blank); setConfirm(false);
      history.reload();
    } catch (e) { toast(e.message, 'error'); setConfirm(false); } finally { setBusy(false); }
  };

  const submit = (e) => {
    e.preventDefault();
    if (!validate()) return;
    if (form.targetType === 'all' || form.priority === 'Emergency') setConfirm(true); else send();
  };

  const opts = form.targetType === 'route' ? targets.data?.routes : targets.data?.buses;

  return (
    <div className="space-y-4">
      <PageHeader title="Notifications" subtitle="Send an announcement. It appears in each student's notification center, and as a push if they turned it on." />
      <div className="grid gap-4 lg:grid-cols-5">
        <Card title="New announcement" className="lg:col-span-2">
          <form onSubmit={submit} className="space-y-4" noValidate>
            <Input label="Title" placeholder="BUS-12 is delayed" maxLength={160} value={form.title} onChange={set('title')} error={errors.title} />
            <div>
              <label htmlFor="msg" className="mb-1.5 block text-sm font-medium text-slate-700">Message</label>
              <textarea id="msg" rows={4} maxLength={1000} placeholder="BUS-12 is delayed by 15 minutes due to traffic." value={form.message} onChange={set('message')} aria-invalid={!!errors.message}
                className={cx('w-full rounded-lg border bg-white p-3 text-sm', errors.message ? 'border-red-500' : 'border-slate-300')} />
              {errors.message && <p className="mt-1 text-xs text-red-600">{errors.message}</p>}
            </div>
            <Select label="Priority" options={['Normal', 'High', 'Emergency']} value={form.priority} onChange={set('priority')} />
            <Select label="Target audience" options={AUDIENCES} value={form.targetType} onChange={(e) => setForm({ ...form, targetType: e.target.value, targetId: '' })} />
            {form.targetType !== 'all' && (
              <Select label={form.targetType === 'route' ? 'Route' : 'Bus'} placeholder="Select…" options={opts || []} value={form.targetId} onChange={set('targetId')} error={errors.targetId} />
            )}
            <Button type="submit" className="w-full"><Send size={16} aria-hidden /> Send announcement</Button>
          </form>
        </Card>

        <div className="space-y-3 lg:col-span-3">
          <h2 className="text-sm font-semibold text-slate-900">Recent announcements</h2>
          {history.loading ? <LoadingSkeleton rows={3} /> : history.error ? <ErrorNote message={history.error} onRetry={history.reload} />
            : history.data.length ? (
              <ul className="space-y-3">
                {history.data.map((a) => (
                  <li key={a.id} className="rounded-xl border border-slate-200 bg-white p-4">
                    <div className="flex items-start justify-between gap-2"><p className="font-semibold text-slate-900">{a.title}</p><Badge tone={tone[a.priority]}>{a.priority}</Badge></div>
                    <p className="mt-1 text-sm text-slate-600">{a.message}</p>
                    <p className="mt-2 text-xs text-slate-500">{a.target} · {a.recipients} recipient{a.recipients === 1 ? '' : 's'} · {timeAgo(a.minsAgo)}</p>
                  </li>
                ))}
              </ul>
            ) : <Card><EmptyState icon={Megaphone} title="No announcements yet" message="Announcements you send will be listed here." /></Card>}
        </div>
      </div>

      <ConfirmDialog open={confirm} title="Send announcement?" confirmLabel="Send" loading={busy} onClose={() => setConfirm(false)} onConfirm={send}
        message={`${form.priority === 'Emergency' ? 'This is an EMERGENCY announcement. ' : ''}It will go to ${form.targetType === 'all' ? 'all students' : form.targetType === 'route' ? 'students on the selected route' : 'students on the selected bus'}. This cannot be undone.`} />
    </div>
  );
}
