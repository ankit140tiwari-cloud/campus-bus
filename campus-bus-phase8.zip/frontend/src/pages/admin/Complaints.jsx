import { useEffect, useState } from 'react';
import { Eye, MessageSquareWarning } from 'lucide-react';
import useAsync from '../../hooks/useAsync';
import { listComplaints, updateComplaint, getComplaintImage } from '../../services/adminOpsService';
import { useToast } from '../../components/Toast';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import RowActions from '../../components/RowActions';
import ErrorNote from '../../components/ErrorNote';
import Modal from '../../components/Modal';
import Input from '../../components/Input';
import Select from '../../components/Select';
import Badge from '../../components/Badge';
import Button from '../../components/Button';
import Card from '../../components/Card';
import EmptyState from '../../components/EmptyState';
import LoadingSkeleton from '../../components/LoadingSkeleton';

const STATUSES = ['Pending', 'Investigating', 'Resolved'];
const PRIORITIES = ['Low', 'Medium', 'High'];
const ptone = { High: 'danger', Medium: 'warning', Low: 'neutral' };

function useDebounced(value, ms = 300) {
  const [v, setV] = useState(value);
  useEffect(() => { const t = setTimeout(() => setV(value), ms); return () => clearTimeout(t); }, [value, ms]);
  return v;
}

export default function Complaints() {
  const [status, setStatus] = useState('All');
  const [priority, setPriority] = useState('All');
  const [q, setQ] = useState('');
  const dq = useDebounced(q);
  const { data, loading, error, reload } = useAsync(() => listComplaints({ status, priority, q: dq }), [status, priority, dq]);
  const toast = useToast();
  const [sel, setSel] = useState(null);
  const [edit, setEdit] = useState({ status: 'Pending', priority: 'Medium' });
  const [img, setImg] = useState(null);
  const [busy, setBusy] = useState(false);

  const open = (c) => { setSel(c); setEdit({ status: c.status, priority: c.priority }); };

  useEffect(() => {
    if (!sel?.hasImage) return undefined;
    let url, dead = false;
    getComplaintImage(sel.id).then((u) => { url = u; if (!dead) setImg(u); }).catch(() => {});
    return () => { dead = true; setImg(null); if (url) URL.revokeObjectURL(url); };
  }, [sel?.id, sel?.hasImage]);

  const save = async () => {
    setBusy(true);
    try {
      await updateComplaint(sel.id, edit);
      toast(edit.status !== sel.status ? 'Updated. The student has been notified.' : 'Complaint updated');
      setSel(null);
      reload();
    } catch (e) { toast(e.message, 'error'); } finally { setBusy(false); }
  };

  const columns = [
    { key: 'code', label: 'ID' }, { key: 'student', label: 'Student' }, { key: 'issue', label: 'Issue' }, { key: 'bus', label: 'Bus' }, { key: 'route', label: 'Route' }, { key: 'date', label: 'Date' },
    { key: 'priority', label: 'Priority', render: (c) => <Badge tone={ptone[c.priority]}>{c.priority}</Badge> },
    { key: 'status', label: 'Status', render: (c) => <Badge>{c.status}</Badge> },
    { key: 'actions', label: 'Actions', render: (c) => <RowActions actions={[{ label: 'View complaint', icon: Eye, onClick: () => open(c) }]} /> },
  ];

  return (
    <div className="space-y-4">
      <PageHeader title="Complaints" subtitle="Update the status and the student is notified." />
      <div className="grid gap-3 sm:grid-cols-3">
        <Input aria-label="Search complaints" placeholder="Search student, issue or text" value={q} onChange={(e) => setQ(e.target.value)} />
        <Select aria-label="Filter by status" options={['All', ...STATUSES]} value={status} onChange={(e) => setStatus(e.target.value)} />
        <Select aria-label="Filter by priority" options={['All', ...PRIORITIES]} value={priority} onChange={(e) => setPriority(e.target.value)} />
      </div>

      {loading ? <LoadingSkeleton rows={4} /> : error ? <ErrorNote message={error} onRetry={reload} /> : data.length
        ? <DataTable columns={columns} rows={data} onRowClick={open} />
        : <Card><EmptyState icon={MessageSquareWarning} title="No complaints" message="Nothing matches these filters." /></Card>}

      <Modal open={!!sel} title={sel ? `${sel.code} · ${sel.issue}` : ''} onClose={() => setSel(null)}
        footer={<><Button variant="secondary" onClick={() => setSel(null)}>Close</Button><Button loading={busy} onClick={save}>Save changes</Button></>}>
        {sel && (
          <div className="space-y-4">
            <dl className="grid grid-cols-2 gap-3 text-sm">
              {[['Student', sel.student], ['Date', sel.date], ['Bus', sel.bus], ['Route', sel.route], ['Stop', sel.stop]].map(([l, v]) => <div key={l}><dt className="text-slate-500">{l}</dt><dd className="font-semibold">{v}</dd></div>)}
            </dl>
            <div><p className="text-sm text-slate-500">Description</p><p className="mt-1 whitespace-pre-wrap rounded-lg bg-slate-50 p-3 text-sm text-slate-800">{sel.description}</p></div>
            {sel.hasImage && (img ? <img src={img} alt="Photo attached to the complaint" className="max-h-64 w-full rounded-lg object-contain" /> : <p className="text-sm text-slate-500">Loading photo…</p>)}
            <div className="grid grid-cols-2 gap-3">
              <Select label="Status" options={STATUSES} value={edit.status} onChange={(e) => setEdit({ ...edit, status: e.target.value })} />
              <Select label="Priority" options={PRIORITIES} value={edit.priority} onChange={(e) => setEdit({ ...edit, priority: e.target.value })} />
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
