import { useMemo, useState } from 'react';
import { Info, BusFront } from 'lucide-react';
import useAsync from '../../hooks/useAsync';
import useBusLocation from '../../hooks/useBusLocation';
import { getFleet } from '../../services/adminService';
import { applySnapshot } from '../../utils/liveHelpers';
import { cx } from '../../utils/helpers';
import { busForMap, lineFor } from '../../utils/mapHelpers';
import DataTable from '../../components/DataTable';
import Badge from '../../components/Badge';
import Modal from '../../components/Modal';
import Button from '../../components/Button';
import Card from '../../components/Card';
import LiveBadge from '../../components/LiveBadge';
import MapComponent from '../../components/MapComponent';
import EmptyState from '../../components/EmptyState';
import LoadingSkeleton from '../../components/LoadingSkeleton';

const FILTERS = ['All', 'On Time', 'Delayed', 'Offline'];
const seen = (m) => (m == null ? 'No signal' : m === 0 ? 'Just now' : m < 60 ? `${m} min ago` : `${Math.floor(m / 60)} h ago`);

const COLUMNS = [
  { key: 'number', label: 'Bus' },
  { key: 'routeName', label: 'Route' },
  { key: 'currentLocation', label: 'Current location' },
  { key: 'nextStop', label: 'Next stop' },
  { key: 'status', label: 'Status', render: (b) => <Badge>{b.status}</Badge> },
  { key: 'lastSeen', label: 'Last updated', render: (b) => seen(b.lastSeen) },
];

export default function LiveMonitoring() {
  const { data, loading, error, reload } = useAsync(getFleet, []);
  const { updates, status } = useBusLocation();
  const [filter, setFilter] = useState('All');
  const [selNumber, setSelNumber] = useState(null);

  const fleet = useMemo(() => (data || []).map((b) => applySnapshot(b, updates[b.number])), [data, updates]);
  const rows = fleet.filter((b) => filter === 'All' || b.status === filter);
  const sel = fleet.find((b) => b.number === selNumber) || null;

  // every route line and stop stays on the map; the filter only changes which buses are shown
  const { lines, stops } = useMemo(() => {
    const byRoute = new Map(), byStop = new Map();
    (data || []).forEach((b) => {
      if (b.routeId && !byRoute.has(b.routeId)) byRoute.set(b.routeId, lineFor(b.routeId, b.routeStops));
      b.routeStops.forEach((s) => byStop.set(s.name, { name: s.name, lat: s.lat, lng: s.lng, isCollege: s.name === 'College' }));
    });
    return { lines: [...byRoute.values()], stops: [...byStop.values()] };
  }, [data]);
  const mapBuses = rows.map((b) => busForMap(b, { updated: seen(b.lastSeen) })).filter(Boolean);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-xl font-bold text-slate-900">Live bus monitoring</h1>
        <LiveBadge status={status} />
      </div>

      <div className="flex flex-wrap gap-2" role="group" aria-label="Filter by status">
        {FILTERS.map((f) => (
          <button key={f} onClick={() => setFilter(f)} aria-pressed={filter === f}
            className={cx('min-h-[44px] rounded-full px-4 text-sm font-medium', filter === f ? 'bg-brand-600 text-white' : 'border border-slate-300 bg-white text-slate-700 hover:bg-slate-50')}>
            {f}<span className="ml-1.5 opacity-70">{f === 'All' ? fleet.length : fleet.filter((b) => b.status === f).length}</span>
          </button>
        ))}
      </div>

      {loading ? <LoadingSkeleton rows={4} /> : error ? (
        <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700">{error} <button onClick={reload} className="font-semibold underline">Try again</button></p>
      ) : (
        <>
          <MapComponent className="h-72 sm:h-[28rem]" label="Map of all buses" stops={stops} lines={lines} buses={mapBuses} onBusSelect={setSelNumber} />
          <div className="flex items-start gap-2 rounded-lg bg-brand-50 p-3 text-sm text-brand-700">
            <Info size={16} className="mt-0.5 shrink-0" aria-hidden />
            <p>{mapBuses.length} of {rows.length} buses shown on the map. Buses with no running trip or no recent GPS fix are Offline and have no position. Select a bus marker or row for details.</p>
          </div>
          {rows.length ? <DataTable columns={COLUMNS} rows={rows} rowKey="number" onRowClick={(b) => setSelNumber(b.number)} />
            : <Card><EmptyState icon={BusFront} title={`No ${filter.toLowerCase()} buses`} message="Choose another filter to see the rest of the fleet." /></Card>}
        </>
      )}

      <Modal open={!!sel} onClose={() => setSelNumber(null)} title={sel ? `${sel.number} details` : ''} footer={<Button variant="secondary" onClick={() => setSelNumber(null)}>Close</Button>}>
        {sel && (
          <dl className="grid grid-cols-2 gap-4 text-sm">
            {[['Route', `${sel.routeId} ${sel.routeName}`], ['Status', <Badge key="s">{sel.status}</Badge>], ['Current location', sel.currentLocation], ['Next stop', sel.nextStop],
              ['Delay', sel.delay ? `${sel.delay} min` : 'None'], ['Last updated', seen(sel.lastSeen)]].map(([l, v]) => (
              <div key={l}><dt className="text-slate-500">{l}</dt><dd className="font-semibold text-slate-900">{v}</dd></div>
            ))}
          </dl>
        )}
      </Modal>
    </div>
  );
}
