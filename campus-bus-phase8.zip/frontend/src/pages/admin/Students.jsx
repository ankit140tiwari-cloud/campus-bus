import { useEffect, useState } from 'react';
import { Eye, UserCheck, UserX, Users } from 'lucide-react';
import useAsync from '../../hooks/useAsync';
import { listStudents, setStudentStatus } from '../../services/adminOpsService';
import { useToast } from '../../components/Toast';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import RowActions from '../../components/RowActions';
import ConfirmDialog from '../../components/ConfirmDialog';
import ErrorNote from '../../components/ErrorNote';
import Modal from '../../components/Modal';
import Input from '../../components/Input';
import Select from '../../components/Select';
import Badge from '../../components/Badge';
import Button from '../../components/Button';
import Card from '../../components/Card';
import EmptyState from '../../components/EmptyState';
import LoadingSkeleton from '../../components/LoadingSkeleton';

export default function Students() {
  const [q, setQ] = useState('');
  const [dq, setDq] = useState('');
  const [status, setStatus] = useState('All');
  useEffect(() => { const t = setTimeout(() => setDq(q), 300); return () => clearTimeout(t); }, [q]);
  const { data, loading, error, reload } = useAsync(() => listStudents({ q: dq, status }), [dq, status]);
  const toast = useToast();
  const [view, setView] = useState(null);
  const [off, setOff] = useState(null);
  const [busy, setBusy] = useState(false);

  const change = async (s, next) => {
    setBusy(true);
    try { await setStudentStatus(s.id, next); toast(`${s.name} ${next === 'Active' ? 'activated' : 'deactivated'}`); setOff(null); reload(); }
    catch (e) { toast(e.message, 'error'); } finally { setBusy(false); }
  };

  const columns = [
    { key: 'studentId', label: 'Student ID' }, { key: 'name', label: 'Name' }, { key: 'department', label: 'Department' }, { key: 'email', label: 'Email' }, { key: 'defaultStop', label: 'Default stop' },
    { key: 'status', label: 'Account', render: (s) => <Badge>{s.status}</Badge> },
    { key: 'actions', label: 'Actions', render: (s) => (
      <RowActions actions={[{ label: 'View student', icon: Eye, onClick: () => setView(s) },
        s.status === 'Active' ? { label: 'Deactivate student', icon: UserX, danger: true, onClick: () => setOff(s) } : { label: 'Activate student', icon: UserCheck, onClick: () => change(s, 'Active') }]} />) },
  ];

  return (
    <div className="space-y-4">
      <PageHeader title="Student management" subtitle="A deactivated student can no longer sign in." />
      <div className="grid gap-3 sm:grid-cols-3">
        <Input className="sm:col-span-2" aria-label="Search students" placeholder="Search name, ID, email or department" value={q} onChange={(e) => setQ(e.target.value)} />
        <Select aria-label="Filter by account status" options={['All', 'Active', 'Inactive']} value={status} onChange={(e) => setStatus(e.target.value)} />
      </div>
      {loading ? <LoadingSkeleton rows={4} /> : error ? <ErrorNote message={error} onRetry={reload} /> : data.length
        ? <DataTable columns={columns} rows={data} /> : <Card><EmptyState icon={Users} title="No students found" message="Change the search or filter." /></Card>}

      <Modal open={!!view} title={view?.name || ''} onClose={() => setView(null)} footer={<Button variant="secondary" onClick={() => setView(null)}>Close</Button>}>
        {view && <dl className="grid grid-cols-2 gap-4 text-sm">{[['Student ID', view.studentId], ['Department', view.department], ['Email', view.email], ['Default stop', view.defaultStop], ['Account', view.status]].map(([l, v]) => <div key={l}><dt className="text-slate-500">{l}</dt><dd className="font-semibold">{v}</dd></div>)}</dl>}
      </Modal>
      <ConfirmDialog open={!!off} title="Deactivate student?" confirmLabel="Deactivate" loading={busy} message={`${off?.name} will no longer be able to sign in. You can activate the account again later.`}
        onClose={() => setOff(null)} onConfirm={() => change(off, 'Inactive')} />
    </div>
  );
}
