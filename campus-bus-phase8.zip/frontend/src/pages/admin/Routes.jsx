import { useState } from 'react';
import { Pencil, Trash2, Route as RouteIcon, ArrowUp, ArrowDown, X } from 'lucide-react';
import useAsync from '../../hooks/useAsync';
import { listRoutes, listStopOptions, listBusOptions, saveRoute, deleteRoute } from '../../services/adminCrudService';
import { useToast } from '../../components/Toast';
import PageHeader from '../../components/PageHeader';
import DataTable from '../../components/DataTable';
import RowActions from '../../components/RowActions';
import ConfirmDialog from '../../components/ConfirmDialog';
import ErrorNote from '../../components/ErrorNote';
import Modal from '../../components/Modal';
import Input from '../../components/Input';
import Select from '../../components/Select';
import Badge from '../../components/Badge';
import Button from '../../components/Button';
import Card from '../../components/Card';
import EmptyState from '../../components/EmptyState';
import LoadingSkeleton from '../../components/LoadingSkeleton';

const blank = { name: '', start: '', destination: '', status: 'Active', stops: [], busIds: [] };

export default function Routes() {
  const { data, loading, error, reload } = useAsync(listRoutes, []);
  const stopOpts = useAsync(listStopOptions, []);
  const busOpts = useAsync(listBusOptions, []);
  const toast = useToast();
  const [q, setQ] = useState('');
  const [modal, setModal] = useState(null);
  const [form, setForm] = useState(blank);
  const [addStop, setAddStop] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [del, setDel] = useState(null);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const openForm = (r) => { setForm(r ? { ...r, stops: r.stopList.map((s) => ({ stopId: s.stopId, name: s.name, time: s.time })) } : blank); setAddStop(''); setErr(''); setModal({ route: r }); };
  const run = async (fn, okMsg) => {
    setBusy(true); setErr('');
    try { await fn(); toast(okMsg); setModal(null); setDel(null); await reload(); }
    catch (e) { setErr(e.message); toast(e.message, 'error'); }
    finally { setBusy(false); }
  };

  const setStops = (stops) => setForm({ ...form, stops });
  const move = (i, d) => { const s = [...form.stops]; [s[i], s[i + d]] = [s[i + d], s[i]]; setStops(s); };
  const setTime = (i, time) => setStops(form.stops.map((s, j) => (j === i ? { ...s, time } : s)));
  const add = () => {
    const o = (stopOpts.data || []).find((x) => String(x.id) === addStop);
    if (!o) return;
    setStops([...form.stops, { stopId: o.id, name: o.name, time: '' }]); setAddStop('');
  };
  const toggleBus = (id) => setForm({ ...form, busIds: form.busIds.includes(id) ? form.busIds.filter((x) => x !== id) : [...form.busIds, id] });

  const rows = (data || []).filter((r) => `${r.id} ${r.name} ${r.start} ${r.destination}`.toLowerCase().includes(q.toLowerCase()));
  const columns = [
    { key: 'code', label: 'Route ID' }, { key: 'name', label: 'Route name' }, { key: 'start', label: 'Start' }, { key: 'destination', label: 'Destination' },
    { key: 'stops', label: 'Stops', render: (r) => r.stops.length },
    { key: 'buses', label: 'Assigned buses', render: (r) => r.busNumbers.join(', ') || 'None' },
    { key: 'status', label: 'Status', render: (r) => <Badge>{r.status}</Badge> },
    { key: 'actions', label: 'Actions', render: (r) => <RowActions actions={[{ label: 'Edit route', icon: Pencil, onClick: () => openForm(r) }, { label: 'Delete route', icon: Trash2, danger: true, onClick: () => setDel(r) }]} /> },
  ];
  const available = (stopOpts.data || []).filter((o) => !form.stops.some((s) => s.stopId === o.id));

  return (
    <div className="space-y-4">
      <PageHeader title="Route management" subtitle="Sample data until Phase 5." addLabel="Create route" onAdd={() => openForm(null)} />
      <Input placeholder="Search route or stop" aria-label="Search routes" value={q} onChange={(e) => setQ(e.target.value)} />
      {loading ? <LoadingSkeleton rows={3} /> : error ? <ErrorNote message={error} onRetry={reload} /> : rows.length
        ? <DataTable columns={columns} rows={rows} /> : <Card><EmptyState icon={RouteIcon} title="No routes found" message="Create a route or change your search." /></Card>}

      <Modal open={!!modal} title={modal?.route ? `Edit ${modal.route.code}` : 'Create route'} onClose={() => setModal(null)}
        footer={<><Button variant="secondary" onClick={() => setModal(null)}>Cancel</Button><Button loading={busy} onClick={() => run(() => saveRoute({ ...form, id: modal.route?.id }), 'Route saved')}>Save route</Button></>}>
        <div className="grid gap-4 sm:grid-cols-2">
          {err && <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700 sm:col-span-2">{err}</p>}
          <Input label="Route name" value={form.name} onChange={set('name')} className="sm:col-span-2" />
          <Input label="Starting point" placeholder="Defaults to first stop" value={form.start} onChange={set('start')} />
          <Input label="Destination" placeholder="Defaults to last stop" value={form.destination} onChange={set('destination')} />
          <Select label="Status" options={['Active', 'Inactive']} value={form.status} onChange={set('status')} className="sm:col-span-2" />

          <fieldset className="sm:col-span-2">
            <legend className="mb-2 text-sm font-medium text-slate-700">Stops in order</legend>
            {form.stops.length === 0 && <p className="text-sm text-slate-500">No stops yet. Add at least two.</p>}
            <ol className="space-y-2">
              {form.stops.map((s, i) => (
                <li key={s.stopId} className="flex items-center gap-2 rounded-lg border border-slate-200 p-2">
                  <span className="w-5 text-center text-xs text-slate-500">{i + 1}</span>
                  <span className="min-w-0 flex-1 truncate text-sm font-medium">{s.name}</span>
                  <input type="time" aria-label={`Arrival time at ${s.name}`} value={s.time} onChange={(e) => setTime(i, e.target.value)} className="min-h-[40px] w-28 rounded-lg border border-slate-300 px-2 text-sm" />
                  <button disabled={i === 0} onClick={() => move(i, -1)} aria-label={`Move ${s.name} up`} className="grid h-9 w-9 place-items-center rounded-lg hover:bg-slate-100 disabled:opacity-30"><ArrowUp size={16} /></button>
                  <button disabled={i === form.stops.length - 1} onClick={() => move(i, 1)} aria-label={`Move ${s.name} down`} className="grid h-9 w-9 place-items-center rounded-lg hover:bg-slate-100 disabled:opacity-30"><ArrowDown size={16} /></button>
                  <button onClick={() => setStops(form.stops.filter((_, j) => j !== i))} aria-label={`Remove ${s.name}`} className="grid h-9 w-9 place-items-center rounded-lg text-red-600 hover:bg-red-50"><X size={16} /></button>
                </li>
              ))}
            </ol>
            <div className="mt-3 flex gap-2">
              <Select aria-label="Stop to add" className="flex-1" placeholder="Add a stop…" options={available.map((o) => ({ value: String(o.id), label: o.name }))} value={addStop} onChange={(e) => setAddStop(e.target.value)} />
              <Button variant="secondary" onClick={add} disabled={!addStop}>Add</Button>
            </div>
          </fieldset>

          <fieldset className="sm:col-span-2">
            <legend className="mb-1 text-sm font-medium text-slate-700">Assigned buses</legend>
            <div className="grid grid-cols-2 gap-1 sm:grid-cols-3">
              {(busOpts.data || []).map((b) => (
                <label key={b.id} className="flex min-h-[44px] items-center gap-2 text-sm">
                  <input type="checkbox" checked={form.busIds.includes(b.id)} onChange={() => toggleBus(b.id)} className="h-4 w-4 rounded border-slate-300" />{b.number}
                </label>
              ))}
            </div>
          </fieldset>
        </div>
      </Modal>

      <ConfirmDialog open={!!del} title="Delete route?" loading={busy}
        message={`Delete ${del?.name}? Its buses become unassigned and its schedules are removed. This cannot be undone.`}
        onClose={() => setDel(null)} onConfirm={() => run(() => deleteRoute(del.id), `${del.name} deleted`)} />
    </div>
  );
}
