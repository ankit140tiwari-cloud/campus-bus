import { useCallback, useEffect, useRef, useState } from 'react';
import { Info, TriangleAlert } from 'lucide-react';
import useAsync from '../../hooks/useAsync';
import useWebSocket from '../../hooks/useWebSocket';
import { listBuses, listRoutes } from '../../services/adminCrudService';
import { getActiveTrips, startTrip, endTrip } from '../../services/trackingService';
import { USE_MOCK } from '../../utils/config';
import { useToast } from '../../components/Toast';
import Card from '../../components/Card';
import Select from '../../components/Select';
import Button from '../../components/Button';
import LiveBadge from '../../components/LiveBadge';
import { cx } from '../../utils/helpers';

const IDLE = { state: 'Waiting', lat: null, lng: null, accuracy: null, sent: 0, error: '' };
const SIM_STEPS = 12, SIM_MS = 2000;

// Straight-line path through the route's stops, for testing without moving.
const simPath = (stops) => {
  const pts = [];
  for (let i = 0; i < stops.length - 1; i++) for (let k = 0; k < SIM_STEPS; k++) {
    const t = k / SIM_STEPS;
    pts.push([stops[i].lat + (stops[i + 1].lat - stops[i].lat) * t, stops[i].lng + (stops[i + 1].lng - stops[i].lng) * t]);
  }
  if (stops.length) pts.push([stops.at(-1).lat, stops.at(-1).lng]);
  return pts;
};

export default function TripControl() {
  const toast = useToast();
  const buses = useAsync(listBuses, []);
  const routes = useAsync(listRoutes, []);
  const active = useAsync(() => (USE_MOCK ? Promise.resolve([]) : getActiveTrips()), []);
  const [busId, setBusId] = useState('');
  const [trip, setTrip] = useState(null);
  const [gps, setGps] = useState(IDLE);
  const [simulate, setSimulate] = useState(false);
  const [busy, setBusy] = useState(false);
  const watch = useRef(null), sim = useRef(null), lock = useRef(null), sendRef = useRef(() => false);

  const onMessage = useCallback((m) => {
    if (m.type === 'ack') setGps((g) => ({ ...g, sent: g.sent + 1, error: '' }));
    else if (m.type === 'error') setGps((g) => ({ ...g, error: m.detail }));
  }, []);
  const ws = useWebSocket(trip && !USE_MOCK ? `/ws/bus/${trip.busId}` : null, { onMessage });
  sendRef.current = ws.send;

  const onFix = useCallback((lat, lng, accuracy, ts) => {
    setGps((g) => ({ ...g, state: 'Active', lat, lng, accuracy }));
    if (!USE_MOCK) sendRef.current({ type: 'location', latitude: lat, longitude: lng, timestamp: ts });
  }, []);

  const stopGps = useCallback(() => {
    if (watch.current != null) navigator.geolocation.clearWatch(watch.current);
    clearInterval(sim.current);
    lock.current?.release?.().catch(() => {});
    watch.current = sim.current = lock.current = null;
  }, []);
  useEffect(() => stopGps, [stopGps]);

  const eligible = (buses.data || []).filter((b) => b.status === 'Active' && b.routeId !== '');
  const bus = eligible.find((b) => String(b.id) === String(busId));
  const route = bus && (routes.data || []).find((r) => String(r.id) === String(bus.routeId));

  const startGps = () => {
    if (simulate) {
      const pts = simPath(route?.stopList || []);
      if (pts.length < 2) return setGps((g) => ({ ...g, state: 'Error', error: 'This route has no stop coordinates to simulate.' }));
      let i = 0;
      sim.current = setInterval(() => { const p = pts[Math.min(i++, pts.length - 1)]; onFix(p[0], p[1], 5, Date.now()); }, SIM_MS);
      return undefined;
    }
    if (!navigator.geolocation) return setGps((g) => ({ ...g, state: 'Error', error: 'This device cannot provide GPS location.' }));
    watch.current = navigator.geolocation.watchPosition(
      (p) => onFix(p.coords.latitude, p.coords.longitude, p.coords.accuracy, p.timestamp),
      (e) => setGps((g) => ({ ...g, state: 'Error', error: e.code === 1 ? 'Location permission denied. Allow location access for this site and try again.' : 'Could not get a GPS fix. Move to an open area.' })),
      { enableHighAccuracy: true, maximumAge: 2000, timeout: 15000 });
    navigator.wakeLock?.request('screen').then((l) => { lock.current = l; }).catch(() => {});
    return undefined;
  };

  const start = async () => {
    setBusy(true);
    try {
      let tripId = 0;
      if (!USE_MOCK) {
        const existing = (active.data || []).find((t) => t.bus_id === Number(busId));
        tripId = (existing || (await startTrip(Number(busId)))).trip_id;
      }
      setTrip({ id: tripId, busId: Number(busId) });
      setGps(IDLE);
      startGps();
    } catch (e) { toast(e.message, 'error'); } finally { setBusy(false); }
  };

  const end = async () => {
    setBusy(true);
    stopGps();
    try {
      if (!USE_MOCK && trip.id) await endTrip(trip.id);
      toast('Trip ended');
    } catch (e) { toast(e.message, 'error'); }
    setTrip(null); setGps(IDLE); setBusy(false); active.reload();
  };

  const dot = { Waiting: 'bg-amber-500', Active: 'bg-green-500', Error: 'bg-red-500' }[gps.state];
  const resuming = !trip && bus && (active.data || []).some((t) => t.bus_id === bus.id);

  return (
    <div className="mx-auto max-w-md space-y-4">
      <div>
        <h1 className="text-xl font-bold text-slate-900">Trip Control</h1>
        <p className="text-sm text-slate-500">Internal tool for sending a bus's GPS position. Keep this page open during the trip.</p>
      </div>

      {USE_MOCK && <p className="flex gap-2 rounded-lg bg-brand-50 p-3 text-sm text-brand-700"><Info size={16} className="mt-0.5 shrink-0" />Demo mode: GPS is read but nothing is sent. Set VITE_USE_MOCK=false and start the backend to track for real.</p>}
      {!window.isSecureContext && <p className="flex gap-2 rounded-lg bg-amber-50 p-3 text-sm text-amber-800"><TriangleAlert size={16} className="mt-0.5 shrink-0" />Phones only give GPS to HTTPS pages. Open this page over HTTPS (localhost works on the same computer).</p>}

      <Card>
        <Select label="Bus" placeholder="Select bus" disabled={!!trip} value={busId} onChange={(e) => setBusId(e.target.value)} options={eligible.map((b) => ({ value: String(b.id), label: b.number }))} />
        <p className="mt-3 text-sm text-slate-500">Route: <b className="text-slate-800">{bus ? `${route?.code || ''} ${bus.routeName}` : '—'}</b></p>
        <label className="mt-3 flex min-h-[44px] items-center gap-2 text-sm text-slate-600">
          <input type="checkbox" disabled={!!trip} checked={simulate} onChange={(e) => setSimulate(e.target.checked)} className="h-4 w-4 rounded border-slate-300" />
          Simulate movement along the route (no phone needed)
        </label>
      </Card>

      <Card>
        <div className="flex items-center justify-between">
          <p className="flex items-center gap-2 text-sm font-semibold text-slate-900">GPS status
            <span className="flex items-center gap-1.5 font-bold"><span className={cx('h-2.5 w-2.5 rounded-full', dot)} />{gps.state}</span></p>
          {trip && !USE_MOCK && <LiveBadge status={ws.status} />}
        </div>
        <dl className="mt-3 grid grid-cols-2 gap-3 text-sm">
          <div><dt className="text-slate-500">Latitude</dt><dd className="font-mono font-semibold">{gps.lat != null ? gps.lat.toFixed(5) : '—'}</dd></div>
          <div><dt className="text-slate-500">Longitude</dt><dd className="font-mono font-semibold">{gps.lng != null ? gps.lng.toFixed(5) : '—'}</dd></div>
          <div><dt className="text-slate-500">Accuracy</dt><dd className="font-semibold">{gps.accuracy != null ? `±${Math.round(gps.accuracy)} m` : '—'}</dd></div>
          <div><dt className="text-slate-500">Updates sent</dt><dd className="font-semibold">{gps.sent}</dd></div>
        </dl>
        {gps.error && <p role="alert" className="mt-3 rounded-lg bg-red-50 p-3 text-sm text-red-700">{gps.error}</p>}
      </Card>

      {trip
        ? <Button variant="danger" loading={busy} onClick={end} className="min-h-[56px] w-full text-base">END TRIP</Button>
        : <Button loading={busy} disabled={!bus} onClick={start} className="min-h-[56px] w-full text-base">{resuming ? 'RESUME TRIP' : 'START TRIP'}</Button>}
    </div>
  );
}
