import { USE_MOCK } from '../utils/config';
import { api, apiBlob } from './api';
import * as M from './mockData';

// Admin announcements, complaints and students. Mock mode keeps everything in memory and lets announcements and
// complaint updates reach the demo student; live mode calls the API.
const code = (id) => `R${String(id).padStart(2, '0')}`;
const ago = (iso) => Math.max(0, Math.round((Date.now() - Date.parse(iso)) / 60000));

// ---------------- announcements ----------------
let mockAnn = [
  { id: 2, title: 'BUS-07 is delayed by 15 minutes due to traffic.', message: 'BUS-07 is delayed by 15 minutes due to traffic near New Market.', priority: 'High', target: 'Bus: BUS-07', recipients: 1, minsAgo: 90 },
  { id: 1, title: 'Welcome back', message: 'Campus Bus tracking is live for the new term.', priority: 'Normal', target: 'All students', recipients: 5, minsAgo: 2880 },
];

export async function getTargetOptions() {
  if (USE_MOCK) return { routes: M.ROUTES.map((r) => ({ value: r.id, label: `${r.id} · ${r.name}` })), buses: M.BUSES.map((b) => ({ value: b.number, label: b.number })) };
  const [routes, buses] = await Promise.all([api('/routes'), api('/buses')]);
  return { routes: routes.map((r) => ({ value: String(r.id), label: `${code(r.id)} · ${r.route_name}` })), buses: buses.map((b) => ({ value: String(b.id), label: b.bus_number })) };
}

export async function listAnnouncements() {
  if (USE_MOCK) return M.delay(mockAnn.map((a) => ({ ...a })));
  return (await api('/notifications/admin')).map((n) => ({ id: n.id, title: n.title, message: n.message, priority: n.priority, target: n.target, recipients: n.recipients, minsAgo: ago(n.created_at) }));
}

export async function sendAnnouncement({ title, message, priority, targetType, targetId }) {
  if (!USE_MOCK) {
    return api('/notifications', { method: 'POST', body: { title, message, priority, target_type: targetType, target_id: targetType === 'all' ? null : Number(targetId) } });
  }
  // the demo student stands at MP Nagar on route R01 (BUS-12 and BUS-03)
  const sees = targetType === 'all' || (targetType === 'route' && targetId === 'R01') || (targetType === 'bus' && ['BUS-12', 'BUS-03'].includes(targetId));
  const label = targetType === 'all' ? 'All students' : targetType === 'route' ? `Route: ${targetId}` : `Bus: ${targetId}`;
  const recipients = targetType === 'all' ? M.STUDENTS.filter((s) => s.status === 'Active').length : 2;
  mockAnn = [{ id: Date.now(), title, message, priority, target: label, recipients, minsAgo: 0 }, ...mockAnn];
  if (sees) M.setNotifications([{ id: Date.now(), type: priority === 'Emergency' ? 'emergency' : 'announcement', title, message, minsAgo: 0, read: false }, ...M.NOTIFICATIONS]);
  return M.delay({ recipients, pushed: 0 }, 400);
}

// ---------------- complaints ----------------
const mapC = (c) => ({ id: c.id, code: c.code, student: c.student, issue: c.issue_type, bus: c.bus_number || '—', route: c.route_name || '—', stop: c.stop_name || '—',
  description: c.description, priority: c.priority, status: c.status, date: c.created_at.slice(0, 10), hasImage: c.has_image });

export async function listComplaints({ status = 'All', priority = 'All', q = '' } = {}) {
  if (USE_MOCK) {
    const needle = q.trim().toLowerCase();
    return M.delay(M.COMPLAINTS
      .filter((c) => (status === 'All' || c.status === status) && (priority === 'All' || c.priority === priority) && (!needle || `${c.student} ${c.type} ${c.description}`.toLowerCase().includes(needle)))
      .map((c) => ({ id: c.id, code: c.id, student: c.student, issue: c.type, bus: c.bus || '—', route: c.route || '—', stop: c.stop || '—', description: c.description, priority: c.priority, status: c.status, date: c.date, hasImage: false })));
  }
  const qs = new URLSearchParams();
  if (status !== 'All') qs.set('status', status);
  if (priority !== 'All') qs.set('priority', priority);
  if (q.trim()) qs.set('q', q.trim());
  return (await api(`/complaints?${qs}`)).map(mapC);
}

export async function updateComplaint(id, { status, priority }) {
  if (!USE_MOCK) return mapC(await api(`/complaints/${id}`, { method: 'PUT', body: { status, priority } }));
  const old = M.COMPLAINTS.find((c) => c.id === id);
  M.patchComplaint(id, { status, priority });
  if (old?.own && old.status !== status) {
    M.setNotifications([{ id: Date.now(), type: 'complaint', title: `Report ${id} update`, message: `Your report "${old.type}" is now ${status}.`, minsAgo: 0, read: false }, ...M.NOTIFICATIONS]);
  }
  return M.delay(true, 300);
}

export const getComplaintImage = (id) => (USE_MOCK ? Promise.resolve(null) : apiBlob(`/complaints/${id}/image`));

// ---------------- students ----------------
export async function listStudents({ q = '', status = 'All' } = {}) {
  if (USE_MOCK) {
    const needle = q.trim().toLowerCase();
    return M.delay(M.STUDENTS.filter((s) => (status === 'All' || s.status === status) && (!needle || `${s.name} ${s.email} ${s.studentId} ${s.department}`.toLowerCase().includes(needle))).map((s) => ({ ...s })));
  }
  const qs = new URLSearchParams();
  if (q.trim()) qs.set('q', q.trim());
  if (status !== 'All') qs.set('status', status);
  return (await api(`/students?${qs}`)).map((u) => ({ id: u.id, studentId: u.student_id, name: u.name, department: u.department || '—', email: u.email, defaultStop: u.default_stop || '—', status: u.status }));
}

export async function setStudentStatus(id, status) {
  if (!USE_MOCK) return api(`/students/${id}/status`, { method: 'PUT', body: { status } });
  M.patchStudent(id, { status });
  return M.delay(true, 200);
}
