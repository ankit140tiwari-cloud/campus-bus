import { api } from './api';

export const getLiveSnapshots = () => api('/tracking/live');
export const getBusLocation = (busId) => api(`/buses/${busId}/location`);
export const getActiveTrips = () => api('/trips/active');
export const startTrip = (busId) => api('/trips/start', { method: 'POST', body: { bus_id: busId } });
export const endTrip = (tripId) => api(`/trips/${tripId}/end`, { method: 'POST' });
