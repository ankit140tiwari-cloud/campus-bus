import { api } from './api';
import { toMin, addMin } from '../utils/helpers';
import { applySnapshot } from '../utils/liveHelpers';

const hhmm = (t) => (t || '').slice(0, 5);

export async function loadAll() {
  const [buses, routes, live] = await Promise.all([api('/buses'), api('/routes'), api('/tracking/live')]);
  return { buses, routeBy: Object.fromEntries(routes.map((r) => [r.id, r])), liveBy: Object.fromEntries(live.map((l) => [l.bus_id, l])) };
}

// Same output shape as busService.describeBus, built from API data plus an optional live snapshot.
export function describeLive(bus, route, snap, stopName) {
  const stops = route ? route.stops.map((s) => ({ name: s.stop_name, time: hhmm(s.expected_time), lat: s.latitude, lng: s.longitude })) : [];
  const base = {
    id: bus.id, number: bus.bus_number, routeId: route ? `R${String(route.id).padStart(2, '0')}` : '', routeName: route?.route_name || 'Unassigned',
    status: 'Offline', delay: 0, currentLocation: 'Not running', nextStop: '—', position: null, lastSeen: null, currentIdx: -1,
    routeStops: stops.map(({ name, lat, lng }) => ({ name, lat, lng })), stops,
  };
  return applySnapshot(base, snap, stopName);
}

const describeAll = async (stopName) => {
  const { buses, routeBy, liveBy } = await loadAll();
  return buses.map((b) => describeLive(b, routeBy[b.route_id], liveBy[b.id], stopName));
};

export const getBuses = () => describeAll();

export async function getBusDetail(number, stopName) {
  const d = (await describeAll(stopName)).find((b) => b.number === number);
  if (!d) return null;
  return { ...d, stops: d.stops.map((s) => ({ ...s, time: addMin(s.time, d.delay) })) };
}

export async function getNextBus(stopName) {
  const list = (await describeAll(stopName)).filter((b) => b.status !== 'Offline' && b.eta !== undefined);
  return list.sort((a, b) => a.eta - b.eta)[0] || null;
}

export async function searchBuses({ from, to, time }) {
  const list = await describeAll(from);
  return list
    .filter((b) => {
      const names = b.stops.map((s) => s.name);
      const i = names.indexOf(from), j = names.indexOf(to);
      if (b.status === 'Offline' || i < 0 || j < 0 || i >= j || b.eta === undefined) return false;
      return !time || toMin(addMin(b.stops[i].time, b.delay)) >= toMin(time);
    })
    .map((b) => ({ ...b, routeName: `${from} → ${to}`, destination: to }))
    .sort((a, b) => a.eta - b.eta);
}
