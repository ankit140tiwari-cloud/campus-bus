import { SCHEDULES, BUSES, delay } from './mockData';
import { USE_MOCK } from '../utils/config';
import { api } from './api';

const mockSchedules = () =>
  delay(SCHEDULES.map((s) => ({ ...s, status: BUSES.find((b) => b.number === s.bus)?.status || 'Scheduled' })));

// One API row per bus/day/trip; the student page expects a `days` array and 24h HH:MM strings.
const liveSchedules = async () => (await api('/schedules')).filter((s) => s.status === 'Active').map((s) => ({
  id: s.id, bus: s.bus_number, route: s.route_name, departure: s.departure_time, arrival: s.arrival_time, days: [s.day], status: 'Scheduled',
}));

export const getSchedules = () => (USE_MOCK ? mockSchedules() : liveSchedules());
