import { STORAGE_KEY } from '../utils/constants';

const BASE = import.meta.env.VITE_API_URL || '/api';

export const getStoredAuth = () => {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || sessionStorage.getItem(STORAGE_KEY) || 'null');
  } catch {
    return null;
  }
};

// FastAPI returns either { detail: "text" } or { detail: [{ loc, msg }, ...] } for validation errors.
function messageFrom(body) {
  const d = body?.detail;
  if (typeof d === 'string') return d;
  if (Array.isArray(d) && d.length) {
    return d.map((x) => `${String(x.loc?.at(-1) ?? 'field').replace(/_/g, ' ')}: ${String(x.msg).replace(/^Value error, /, '')}`).join('. ');
  }
  return 'Request failed. Check your connection and try again.';
}

async function request(path, { method = 'GET', body, form } = {}) {
  const auth = getStoredAuth();
  const headers = auth?.token ? { Authorization: `Bearer ${auth.token}` } : {};
  if (body !== undefined) headers['Content-Type'] = 'application/json'; // FormData sets its own boundary header
  let res;
  try {
    res = await fetch(`${BASE}${path}`, { method, headers, body: form ?? (body !== undefined ? JSON.stringify(body) : undefined) });
  } catch {
    throw new Error('Cannot reach the server. Check that the backend is running.');
  }
  if (res.status === 401 && auth?.token) {
    // token expired or revoked: clear it and return to the login page
    localStorage.removeItem(STORAGE_KEY);
    sessionStorage.removeItem(STORAGE_KEY);
    window.location.assign('/login');
  }
  if (!res.ok) throw new Error(messageFrom(await res.json().catch(() => null)));
  return res;
}

export async function api(path, opts) {
  const res = await request(path, opts);
  return res.status === 204 ? null : res.json();
}

export const apiForm = (path, form) => api(path, { method: 'POST', form });

// Protected files (complaint photos) need the auth header, so they cannot be a plain <img src>.
export async function apiBlob(path) {
  return URL.createObjectURL(await (await request(path)).blob());
}
