import { api } from './api';

// Firebase Cloud Messaging for browsers. Everything is dynamic-imported, so the app runs fine without Firebase set up.
const cfg = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY, projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID, appId: import.meta.env.VITE_FIREBASE_APP_ID,
};
const VAPID = import.meta.env.VITE_FIREBASE_VAPID_KEY;
const TOKEN_KEY = 'campus_bus_push_token';

export const pushConfigured = () => !!(cfg.apiKey && cfg.projectId && cfg.messagingSenderId && cfg.appId && VAPID);
export const pushSupported = () => typeof window !== 'undefined' && 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
export const pushEnabled = () => pushSupported() && Notification.permission === 'granted' && !!localStorage.getItem(TOKEN_KEY);

async function messaging() {
  const { initializeApp, getApps } = await import('firebase/app');
  const { getMessaging } = await import('firebase/messaging');
  return getMessaging(getApps()[0] || initializeApp(cfg));
}

export async function enablePush() {
  if (Notification.permission === 'denied') throw new Error('Notifications are blocked for this site. Allow them in your browser settings, then try again.');
  if ((await Notification.requestPermission()) !== 'granted') throw new Error('Notification permission was not granted.');
  const { getToken } = await import('firebase/messaging');
  const reg = await navigator.serviceWorker.register(`/firebase-messaging-sw.js?${new URLSearchParams(cfg)}`);
  const token = await getToken(await messaging(), { vapidKey: VAPID, serviceWorkerRegistration: reg });
  if (!token) throw new Error('Could not get a push token from Firebase.');
  await api('/notifications/device-token', { method: 'POST', body: { token } });
  localStorage.setItem(TOKEN_KEY, token);
}

export async function disablePush() {
  const token = localStorage.getItem(TOKEN_KEY);
  if (token) await api('/notifications/device-token', { method: 'DELETE', body: { token } });
  try { const { deleteToken } = await import('firebase/messaging'); await deleteToken(await messaging()); } catch { /* token already gone */ }
  localStorage.removeItem(TOKEN_KEY);
}

// While the app is open the service worker is not used; show incoming pushes through the app's own toast instead.
export async function listenForeground(onNotice) {
  const { onMessage } = await import('firebase/messaging');
  return onMessage(await messaging(), (p) => onNotice(p.data || {}));
}
