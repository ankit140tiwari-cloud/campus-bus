import { USE_MOCK } from '../utils/config';
import { api, apiForm } from './api';
import { NOTIFICATIONS, setNotifications, COMPLAINTS, addComplaint, ROUTES, BUSES, STOP_NAMES, delay } from './mockData';

const minsSince = (iso) => Math.max(0, Math.round((Date.now() - Date.parse(iso)) / 60000));
const PRIORITY = { 'Bus Not Available': 'High', 'Bus Delay': 'Medium', 'Bus Overcrowding': 'Medium', 'Route Problem': 'Medium', 'Stop Problem': 'Low', Other: 'Low' };

// ---------------- notifications ----------------
const mapNote = (n) => ({ id: n.id, type: n.category, title: n.title, message: n.message, minsAgo: minsSince(n.created_at), read: n.read });

export const getNotifications = () => (USE_MOCK ? delay(NOTIFICATIONS.map((n) => ({ ...n }))) : api('/notifications').then((r) => r.map(mapNote)));

export const markRead = (id) => {
  if (!USE_MOCK) return api(`/notifications/${id}/read`, { method: 'POST' });
  setNotifications(NOTIFICATIONS.map((n) => (n.id === id ? { ...n, read: true } : n)));
  return delay(true, 100);
};

export const markAllRead = () => {
  if (!USE_MOCK) return api('/notifications/read-all', { method: 'POST' });
  setNotifications(NOTIFICATIONS.map((n) => ({ ...n, read: true })));
  return delay(true, 100);
};

// ---------------- complaints ----------------
const mapComplaint = (c) => ({ id: c.code, rawId: c.id, type: c.issue_type, bus: c.bus_number || '', route: c.route_name || '', stop: c.stop_name || '',
  description: c.description, status: c.status, date: c.created_at.slice(0, 10) });

export const getComplaints = () => (USE_MOCK ? delay(COMPLAINTS.filter((c) => c.own).map((c) => ({ ...c }))) : api('/complaints').then((r) => r.map(mapComplaint)));

// Dropdown choices for the report form. Mock: names. Live: database ids, which the API needs.
export async function getReportOptions() {
  if (USE_MOCK) {
    return { buses: BUSES.map((b) => ({ value: b.number, label: b.number })), routes: ROUTES.map((r) => ({ value: r.id, label: `${r.id} · ${r.name}` })), stops: STOP_NAMES.map((n) => ({ value: n, label: n })) };
  }
  const [buses, routes, stops] = await Promise.all([api('/buses'), api('/routes'), api('/stops')]);
  return {
    buses: buses.map((b) => ({ value: String(b.id), label: b.bus_number })),
    routes: routes.map((r) => ({ value: String(r.id), label: `R${String(r.id).padStart(2, '0')} · ${r.route_name}` })),
    stops: stops.map((s) => ({ value: String(s.id), label: s.stop_name })),
  };
}

export async function createComplaint(data) {
  if (USE_MOCK) {
    const c = { type: data.type, bus: data.bus, route: data.route, stop: data.stop, description: data.description, student: 'Aarav Sharma', own: true,
      priority: PRIORITY[data.type] || 'Low', id: `C-${1000 + Math.floor(Math.random() * 9000)}`, status: 'Pending', date: new Date().toISOString().slice(0, 10) };
    addComplaint(c);
    return delay(c, 500);
  }
  const f = new FormData();
  f.append('issue_type', data.type);
  f.append('description', data.description);
  if (data.bus) f.append('bus_id', data.bus);
  if (data.route) f.append('route_id', data.route);
  if (data.stop) f.append('stop_id', data.stop);
  if (data.image) f.append('image', data.image);
  return mapComplaint(await apiForm('/complaints', f));
}

export const changePassword = ({ current, next }) =>
  USE_MOCK
    ? delay(null, 500).then(() => { if (current !== 'student123') throw new Error('Current password is incorrect.'); return true; })
    : api('/auth/change-password', { method: 'POST', body: { current_password: current, new_password: next } });
