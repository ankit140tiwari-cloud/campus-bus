import { ROUTES, BUSES, STOP_NAMES, delay } from './mockData';
import { USE_MOCK } from '../utils/config';
import { api } from './api';

const mockRoutes = () =>
  delay(ROUTES.map((r) => ({
    id: r.id, name: r.name, stopCount: r.stops.length, busCount: BUSES.filter((b) => b.routeId === r.id).length,
    start: r.stops[0].name, destination: r.stops[r.stops.length - 1].name, stops: r.stops,
  })));
export const getStopNames = () => delay(STOP_NAMES, 100);
export const getRouteOptions = () => ROUTES.map((r) => ({ value: r.id, label: `${r.id} · ${r.name}` }));
export const getBusOptions = () => BUSES.map((b) => ({ value: b.number, label: b.number }));
export const stopNames = STOP_NAMES;

const hhmm = (t) => (t || '').slice(0, 5);
const liveRoutes = async () => (await api('/routes')).filter((r) => r.status === 'Active').map((r) => ({
  id: `R${String(r.id).padStart(2, '0')}`, name: r.route_name, stopCount: r.stops.length, busCount: r.buses.length,
  start: r.start_point, destination: r.destination, stops: r.stops.map((s) => ({ name: s.stop_name, time: hhmm(s.expected_time), lat: s.latitude, lng: s.longitude })),
}));
export const getRoutes = () => (USE_MOCK ? mockRoutes() : liveRoutes());
