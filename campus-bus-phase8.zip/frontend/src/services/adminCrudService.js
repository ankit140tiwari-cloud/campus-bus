import { USE_MOCK } from '../utils/config';
import * as mock from './adminCrudMock';
import * as live from './adminCrudApi';

const impl = USE_MOCK ? mock : live;

export const { listStops, saveStop, deleteStop, listRoutes, listStopOptions, listBusOptions, saveRoute, deleteRoute,
  listBuses, saveBus, setBusStatus, deleteBus, listSchedules, saveSchedule, setScheduleActive, deleteSchedule } = impl;
