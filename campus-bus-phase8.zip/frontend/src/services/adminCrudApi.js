import { api } from './api';

// Live implementation: same function names and return shapes as adminCrudMock.js,
// so the admin pages do not care which one is active.
const hhmm = (t) => (t || '').slice(0, 5);
const num = (v) => (v === '' || v == null ? null : Number(v));

const mapBus = (b) => ({ id: b.id, number: b.bus_number, registration: b.registration_number, capacity: b.capacity, routeId: b.route_id ?? '', status: b.status, routeName: b.route_name || 'Unassigned' });
const mapStop = (s) => ({ id: s.id, name: s.stop_name, lat: s.latitude, lng: s.longitude, status: s.status, routeNames: s.routes.map((r) => r.route_name), routeId: s.routes[0]?.route_id ?? '', order: s.routes[0]?.stop_order ?? '' });
const mapRoute = (r) => ({
  id: r.id, code: `R${String(r.id).padStart(2, '0')}`, name: r.route_name, start: r.start_point, destination: r.destination, status: r.status,
  stops: r.stops.map((s) => ({ stopId: s.stop_id, time: hhmm(s.expected_time) })),
  stopList: r.stops.map((s) => ({ stopId: s.stop_id, name: s.stop_name, time: hhmm(s.expected_time), lat: s.latitude, lng: s.longitude })),
  busIds: r.buses.map((b) => b.id), busNumbers: r.buses.map((b) => b.bus_number),
});
const mapSchedule = (s) => ({ id: s.id, busId: s.bus_id, routeId: s.route_id, day: s.day, departure: s.departure_time, arrival: s.arrival_time, active: s.status === 'Active', busNumber: s.bus_number, routeName: s.route_name });

const send = (path, id, body) => (id ? api(`${path}/${id}`, { method: 'PUT', body }) : api(path, { method: 'POST', body }));

// Stops
export const listStops = async () => (await api('/stops')).map(mapStop);
export const saveStop = ({ id, name, lat, lng, status, routeId, order }) =>
  send('/stops', id, { stop_name: name, latitude: lat, longitude: lng, status, route_id: num(routeId), stop_order: num(order) });
export const deleteStop = (id) => api(`/stops/${id}`, { method: 'DELETE' });

// Routes
export const listRoutes = async () => (await api('/routes')).map(mapRoute);
export const listStopOptions = async () => (await api('/stops')).filter((s) => s.status === 'Active').map((s) => ({ id: s.id, name: s.stop_name }));
export const listBusOptions = async () => (await api('/buses')).map((b) => ({ id: b.id, number: b.bus_number, routeId: b.route_id ?? '' }));
export const saveRoute = ({ id, name, start, destination, status, stops, busIds }) =>
  send('/routes', id, { route_name: name, start_point: start || null, destination: destination || null, status, stops: stops.map((s) => ({ stop_id: s.stopId, expected_time: s.time })), bus_ids: busIds });
export const deleteRoute = (id) => api(`/routes/${id}`, { method: 'DELETE' });

// Buses
export const listBuses = async () => (await api('/buses')).map(mapBus);
export const saveBus = ({ id, number, registration, capacity, routeId, status }) =>
  send('/buses', id, { bus_number: number, registration_number: registration, capacity: Number(capacity), route_id: num(routeId), status });
export const setBusStatus = (id, status) => api(`/buses/${id}/status`, { method: 'PATCH', body: { status } });
export const deleteBus = (id) => api(`/buses/${id}`, { method: 'DELETE' });

// Schedules
export const listSchedules = async () => (await api('/schedules')).map(mapSchedule);
export const saveSchedule = ({ id, busId, routeId, day, departure, arrival, active }) =>
  send('/schedules', id, { bus_id: num(busId), route_id: num(routeId), day, departure_time: departure, arrival_time: arrival, status: active ? 'Active' : 'Inactive' });
export const setScheduleActive = (id, active) => api(`/schedules/${id}/status`, { method: 'PATCH', body: { status: active ? 'Active' : 'Inactive' } });
export const deleteSchedule = (id) => api(`/schedules/${id}`, { method: 'DELETE' });
