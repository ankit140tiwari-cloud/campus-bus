import { Routes, Route, Navigate } from 'react-router-dom';
import useAuth from './hooks/useAuth';
import Login from './pages/auth/Login';
import StudentLayout from './layouts/StudentLayout';
import AdminLayout from './layouts/AdminLayout';
import StudentDashboard from './pages/student/Dashboard';
import FindBus from './pages/student/FindBus';
import LiveTracking from './pages/student/LiveTracking';
import StudentRoutes from './pages/student/Routes';
import Schedule from './pages/student/Schedule';
import Notifications from './pages/student/Notifications';
import ReportIssue from './pages/student/ReportIssue';
import Profile from './pages/student/Profile';
import AdminDashboard from './pages/admin/Dashboard';
import LiveMonitoring from './pages/admin/LiveMonitoring';
import Buses from './pages/admin/Buses';
import AdminRoutes from './pages/admin/Routes';
import Stops from './pages/admin/Stops';
import Schedules from './pages/admin/Schedules';
import TripControl from './pages/admin/TripControl';
import AdminNotifications from './pages/admin/Notifications';
import Complaints from './pages/admin/Complaints';
import Students from './pages/admin/Students';
import ComingSoon from './pages/ComingSoon';
import { HOME_BY_ROLE, ADMIN_NAV } from './utils/constants';

function RequireRole({ role, children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (user.role !== role) return <Navigate to={HOME_BY_ROLE[user.role]} replace />;
  return children;
}

export default function App() {
  const { user } = useAuth();
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/student" element={<RequireRole role="student"><StudentLayout /></RequireRole>}>
        <Route index element={<StudentDashboard />} />
        <Route path="find-bus" element={<FindBus />} />
        <Route path="live" element={<LiveTracking />} />
        <Route path="routes" element={<StudentRoutes />} />
        <Route path="schedule" element={<Schedule />} />
        <Route path="notifications" element={<Notifications />} />
        <Route path="report" element={<ReportIssue />} />
        <Route path="profile" element={<Profile />} />
      </Route>
      <Route path="/admin" element={<RequireRole role="admin"><AdminLayout /></RequireRole>}>
        <Route index element={<AdminDashboard />} />
        <Route path="live" element={<LiveMonitoring />} />
        <Route path="buses" element={<Buses />} />
        <Route path="routes" element={<AdminRoutes />} />
        <Route path="stops" element={<Stops />} />
        <Route path="schedules" element={<Schedules />} />
        <Route path="trip-control" element={<TripControl />} />
        <Route path="notifications" element={<AdminNotifications />} />
        <Route path="complaints" element={<Complaints />} />
        <Route path="students" element={<Students />} />
        {ADMIN_NAV.filter((i) => !i.end && !['live', 'buses', 'routes', 'stops', 'schedules', 'trip-control', 'notifications', 'complaints', 'students'].includes(i.to.split('/')[2])).map((i) => <Route key={i.to} path={i.to.split('/')[2]} element={<ComingSoon />} />)}
      </Route>
      <Route path="*" element={<Navigate to={user ? HOME_BY_ROLE[user.role] : '/login'} replace />} />
    </Routes>
  );
}
