// Set VITE_USE_MOCK=false in .env to talk to the FastAPI backend. Default is mock data (no backend needed).
export const USE_MOCK = import.meta.env.VITE_USE_MOCK !== 'false';
