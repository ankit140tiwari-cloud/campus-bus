import { fmt12 } from './helpers';

// Adapters from service data to MapComponent props.
export const stopsForMap = (stops = []) =>
  stops.filter((s) => s.lat != null).map((s) => ({ name: s.name, lat: s.lat, lng: s.lng, time: s.time ? fmt12(s.time) : undefined, isCollege: s.name === 'College' }));

export const lineFor = (id, stops = []) => ({ id, coords: stops.filter((s) => s.lat != null).map((s) => [s.lat, s.lng]) });

export const busForMap = (d, extra = {}) =>
  d.position ? { number: d.number, lat: d.position.lat, lng: d.position.lng, status: d.status, routeName: d.routeName, currentLocation: d.currentLocation, nextStop: d.nextStop,
    eta: d.eta !== undefined ? `${d.eta} min` : undefined, ...extra } : null;
