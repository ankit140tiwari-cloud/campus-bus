export const APP_NAME = 'Campus Bus';
export const APP_SUBTITLE = 'Identification and Management System';
export const ROLES = { STUDENT: 'student', ADMIN: 'admin' };
export const HOME_BY_ROLE = { student: '/student', admin: '/admin' };
export const STORAGE_KEY = 'campus_bus_auth';

export const STUDENT_NAV = [
  { to: '/student', label: 'Dashboard', icon: 'LayoutDashboard', end: true },
  { to: '/student/find-bus', label: 'Find Bus', icon: 'Search' },
  { to: '/student/live', label: 'Live Tracking', icon: 'MapPin' },
  { to: '/student/routes', label: 'Routes & Stops', icon: 'Route' },
  { to: '/student/schedule', label: 'Schedule', icon: 'CalendarClock' },
  { to: '/student/notifications', label: 'Notifications', icon: 'Bell' },
  { to: '/student/report', label: 'Report Issue', icon: 'MessageSquareWarning' },
  { to: '/student/profile', label: 'Profile', icon: 'User' },
];

export const ADMIN_NAV = [
  { to: '/admin', label: 'Dashboard', icon: 'LayoutDashboard', end: true },
  { to: '/admin/live', label: 'Live Monitoring', icon: 'Radar' },
  { to: '/admin/buses', label: 'Buses', icon: 'Bus' },
  { to: '/admin/routes', label: 'Routes', icon: 'Route' },
  { to: '/admin/stops', label: 'Stops', icon: 'MapPin' },
  { to: '/admin/schedules', label: 'Schedules', icon: 'CalendarClock' },
  { to: '/admin/students', label: 'Students', icon: 'Users' },
  { to: '/admin/notifications', label: 'Notifications', icon: 'Megaphone' },
  { to: '/admin/complaints', label: 'Complaints', icon: 'MessageSquareWarning' },
  { to: '/admin/analytics', label: 'Analytics', icon: 'BarChart3' },
  { to: '/admin/trip-control', label: 'Trip Control', icon: 'Navigation' },
];
