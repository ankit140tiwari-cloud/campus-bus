import { addMin, fmt12 } from './helpers';

const STALE_MS = 120000;

// Overlays one live snapshot (REST /tracking/live or a WebSocket bus_update) on a bus described by busService.
// Pure: returns a new object and leaves `base` alone. With no snapshot it returns `base` unchanged (mock mode).
export function applySnapshot(base, snap, stopName) {
  if (!snap) return base;
  const offline = { ...base, status: 'Offline', delay: 0, currentLocation: 'Not running', nextStop: '—', position: null, lastSeen: null, currentIdx: -1 };
  if (snap.ended) { delete offline.eta; delete offline.stopsRemaining; return offline; }

  const age = Date.now() - Date.parse(snap.timestamp);
  const stale = !snap.timestamp || age > STALE_MS;
  const names = (base.routeStops || []).map((s) => s.name);
  const cur = snap.current_stop ? names.indexOf(snap.current_stop) : -1;
  const out = {
    ...base,
    status: stale ? 'Offline' : snap.status,
    delay: snap.delay_min,
    currentLocation: snap.current_stop || (snap.next_stop ? `Before ${snap.next_stop}` : 'On the way'),
    nextStop: snap.next_stop || 'Arrived at destination',
    position: snap.latitude != null ? { lat: snap.latitude, lng: snap.longitude } : null,
    lastSeen: Math.max(0, Math.floor(age / 60000)),
    currentIdx: cur,
  };
  if (stopName) {
    const eta = snap.etas?.[stopName];
    if (eta !== undefined && !stale) {
      out.eta = eta;
      out.stopsRemaining = names.indexOf(stopName) - cur;
      const t = base.stops?.find((s) => s.name === stopName)?.time;
      if (t) out.departure = fmt12(addMin(t, snap.delay_min));
    } else {
      delete out.eta; delete out.stopsRemaining;
    }
  }
  return out;
}
