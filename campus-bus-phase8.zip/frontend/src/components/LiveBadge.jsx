import { cx } from '../utils/helpers';

const MAP = { open: ['Live', 'bg-green-500'], connecting: ['Connecting…', 'bg-amber-500'], closed: ['Reconnecting…', 'bg-red-500'], mock: ['Sample data', 'bg-slate-400'] };

export default function LiveBadge({ status }) {
  const [text, dot] = MAP[status] || MAP.closed;
  return (
    <span role="status" className="inline-flex items-center gap-1.5 rounded-full bg-white px-2.5 py-1 text-xs font-medium text-slate-600 ring-1 ring-inset ring-slate-200">
      <span className={cx('h-2 w-2 rounded-full', dot, status === 'open' && 'animate-pulse')} aria-hidden />{text}
    </span>
  );
}
