import { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { cx } from '../utils/helpers';

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const BUS_SVG = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 6v6"/><path d="M15 6v6"/><path d="M2 12h19.6"/><path d="M18 18h3s.5-1.7.8-2.8c.1-.4.2-.8.2-1.2 0-.4-.1-.8-.2-1.2l-1.4-5C20.1 6.8 19.1 6 18 6H4a2 2 0 0 0-2 2v10h3"/><circle cx="7" cy="18" r="2"/><path d="M9 18h5"/><circle cx="16" cy="18" r="2"/></svg>';
const DEFAULT_CENTER = [23.2599, 77.4126];

const busIcon = (status = '') => L.divIcon({ className: '', html: `<div class="cb-bus cb-bus-${status.toLowerCase().replace(/\s+/g, '')}">${BUS_SVG}</div>`, iconSize: [34, 34], iconAnchor: [17, 17], popupAnchor: [0, -18] });
const stopIcon = (kind) => {
  const size = kind === 'college' ? 24 : kind === 'mine' ? 22 : 14;
  return L.divIcon({ className: '', html: `<div class="cb-stop cb-stop-${kind}">${kind === 'college' ? 'C' : ''}</div>`, iconSize: [size, size], iconAnchor: [size / 2, size / 2], popupAnchor: [0, -size / 2] });
};

const busPopup = (b) => `<b>${esc(b.number)}</b><br>Route: ${esc(b.routeName)}<br>Current location: ${esc(b.currentLocation)}<br>Next stop: ${esc(b.nextStop)}`
  + `${b.eta ? `<br>ETA: ${esc(b.eta)}` : ''}<br>Status: ${esc(b.status)}${b.updated ? `<br>Updated: ${esc(b.updated)}` : ''}`;

/**
 * stops:  [{ id?, name, lat, lng, time?, isCollege? }]     lines: [{ id, coords: [[lat, lng], ...], color? }]
 * buses:  [{ number, lat, lng, status, routeName, currentLocation, nextStop, eta?, updated? }]
 * highlight: stop name to emphasise (the student's stop)   pin: { lat, lng } draggable-free picker marker
 * Buses are diffed by number and moved in place, so Phase 7 can push new positions without re-fitting the map.
 */
export default function MapComponent({ stops = [], lines = [], buses = [], highlight, pin, onMapClick, onBusSelect, onStopSelect, className = 'h-72', label = 'Map' }) {
  const el = useRef(null);
  const map = useRef(null);
  const groups = useRef({});
  const markers = useRef(new Map());
  const pinMarker = useRef(null);
  const cb = useRef({});
  cb.current = { onMapClick, onBusSelect, onStopSelect };
  const [tileError, setTileError] = useState(false);

  // create the map once
  useEffect(() => {
    const m = L.map(el.current).setView(DEFAULT_CENTER, 12);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    }).on('tileerror', () => setTileError(true)).addTo(m);
    groups.current = { static: L.layerGroup().addTo(m), buses: L.layerGroup().addTo(m) };
    m.on('click', (e) => cb.current.onMapClick?.(e.latlng.lat, e.latlng.lng));
    const ro = new ResizeObserver(() => m.invalidateSize());
    ro.observe(el.current);
    map.current = m;
    return () => { ro.disconnect(); m.remove(); map.current = null; markers.current = new Map(); pinMarker.current = null; };
  }, []);

  // stops + route lines; re-fit only when their content changes
  const staticSig = JSON.stringify([stops.map((s) => [s.name, s.lat, s.lng, s.time]), lines.map((l) => [l.id, l.coords.length]), highlight]);
  useEffect(() => {
    const g = groups.current.static;
    if (!g || !map.current) return;
    g.clearLayers();
    const pts = [];
    lines.forEach((l) => { if (l.coords.length > 1) L.polyline(l.coords, { color: l.color || '#4f46e5', weight: 4, opacity: 0.75 }).addTo(g); pts.push(...l.coords); });
    stops.forEach((s) => {
      if (s.lat == null || s.lng == null) return;
      const kind = s.isCollege ? 'college' : s.name === highlight ? 'mine' : 'normal';
      const mk = L.marker([s.lat, s.lng], { icon: stopIcon(kind), title: s.name, keyboard: true }).addTo(g);
      mk.bindPopup(`<b>${esc(s.name)}</b>${s.time ? `<br>Expected ${esc(s.time)}` : ''}${kind === 'mine' ? '<br>Your stop' : ''}`);
      mk.on('click', () => cb.current.onStopSelect?.(s));
      pts.push([s.lat, s.lng]);
    });
    if (pts.length) map.current.fitBounds(pts, { padding: [30, 30], maxZoom: 16 });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [staticSig]);

  // buses: add, move or remove markers without touching the view
  const busSig = JSON.stringify(buses.map((b) => [b.number, b.lat, b.lng, b.status, b.routeName, b.currentLocation, b.nextStop, b.eta, b.updated]));
  useEffect(() => {
    const g = groups.current.buses;
    if (!g) return;
    const seen = new Set();
    buses.forEach((b) => {
      if (b.lat == null || b.lng == null) return;
      seen.add(b.number);
      let mk = markers.current.get(b.number);
      if (!mk) {
        mk = L.marker([b.lat, b.lng], { icon: busIcon(b.status), title: b.number, zIndexOffset: 1000, keyboard: true }).addTo(g);
        if (cb.current.onBusSelect) mk.on('click', () => cb.current.onBusSelect(b.number));
        else mk.bindPopup(busPopup(b));
        markers.current.set(b.number, mk);
      } else {
        mk.setLatLng([b.lat, b.lng]).setIcon(busIcon(b.status));
        if (mk.getPopup()) mk.setPopupContent(busPopup(b));
      }
    });
    markers.current.forEach((mk, n) => { if (!seen.has(n)) { g.removeLayer(mk); markers.current.delete(n); } });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [busSig]);

  // location picker marker
  useEffect(() => {
    const m = map.current;
    if (!m) return;
    if (!pin) { pinMarker.current?.remove(); pinMarker.current = null; return; }
    if (!pinMarker.current) {
      pinMarker.current = L.marker([pin.lat, pin.lng], { icon: stopIcon('mine') }).addTo(m);
      m.setView([pin.lat, pin.lng], 15);
    } else {
      pinMarker.current.setLatLng([pin.lat, pin.lng]);
      if (!m.getBounds().contains([pin.lat, pin.lng])) m.panTo([pin.lat, pin.lng]);
    }
  }, [pin?.lat, pin?.lng]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className={cx('relative isolate w-full overflow-hidden rounded-xl border border-slate-200 bg-slate-100', className)}>
      <div ref={el} role="region" aria-label={label} className="h-full w-full" />
      {tileError && (
        <p role="status" className="absolute bottom-6 left-2 right-2 z-[500] rounded-lg bg-white/95 p-2 text-xs text-slate-700 shadow">
          Map tiles could not load. Check your internet connection.
        </p>
      )}
    </div>
  );
}
