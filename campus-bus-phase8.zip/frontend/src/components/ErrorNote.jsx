export default function ErrorNote({ message, onRetry }) {
  return (
    <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700">
      {message} {onRetry && <button onClick={onRetry} className="font-semibold underline">Try again</button>}
    </p>
  );
}
