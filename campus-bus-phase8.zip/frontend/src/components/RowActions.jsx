import { cx } from '../utils/helpers';

// actions: [{ label, icon: Icon, onClick, danger }]
export default function RowActions({ actions }) {
  return (
    <div className="flex items-center gap-1">
      {actions.map(({ label, icon: Icon, onClick, danger }) => (
        <button key={label} onClick={(e) => { e.stopPropagation(); onClick(); }} aria-label={label} title={label}
          className={cx('grid h-10 w-10 place-items-center rounded-lg', danger ? 'text-red-600 hover:bg-red-50' : 'text-slate-600 hover:bg-slate-100')}>
          <Icon size={18} aria-hidden />
        </button>
      ))}
    </div>
  );
}
