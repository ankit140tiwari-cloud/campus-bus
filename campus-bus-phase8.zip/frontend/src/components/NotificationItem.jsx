import { Bus, Clock, MapPinned, CalendarClock, Siren, Bell, Megaphone, MessageSquareWarning } from 'lucide-react';
import { timeAgo, cx } from '../utils/helpers';

const ICONS = { departed: [Bus, 'bg-brand-50 text-brand-600'], delayed: [Clock, 'bg-amber-50 text-amber-700'], arriving: [Bell, 'bg-green-50 text-green-700'], route: [MapPinned, 'bg-brand-50 text-brand-600'], schedule: [CalendarClock, 'bg-brand-50 text-brand-600'], emergency: [Siren, 'bg-red-50 text-red-700'], announcement: [Megaphone, 'bg-brand-50 text-brand-600'], complaint: [MessageSquareWarning, 'bg-amber-50 text-amber-700'] };

export default function NotificationItem({ n, onRead }) {
  const [Icon, tone] = ICONS[n.type] || ICONS.arriving;
  return (
    <li className={cx('flex gap-3 rounded-xl border p-4', n.read ? 'border-slate-200 bg-white' : 'border-brand-100 bg-brand-50/40')}>
      <span className={cx('grid h-10 w-10 shrink-0 place-items-center rounded-lg', tone)}><Icon size={18} aria-hidden /></span>
      <div className="min-w-0 flex-1">
        <div className="flex items-start justify-between gap-2">
          <p className="font-semibold text-slate-900">{n.title}</p>
          {!n.read && <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-brand-500" aria-label="Unread" />}
        </div>
        <p className="text-sm text-slate-600">{n.message}</p>
        <div className="mt-1 flex items-center gap-3 text-xs text-slate-500">
          <span>{timeAgo(n.minsAgo)}</span>
          {!n.read && <button onClick={() => onRead(n.id)} className="font-medium text-brand-600 hover:underline">Mark as read</button>}
        </div>
      </div>
    </li>
  );
}
