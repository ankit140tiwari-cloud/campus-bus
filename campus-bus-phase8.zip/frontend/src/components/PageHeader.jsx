import { Plus } from 'lucide-react';
import Button from './Button';

export default function PageHeader({ title, subtitle, addLabel, onAdd }) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-3">
      <div><h1 className="text-xl font-bold text-slate-900">{title}</h1>{subtitle && <p className="text-sm text-slate-500">{subtitle}</p>}</div>
      {onAdd && <Button onClick={onAdd}><Plus size={16} aria-hidden /> {addLabel}</Button>}
    </div>
  );
}
