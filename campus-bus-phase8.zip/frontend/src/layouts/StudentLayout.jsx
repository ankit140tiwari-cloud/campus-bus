import { useEffect } from 'react';
import AppShell from './AppShell';
import { STUDENT_NAV } from '../utils/constants';
import { USE_MOCK } from '../utils/config';
import { useToast } from '../components/Toast';
import { listenForeground, pushConfigured, pushEnabled } from '../services/pushService';

export default function StudentLayout() {
  const toast = useToast();
  useEffect(() => {
    if (USE_MOCK || !pushConfigured() || !pushEnabled()) return undefined;
    let off;
    listenForeground((d) => toast(`${d.title}: ${d.body}`)).then((u) => { off = u; }).catch(() => {});
    return () => off?.();
  }, [toast]);
  return <AppShell items={STUDENT_NAV} />;
}
