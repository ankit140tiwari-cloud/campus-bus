import { useCallback, useEffect, useState } from 'react';
import useWebSocket from './useWebSocket';
import { USE_MOCK } from '../utils/config';

// Live positions of every running bus, keyed by bus number. In mock mode it stays empty and the pages keep their sample data.
export default function useBusLocation() {
  const [updates, setUpdates] = useState({});
  const [, tick] = useState(0);

  const onMessage = useCallback((m) => {
    if (m.type === 'snapshot') setUpdates(Object.fromEntries(m.buses.map((b) => [b.bus_number, b])));
    else if (m.type === 'bus_update') setUpdates((u) => ({ ...u, [m.bus.bus_number]: m.bus }));
    else if (m.type === 'trip_ended' && m.bus_number) setUpdates((u) => ({ ...u, [m.bus_number]: { ended: true } }));
  }, []);

  const { status } = useWebSocket(USE_MOCK ? null : '/ws/fleet', { onMessage });

  // re-render now and then so a bus that stops sending turns Offline even though no message arrives
  useEffect(() => {
    if (USE_MOCK) return undefined;
    const id = setInterval(() => tick((x) => x + 1), 15000);
    return () => clearInterval(id);
  }, []);

  return { updates, status: USE_MOCK ? 'mock' : status };
}
