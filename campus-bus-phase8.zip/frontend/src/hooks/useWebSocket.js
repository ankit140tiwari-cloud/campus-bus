import { useCallback, useEffect, useRef, useState } from 'react';
import { getStoredAuth } from '../services/api';

const WS_BASE = import.meta.env.VITE_WS_URL || `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}`;

// Connects to `path` (e.g. "/ws/fleet"), authenticates with the stored JWT as the first message, answers with
// reconnect + backoff, and sends a ping every 25 s so proxies keep the socket open. path=null means disconnected.
export default function useWebSocket(path, { onMessage } = {}) {
  const [status, setStatus] = useState('closed'); // connecting | open | closed
  const sock = useRef(null);
  const handler = useRef(onMessage);
  handler.current = onMessage;

  useEffect(() => {
    if (!path) { setStatus('closed'); return undefined; }
    let stopped = false, retry = 0, retryTimer, pingTimer;

    const connect = () => {
      setStatus('connecting');
      const ws = new WebSocket(`${WS_BASE}${path}`);
      sock.current = ws;
      ws.onopen = () => ws.send(JSON.stringify({ type: 'auth', token: getStoredAuth()?.token }));
      ws.onmessage = (e) => {
        let msg;
        try { msg = JSON.parse(e.data); } catch { return; }
        if (msg.type === 'auth_ok') { retry = 0; setStatus('open'); }
        handler.current?.(msg);
      };
      ws.onclose = (e) => {
        clearInterval(pingTimer);
        setStatus('closed');
        if (stopped || e.code === 4401 || e.code === 4403) return; // bad or revoked token: do not hammer the server
        retryTimer = setTimeout(connect, Math.min(1000 * 2 ** retry++, 15000));
      };
      pingTimer = setInterval(() => ws.readyState === 1 && ws.send('{"type":"ping"}'), 25000);
    };

    connect();
    return () => { stopped = true; clearTimeout(retryTimer); clearInterval(pingTimer); sock.current?.close(); sock.current = null; };
  }, [path]);

  const send = useCallback((obj) => {
    if (sock.current?.readyState !== 1) return false;
    sock.current.send(JSON.stringify(obj));
    return true;
  }, []);

  return { status, send };
}
