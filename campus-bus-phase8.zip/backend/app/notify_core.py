"""Pure notification rules (no framework imports, so they can be unit-tested anywhere)."""

# category -> the student preference that controls it. Emergencies, announcements and complaint updates are always delivered.
PREF_BY_CATEGORY = {"departed": "departed", "delayed": "delayed", "arriving": "arriving", "route": "changes", "schedule": "changes"}
ALWAYS = {"emergency", "announcement", "complaint"}


def wants(prefs: dict | None, category: str) -> bool:
    if category in ALWAYS:
        return True
    key = PREF_BY_CATEGORY.get(category)
    return True if key is None else bool((prefs or {}).get(key, True))


def disabled_categories(prefs: dict | None) -> list[str]:
    return [c for c, k in PREF_BY_CATEGORY.items() if not (prefs or {}).get(k, True)]
