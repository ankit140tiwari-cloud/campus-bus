import asyncio
import json
import logging
import math
import time
from datetime import datetime, timezone

import jwt
from fastapi import APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload
from starlette.concurrency import run_in_threadpool

from .. import config
from ..database import SessionLocal, get_db
from ..deps import get_current_user, require_admin
from ..models import Bus, BusLocation, Route, RouteStop, Trip, User
from ..notify import create_notification
from ..security import decode_token
from ..tracking import manager
from ..tracking_core import BusState
from ..utils import get_or_404

log = logging.getLogger("tracking")
router = APIRouter(tags=["tracking"])      # mounted under /api
ws_router = APIRouter(tags=["tracking-ws"])  # mounted at the root: /ws/...


class TripStartIn(BaseModel):
    bus_id: int


def build_state(db: Session, bus: Bus, trip: Trip) -> BusState | None:
    route = db.get(Route, trip.route_id) if trip.route_id else None
    if route is None:
        return None
    links = db.scalars(select(RouteStop).where(RouteStop.route_id == route.id).order_by(RouteStop.stop_order).options(joinedload(RouteStop.stop))).all()
    stops = [{"name": l.stop.stop_name, "lat": l.stop.latitude, "lng": l.stop.longitude, "minutes": l.expected_time.hour * 60 + l.expected_time.minute} for l in links]
    return BusState(bus_id=bus.id, bus_number=bus.bus_number, route_id=route.id, route_name=route.route_name, trip_id=trip.id, stops=stops)


def restore_states() -> None:
    """After a restart, rebuild state for trips that are still open in the database."""
    with SessionLocal() as db:
        for trip in db.scalars(select(Trip).where(Trip.ended_at.is_(None))).all():
            bus = db.get(Bus, trip.bus_id)
            state = build_state(db, bus, trip) if bus else None
            if state:
                manager.states[bus.id] = state


# ----------------------------------------------------------------- REST
def _start_trip(db: Session, bus_id: int, admin: User) -> dict:
    bus = get_or_404(db, Bus, bus_id, "Bus")
    if bus.status != "Active":
        raise HTTPException(400, "Activate this bus before starting a trip.")
    if bus.route_id is None:
        raise HTTPException(400, "Assign a route to this bus before starting a trip.")
    if db.scalar(select(Trip.id).where(Trip.bus_id == bus.id, Trip.ended_at.is_(None))) is not None:
        raise HTTPException(409, "This bus already has an active trip.")
    trip = Trip(bus_id=bus.id, route_id=bus.route_id, started_by=admin.id)
    db.add(trip)
    db.flush()
    state = build_state(db, bus, trip)
    if state is None or len(state.stops) < 2:
        db.rollback()
        raise HTTPException(400, "This bus's route needs at least two stops.")
    db.commit()
    manager.states[bus.id] = state
    try:
        create_notification(db, title=f"{bus.bus_number} departed", message=f"{bus.bus_number} has started its trip on {state.route_name}.",
                            category="departed", target_type="route", target_id=state.route_id)
    except Exception:
        log.exception("could not send departure notification")
    return {"trip_id": trip.id, "bus_id": bus.id, "bus_number": bus.bus_number, "route_id": bus.route_id, "started_at": trip.started_at.isoformat()}


@router.post("/trips/start", status_code=201)
async def start_trip(data: TripStartIn, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    return await run_in_threadpool(_start_trip, db, data.bus_id, admin)


def _end_trip(db: Session, trip_id: int) -> Trip:
    trip = get_or_404(db, Trip, trip_id, "Trip")
    if trip.ended_at is not None:
        raise HTTPException(409, "This trip has already ended.")
    trip.ended_at = datetime.now(timezone.utc)
    db.commit()
    return trip


@router.post("/trips/{trip_id}/end")
async def end_trip(trip_id: int, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    trip = await run_in_threadpool(_end_trip, db, trip_id)
    state = manager.states.pop(trip.bus_id, None)
    await manager.broadcast({"type": "trip_ended", "bus_id": trip.bus_id, "bus_number": state.bus_number if state else None}, trip.bus_id)
    return {"trip_id": trip.id, "ended_at": trip.ended_at.isoformat()}


@router.get("/trips/active")
def active_trips(db: Session = Depends(get_db), _: User = Depends(require_admin)):
    rows = db.execute(select(Trip, Bus.bus_number).join(Bus, Bus.id == Trip.bus_id).where(Trip.ended_at.is_(None))).all()
    return [{"trip_id": t.id, "bus_id": t.bus_id, "bus_number": n, "started_at": t.started_at.isoformat()} for t, n in rows]


@router.get("/tracking/live")
def live(_: User = Depends(get_current_user)):
    return manager.all_snaps()


@router.get("/buses/{bus_id}/location")
def bus_location(bus_id: int, db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    bus = get_or_404(db, Bus, bus_id, "Bus")
    s = manager.states.get(bus_id)
    if s and s.ts:
        return manager.snap(s)
    last = db.scalar(select(BusLocation).where(BusLocation.bus_id == bus_id).order_by(BusLocation.timestamp.desc()).limit(1))
    return {"bus_id": bus.id, "bus_number": bus.bus_number, "trip_active": s is not None, "status": "Offline",
            "latitude": last.latitude if last else None, "longitude": last.longitude if last else None,
            "timestamp": last.timestamp.isoformat() if last else None}


# ------------------------------------------------------------ WebSocket
def _load_user(uid: int) -> dict | None:
    with SessionLocal() as db:
        u = db.get(User, uid)
        return {"id": u.id, "role": u.role, "status": u.status} if u else None


def _notify_delay(bus_id: int, bus_number: str, route_id: int, delay: int) -> None:
    try:
        with SessionLocal() as db:
            create_notification(db, title=f"{bus_number} delayed", message=f"{bus_number} is running about {delay} minutes late.",
                                category="delayed", target_type="route", target_id=route_id)
    except Exception:
        log.exception("could not send delay notification")


def _save_location(bus_id: int, lat: float, lng: float, ts: datetime) -> None:
    try:
        with SessionLocal() as db:
            db.add(BusLocation(bus_id=bus_id, latitude=lat, longitude=lng, timestamp=ts))
            db.commit()
    except Exception:  # history is best-effort; never break the live stream
        log.exception("could not save bus location")


async def _auth(ws: WebSocket) -> dict | None:
    """Token goes in the first message, not the URL, so it never appears in server or proxy logs."""
    await ws.accept()
    try:
        msg = json.loads(await asyncio.wait_for(ws.receive_text(), timeout=10))
        if msg.get("type") != "auth":
            raise ValueError
        uid = int(decode_token(msg["token"])["sub"])
    except (asyncio.TimeoutError, json.JSONDecodeError, KeyError, ValueError, TypeError, jwt.PyJWTError, WebSocketDisconnect):
        await _close(ws, 4401)
        return None
    user = await run_in_threadpool(_load_user, uid)
    if not user or user["status"] != "Active":
        await _close(ws, 4403)
        return None
    await ws.send_json({"type": "auth_ok", "role": user["role"]})
    return user


async def _close(ws: WebSocket, code: int) -> None:
    try:
        await ws.close(code=code)
    except Exception:
        pass


async def _reply(ws: WebSocket, msg: dict) -> None:
    try:
        await ws.send_json(msg)
    except Exception:
        pass


def _parse_fix(msg: dict) -> tuple[float, float, datetime]:
    lat, lng = float(msg["latitude"]), float(msg["longitude"])
    if not (math.isfinite(lat) and math.isfinite(lng) and -90 <= lat <= 90 and -180 <= lng <= 180):
        raise ValueError("out of range")
    now = datetime.now(timezone.utc)
    ts = now
    raw = msg.get("timestamp")
    if isinstance(raw, (int, float)) and math.isfinite(raw):  # Geolocation timestamps are epoch milliseconds
        try:
            cand = datetime.fromtimestamp(raw / 1000, tz=timezone.utc)
            if abs((now - cand).total_seconds()) <= 300:  # ignore a phone with a wrong clock
                ts = cand
        except (OverflowError, OSError, ValueError):
            pass
    return lat, lng, ts


async def _handle_bus_message(ws: WebSocket, user: dict, bus_id: int, raw: str) -> None:
    if len(raw) > 2048:
        return await _reply(ws, {"type": "error", "detail": "Message too large."})
    try:
        msg = json.loads(raw)
        kind = msg.get("type")
    except (json.JSONDecodeError, AttributeError):
        return await _reply(ws, {"type": "error", "detail": "Invalid message."})
    if kind == "ping":
        return await _reply(ws, {"type": "pong"})
    if kind != "location":
        return
    if user["role"] != "admin":
        return await _reply(ws, {"type": "error", "detail": "Only admins can send bus locations."})
    s = manager.states.get(bus_id)
    if s is None:
        return await _reply(ws, {"type": "error", "detail": "No active trip for this bus. Start the trip first."})
    try:
        lat, lng, ts = _parse_fix(msg)
    except (KeyError, TypeError, ValueError):
        return await _reply(ws, {"type": "error", "detail": "Latitude and longitude must be valid numbers."})
    now = time.monotonic()
    if now - s.last_accept < config.MIN_UPDATE_INTERVAL_S:
        return  # too frequent; drop silently
    s.last_accept = now
    manager.apply(s, lat, lng, ts)
    if now - s.last_db_write >= config.DB_WRITE_INTERVAL_S:
        s.last_db_write = now
        await run_in_threadpool(_save_location, bus_id, lat, lng, ts)
    snap = manager.snap(s)
    if snap["status"] == "Delayed" and s.last_status != "Delayed" and now - s.last_delay_notice > 600:  # at most one delay notice per 10 min
        s.last_delay_notice = now
        await run_in_threadpool(_notify_delay, s.bus_id, s.bus_number, s.route_id, snap["delay_min"])
    s.last_status = snap["status"]
    await manager.broadcast({"type": "bus_update", "bus": snap}, bus_id)
    await _reply(ws, {"type": "ack"})


@ws_router.websocket("/ws/bus/{bus_id}")
async def ws_bus(ws: WebSocket, bus_id: int):
    """Admin Trip Control sends {type:'location', latitude, longitude, timestamp}; any signed-in user receives updates."""
    user = await _auth(ws)
    if user is None:
        return
    manager.bus_subs.setdefault(bus_id, set()).add(ws)
    try:
        s = manager.states.get(bus_id)
        if s and s.ts:
            await ws.send_json({"type": "bus_update", "bus": manager.snap(s)})
        while True:
            await _handle_bus_message(ws, user, bus_id, await ws.receive_text())
    except WebSocketDisconnect:
        pass
    finally:
        manager.drop(ws)


@ws_router.websocket("/ws/fleet")
async def ws_fleet(ws: WebSocket):
    """Read-only stream of every running bus (student and admin dashboards)."""
    user = await _auth(ws)
    if user is None:
        return
    manager.fleet.add(ws)
    try:
        await ws.send_json({"type": "snapshot", "buses": manager.all_snaps()})
        while True:
            raw = await ws.receive_text()
            if '"ping"' in raw[:64]:
                await _reply(ws, {"type": "pong"})
    except WebSocketDisconnect:
        pass
    finally:
        manager.drop(ws)


async def watch_offline() -> None:
    """Tell subscribers when a bus goes quiet, since no message would otherwise announce it."""
    while True:
        await asyncio.sleep(15)
        for s in list(manager.states.values()):
            snap = manager.snap(s)
            if s.ts and snap["status"] == "Offline" and not s.offline_sent:
                s.offline_sent = True
                await manager.broadcast({"type": "bus_update", "bus": snap}, s.bus_id)
