from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from ..database import get_db
from ..deps import get_current_user, require_admin
from ..models import Bus, Route, Schedule, User
from ..schemas import ScheduleIn, StatusIn
from ..utils import get_or_404, hhmm

router = APIRouter(prefix="/schedules", tags=["schedules"])


def schedule_out(s: Schedule) -> dict:
    return {"id": s.id, "bus_id": s.bus_id, "bus_number": s.bus.bus_number, "route_id": s.route_id, "route_name": s.route.route_name,
            "day": s.day, "departure_time": hhmm(s.departure_time), "arrival_time": hhmm(s.arrival_time), "status": s.status}


def _check(db: Session, data: ScheduleIn, sched_id: int | None) -> None:
    get_or_404(db, Bus, data.bus_id, "Bus")
    get_or_404(db, Route, data.route_id, "Route")
    if data.arrival_time <= data.departure_time:
        raise HTTPException(400, "Arrival must be after departure.")
    q = select(Schedule.id).where(Schedule.bus_id == data.bus_id, Schedule.day == data.day, Schedule.departure_time == data.departure_time)
    if sched_id:
        q = q.where(Schedule.id != sched_id)
    if db.scalar(q) is not None:
        raise HTTPException(409, "This bus already has a trip at that time on that day.")


def _load(db: Session, sched_id: int) -> Schedule:
    s = db.scalar(select(Schedule).where(Schedule.id == sched_id).options(joinedload(Schedule.bus), joinedload(Schedule.route)))
    if s is None:
        raise HTTPException(404, "Schedule not found.")
    return s


@router.get("")
def list_schedules(day: str | None = None, db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    q = select(Schedule).options(joinedload(Schedule.bus), joinedload(Schedule.route)).order_by(Schedule.day, Schedule.departure_time)
    if day:
        q = q.where(Schedule.day == day)
    return [schedule_out(s) for s in db.scalars(q).all()]


@router.post("", status_code=201)
def create_schedule(data: ScheduleIn, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    _check(db, data, None)
    s = Schedule(**data.model_dump())
    db.add(s)
    db.commit()
    return schedule_out(_load(db, s.id))


@router.put("/{sched_id}")
def update_schedule(sched_id: int, data: ScheduleIn, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    s = get_or_404(db, Schedule, sched_id, "Schedule")
    _check(db, data, sched_id)
    for k, v in data.model_dump().items():
        setattr(s, k, v)
    db.commit()
    db.expire_all()
    return schedule_out(_load(db, sched_id))


@router.patch("/{sched_id}/status")
def set_status(sched_id: int, data: StatusIn, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    s = get_or_404(db, Schedule, sched_id, "Schedule")
    s.status = data.status
    db.commit()
    return schedule_out(_load(db, sched_id))


@router.delete("/{sched_id}", status_code=204)
def delete_schedule(sched_id: int, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    db.delete(get_or_404(db, Schedule, sched_id, "Schedule"))
    db.commit()
