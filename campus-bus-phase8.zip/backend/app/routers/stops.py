from datetime import time

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import delete, func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, joinedload, selectinload

from ..database import get_db
from ..deps import get_current_user, require_admin
from ..models import Route, RouteStop, Stop, User
from ..schemas import StopIn
from ..utils import get_or_404, renumber_route

router = APIRouter(prefix="/stops", tags=["stops"])


def stop_out(s: Stop) -> dict:
    links = sorted(s.route_links, key=lambda l: l.route_id)
    return {"id": s.id, "stop_name": s.stop_name, "latitude": s.latitude, "longitude": s.longitude, "status": s.status,
            "routes": [{"route_id": l.route_id, "route_name": l.route.route_name, "stop_order": l.stop_order} for l in links]}


def _load(db: Session, stop_id: int) -> Stop:
    s = db.scalar(select(Stop).where(Stop.id == stop_id).options(selectinload(Stop.route_links).joinedload(RouteStop.route)))
    if s is None:
        raise HTTPException(404, "Stop not found.")
    return s


def _name_taken(db: Session, name: str, stop_id: int | None) -> bool:
    q = select(Stop.id).where(func.lower(Stop.stop_name) == name.lower())
    if stop_id:
        q = q.where(Stop.id != stop_id)
    return db.scalar(q) is not None


def _assign(db: Session, stop: Stop, route_id: int | None, order: int | None) -> None:
    """Put the stop on exactly one route (or none) at the requested position, keeping its time if it was already there."""
    keep_time = time(7, 0)
    touched = set()
    for link in db.scalars(select(RouteStop).where(RouteStop.stop_id == stop.id)).all():
        touched.add(link.route_id)
        if link.route_id == route_id:
            keep_time = link.expected_time
    db.execute(delete(RouteStop).where(RouteStop.stop_id == stop.id))
    db.flush()
    if route_id is not None:
        get_or_404(db, Route, route_id, "Route")
        count = db.scalar(select(func.count()).select_from(RouteStop).where(RouteStop.route_id == route_id)) or 0
        pos = min(max((order or count + 1), 1), count + 1)
        # shift later stops down to make room, then insert
        for link in db.scalars(select(RouteStop).where(RouteStop.route_id == route_id, RouteStop.stop_order >= pos)).all():
            link.stop_order += 1
        db.add(RouteStop(route_id=route_id, stop_id=stop.id, stop_order=pos, expected_time=keep_time))
        touched.add(route_id)
    db.flush()
    for rid in touched:
        renumber_route(db, rid)


@router.get("")
def list_stops(db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    stops = db.scalars(select(Stop).options(selectinload(Stop.route_links).joinedload(RouteStop.route)).order_by(Stop.stop_name)).all()
    return [stop_out(s) for s in stops]


@router.post("", status_code=201)
def create_stop(data: StopIn, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    if _name_taken(db, data.stop_name, None):
        raise HTTPException(409, "A stop with this name already exists.")
    stop = Stop(stop_name=data.stop_name, latitude=data.latitude, longitude=data.longitude, status=data.status)
    db.add(stop)
    try:
        db.flush()
        _assign(db, stop, data.route_id, data.stop_order)
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "That change conflicts with existing data.")
    db.expire_all()
    return stop_out(_load(db, stop.id))


@router.put("/{stop_id}")
def update_stop(stop_id: int, data: StopIn, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    stop = get_or_404(db, Stop, stop_id, "Stop")
    if _name_taken(db, data.stop_name, stop_id):
        raise HTTPException(409, "A stop with this name already exists.")
    old = stop.stop_name
    stop.stop_name, stop.latitude, stop.longitude, stop.status = data.stop_name, data.latitude, data.longitude, data.status
    # keep route start/destination text in step with a renamed stop
    for r in db.scalars(select(Route).where((Route.start_point == old) | (Route.destination == old))).all():
        if r.start_point == old:
            r.start_point = data.stop_name
        if r.destination == old:
            r.destination = data.stop_name
    try:
        _assign(db, stop, data.route_id, data.stop_order)
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "That change conflicts with existing data.")
    db.expire_all()
    return stop_out(_load(db, stop_id))


@router.delete("/{stop_id}", status_code=204)
def delete_stop(stop_id: int, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    stop = get_or_404(db, Stop, stop_id, "Stop")
    route_ids = {l.route_id for l in stop.route_links}
    db.delete(stop)  # route_stops cascade; users.default_stop_id and complaints.stop_id are set to NULL by the database
    db.flush()
    for rid in route_ids:
        renumber_route(db, rid)
    db.commit()
