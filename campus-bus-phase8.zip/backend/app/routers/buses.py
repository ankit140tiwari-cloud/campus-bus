from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session, joinedload

from ..database import get_db
from ..deps import get_current_user, require_admin
from ..models import Bus, Route, User
from ..schemas import BusIn, StatusIn
from ..tracking import manager
from ..utils import get_or_404

router = APIRouter(prefix="/buses", tags=["buses"])


def bus_out(b: Bus) -> dict:
    return {"id": b.id, "bus_number": b.bus_number, "registration_number": b.registration_number, "capacity": b.capacity,
            "route_id": b.route_id, "route_name": b.route.route_name if b.route else None, "status": b.status}


def _check(db: Session, data: BusIn, bus_id: int | None) -> None:
    for col, value, msg in ((Bus.bus_number, data.bus_number, "This bus number already exists."),
                            (Bus.registration_number, data.registration_number, "This registration number already exists.")):
        q = select(Bus.id).where(func.lower(col) == value.lower())
        if bus_id:
            q = q.where(Bus.id != bus_id)
        if db.scalar(q) is not None:
            raise HTTPException(409, msg)
    if data.route_id is not None:
        get_or_404(db, Route, data.route_id, "Route")


@router.get("")
def list_buses(db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    return [bus_out(b) for b in db.scalars(select(Bus).options(joinedload(Bus.route)).order_by(Bus.bus_number)).all()]


@router.get("/{bus_id}")
def get_bus(bus_id: int, db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    return bus_out(get_or_404(db, Bus, bus_id, "Bus"))


@router.post("", status_code=201)
def create_bus(data: BusIn, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    _check(db, data, None)
    bus = Bus(**data.model_dump())
    db.add(bus)
    db.commit()
    db.refresh(bus)
    return bus_out(bus)


@router.put("/{bus_id}")
def update_bus(bus_id: int, data: BusIn, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    bus = get_or_404(db, Bus, bus_id, "Bus")
    _check(db, data, bus_id)
    for k, v in data.model_dump().items():
        setattr(bus, k, v)
    db.commit()
    db.refresh(bus)
    return bus_out(bus)


@router.patch("/{bus_id}/status")
def set_status(bus_id: int, data: StatusIn, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    bus = get_or_404(db, Bus, bus_id, "Bus")
    bus.status = data.status
    db.commit()
    return bus_out(bus)


@router.delete("/{bus_id}", status_code=204)
def delete_bus(bus_id: int, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    db.delete(get_or_404(db, Bus, bus_id, "Bus"))  # schedules, trips and locations cascade
    db.commit()
    manager.states.pop(bus_id, None)
