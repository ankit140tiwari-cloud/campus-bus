import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session, joinedload
from starlette.concurrency import run_in_threadpool

from .. import config
from ..database import get_db
from ..deps import get_current_user, require_admin
from ..models import Bus, Complaint, Route, Stop, User
from ..notify import create_notification
from ..schemas import ComplaintUpdateIn
from ..utils import get_or_404

router = APIRouter(prefix="/complaints", tags=["complaints"])

ISSUE_TYPES = ["Bus Delay", "Bus Overcrowding", "Bus Not Available", "Stop Problem", "Route Problem", "Other"]
PRIORITY_BY_TYPE = {"Bus Not Available": "High", "Bus Delay": "Medium", "Bus Overcrowding": "Medium", "Route Problem": "Medium", "Stop Problem": "Low", "Other": "Low"}
UPLOAD_DIR = Path(config.UPLOAD_DIR) / "complaints"
MEDIA = {"jpg": "image/jpeg", "png": "image/png", "webp": "image/webp"}


def _sniff(data: bytes) -> str | None:
    """Decide the type from the file's own bytes, never from the filename or the client's content-type."""
    if data[:3] == b"\xff\xd8\xff":
        return "jpg"
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "png"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "webp"
    return None


def _out(c: Complaint) -> dict:
    return {"id": c.id, "code": f"C-{c.id:04d}", "student_id": c.student_id, "student": c.student.name, "issue_type": c.issue_type,
            "description": c.description, "priority": c.priority, "status": c.status,
            "bus_id": c.bus_id, "bus_number": c.bus.bus_number if c.bus else None, "route_id": c.route_id, "route_name": c.route.route_name if c.route else None,
            "stop_id": c.stop_id, "stop_name": c.stop.stop_name if c.stop else None, "has_image": bool(c.image_path),
            "created_at": c.created_at.astimezone(timezone.utc).isoformat(), "updated_at": c.updated_at.astimezone(timezone.utc).isoformat()}


_LOAD = (joinedload(Complaint.student), joinedload(Complaint.bus), joinedload(Complaint.route), joinedload(Complaint.stop))


def _create(db: Session, user: User, issue_type: str, description: str, bus_id, route_id, stop_id, image: bytes | None, ext: str | None) -> dict:
    since = datetime.now(timezone.utc) - timedelta(hours=1)
    if (db.scalar(select(func.count()).select_from(Complaint).where(Complaint.student_id == user.id, Complaint.created_at >= since)) or 0) >= config.COMPLAINTS_PER_HOUR:
        raise HTTPException(429, "You have sent several reports in the last hour. Please wait a while before sending another.")
    for model, value, label in ((Bus, bus_id, "Bus"), (Route, route_id, "Route"), (Stop, stop_id, "Stop")):
        if value is not None:
            get_or_404(db, model, value, label)
    c = Complaint(student_id=user.id, bus_id=bus_id, route_id=route_id, stop_id=stop_id, issue_type=issue_type, description=description,
                  priority=PRIORITY_BY_TYPE[issue_type])
    db.add(c)
    db.flush()
    if image:
        UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
        c.image_path = f"{uuid.uuid4().hex}.{ext}"  # our own name; the uploaded filename is never used
        (UPLOAD_DIR / c.image_path).write_bytes(image)
    db.commit()
    return _out(db.scalar(select(Complaint).where(Complaint.id == c.id).options(*_LOAD)))


@router.post("", status_code=201)
async def create_complaint(issue_type: str = Form(...), description: str = Form(...), bus_id: int | None = Form(None), route_id: int | None = Form(None),
                           stop_id: int | None = Form(None), image: UploadFile | None = File(None),
                           db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    if user.role != "student":
        raise HTTPException(403, "Only students can report issues.")
    description = description.strip()
    if issue_type not in ISSUE_TYPES:
        raise HTTPException(400, "Choose a valid issue type.")
    if not 10 <= len(description) <= 2000:
        raise HTTPException(400, "Describe the problem in 10 to 2000 characters.")
    data, ext = None, None
    if image is not None and image.filename:
        data = await image.read(config.MAX_UPLOAD_BYTES + 1)
        if len(data) > config.MAX_UPLOAD_BYTES:
            raise HTTPException(413, f"The photo is too large (limit {config.MAX_UPLOAD_BYTES // 1024 // 1024} MB).")
        ext = _sniff(data)
        if ext is None:
            raise HTTPException(400, "Upload a JPEG, PNG or WebP photo.")
    return await run_in_threadpool(_create, db, user, issue_type, description, bus_id, route_id, stop_id, data, ext)


@router.get("")
def list_complaints(status: str | None = None, priority: str | None = None, q: str | None = None,
                    db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    stmt = select(Complaint).options(*_LOAD).order_by(Complaint.created_at.desc(), Complaint.id.desc()).limit(300)
    if user.role != "admin":
        stmt = stmt.where(Complaint.student_id == user.id)  # students only ever see their own reports
    if status in ("Pending", "Investigating", "Resolved"):
        stmt = stmt.where(Complaint.status == status)
    if priority in ("Low", "Medium", "High"):
        stmt = stmt.where(Complaint.priority == priority)
    if q and user.role == "admin":
        like = f"%{q}%"
        stmt = stmt.join(User, User.id == Complaint.student_id).where(or_(User.name.ilike(like), Complaint.issue_type.ilike(like), Complaint.description.ilike(like)))
    return [_out(c) for c in db.scalars(stmt).unique().all()]


@router.put("/{complaint_id}")
async def update_complaint(complaint_id: int, data: ComplaintUpdateIn, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    if data.status is None and data.priority is None:
        raise HTTPException(400, "Nothing to update.")

    def work() -> dict:
        c = db.scalar(select(Complaint).where(Complaint.id == complaint_id).options(*_LOAD))
        if c is None:
            raise HTTPException(404, "Complaint not found.")
        changed = data.status is not None and data.status != c.status
        if data.status is not None:
            c.status = data.status
        if data.priority is not None:
            c.priority = data.priority
        db.commit()
        db.refresh(c)
        if changed:  # tell the student, in the app and by push
            create_notification(db, title=f"Report C-{c.id:04d} update", message=f'Your report "{c.issue_type}" is now {c.status}.',
                                category="complaint", target_type="user", target_id=c.student_id)
        return _out(db.scalar(select(Complaint).where(Complaint.id == c.id).options(*_LOAD)))

    return await run_in_threadpool(work)


@router.get("/{complaint_id}/image")
def complaint_image(complaint_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    c = get_or_404(db, Complaint, complaint_id, "Complaint")
    if user.role != "admin" and c.student_id != user.id:
        raise HTTPException(404, "Complaint not found.")  # same answer as a missing one, so ids cannot be probed
    if not c.image_path:
        raise HTTPException(404, "This report has no photo.")
    path = UPLOAD_DIR / Path(c.image_path).name
    if not path.is_file():
        raise HTTPException(404, "Photo not found.")
    return FileResponse(path, media_type=MEDIA.get(path.suffix.lstrip("."), "application/octet-stream"), headers={"X-Content-Type-Options": "nosniff"})
