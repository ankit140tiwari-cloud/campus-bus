from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import or_, select
from sqlalchemy.orm import Session, joinedload

from ..database import get_db
from ..deps import require_admin
from ..models import User
from ..schemas import StatusIn
from .auth import user_out

router = APIRouter(prefix="/students", tags=["students"])


@router.get("")
def list_students(q: str | None = None, status: str | None = None, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    stmt = select(User).where(User.role == "student").options(joinedload(User.default_stop)).order_by(User.name)
    if q:
        like = f"%{q.lower()}%"
        stmt = stmt.where(or_(User.name.ilike(like), User.email.ilike(like), User.student_id.ilike(like), User.department.ilike(like)))
    if status in ("Active", "Inactive"):
        stmt = stmt.where(User.status == status)
    return [user_out(u) for u in db.scalars(stmt).all()]


@router.put("/{user_id}/status")
def set_status(user_id: int, data: StatusIn, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    u = db.get(User, user_id)
    if u is None or u.role != "student":
        raise HTTPException(404, "Student not found.")
    u.status = data.status
    db.commit()
    return user_out(u)
