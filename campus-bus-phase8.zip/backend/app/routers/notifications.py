from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import delete, select
from sqlalchemy.orm import Session
from starlette.concurrency import run_in_threadpool

from ..database import get_db
from ..deps import get_current_user, require_admin
from ..models import Bus, DeviceToken, Notification, NotificationRead, Route, User
from ..notify import create_notification, recipient_ids, visible_to
from ..schemas import DeviceTokenIn, NotificationIn
from ..utils import get_or_404

router = APIRouter(prefix="/notifications", tags=["notifications"])


def _out(n: Notification, read: bool | None = None, **extra) -> dict:
    d = {"id": n.id, "category": n.category, "title": n.title, "message": n.message, "priority": n.priority,
         "target_type": n.target_type, "target_id": n.target_id, "created_at": n.created_at.astimezone(timezone.utc).isoformat()}
    if read is not None:
        d["read"] = read
    return {**d, **extra}


def _visible(db: Session, user: User, limit: int = 100) -> list[Notification]:
    return list(db.scalars(select(Notification).where(visible_to(user)).order_by(Notification.created_at.desc(), Notification.id.desc()).limit(limit)).all())


@router.get("")
def my_notifications(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    read_ids = set(db.scalars(select(NotificationRead.notification_id).where(NotificationRead.user_id == user.id)).all())
    return [_out(n, n.id in read_ids) for n in _visible(db, user)]


@router.post("/read-all", status_code=204)
def read_all(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    have = set(db.scalars(select(NotificationRead.notification_id).where(NotificationRead.user_id == user.id)).all())
    for n in _visible(db, user, 500):
        if n.id not in have:
            db.add(NotificationRead(notification_id=n.id, user_id=user.id))
    db.commit()


@router.post("/{notification_id}/read", status_code=204)
def read_one(notification_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_or_404(db, Notification, notification_id, "Notification")
    if db.get(NotificationRead, (notification_id, user.id)) is None:
        db.add(NotificationRead(notification_id=notification_id, user_id=user.id))
        db.commit()


@router.post("/device-token", status_code=204)
def register_token(data: DeviceTokenIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    row = db.scalar(select(DeviceToken).where(DeviceToken.token == data.token))
    if row:
        row.user_id = user.id  # the same browser may be used by a different account later
    else:
        db.add(DeviceToken(user_id=user.id, token=data.token))
    db.commit()


@router.delete("/device-token", status_code=204)
def unregister_token(data: DeviceTokenIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    db.execute(delete(DeviceToken).where(DeviceToken.token == data.token, DeviceToken.user_id == user.id))
    db.commit()


# ------------------------------------------------------------------ admin
@router.get("/admin")
def admin_history(db: Session = Depends(get_db), _: User = Depends(require_admin)):
    rows = db.scalars(select(Notification).where(Notification.target_type != "user").order_by(Notification.created_at.desc(), Notification.id.desc()).limit(50)).all()
    routes = {r.id: r.route_name for r in db.scalars(select(Route)).all()}
    buses = {b.id: b.bus_number for b in db.scalars(select(Bus)).all()}
    out = []
    for n in rows:
        label = "All students" if n.target_type == "all" else f"Route: {routes.get(n.target_id, 'deleted route')}" if n.target_type == "route" else f"Bus: {buses.get(n.target_id, 'deleted bus')}"
        out.append(_out(n, target=label, recipients=len(recipient_ids(db, n))))
    return out


@router.post("", status_code=201)
async def send_announcement(data: NotificationIn, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    if data.target_type == "all":
        data.target_id = None
    elif data.target_id is None:
        raise HTTPException(400, "Choose a route." if data.target_type == "route" else "Choose a bus.")
    elif data.target_type == "route":
        get_or_404(db, Route, data.target_id, "Route")
    else:
        get_or_404(db, Bus, data.target_id, "Bus")
    result = await run_in_threadpool(
        lambda: create_notification(db, title=data.title, message=data.message, category="emergency" if data.priority == "Emergency" else "announcement",
                                    priority=data.priority, target_type=data.target_type, target_id=data.target_id))
    return result
