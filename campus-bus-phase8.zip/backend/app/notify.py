import logging

from sqlalchemy import and_, or_, select
from sqlalchemy.orm import Session

from . import push
from .models import Bus, DeviceToken, Notification, RouteStop, User
from .notify_core import disabled_categories, wants

log = logging.getLogger("notify")


def visible_to(user: User):
    """SQL condition: which notifications a student should see, from their default stop and their preferences."""
    my_routes = select(RouteStop.route_id).where(RouteStop.stop_id == user.default_stop_id)
    cond = or_(
        Notification.target_type == "all",
        and_(Notification.target_type == "route", Notification.target_id.in_(my_routes)),
        and_(Notification.target_type == "bus", Notification.target_id.in_(select(Bus.id).where(Bus.route_id.in_(my_routes)))),
        and_(Notification.target_type == "user", Notification.target_id == user.id),
    )
    off = disabled_categories(user.notification_prefs)
    return and_(cond, Notification.category.notin_(off)) if off else cond


def recipient_ids(db: Session, n: Notification) -> list[int]:
    if n.target_type == "user":
        users = db.scalars(select(User).where(User.id == n.target_id, User.status == "Active")).all()
    else:
        q = select(User).where(User.role == "student", User.status == "Active")
        if n.target_type in ("route", "bus"):
            route_ids = [n.target_id] if n.target_type == "route" else select(Bus.route_id).where(Bus.id == n.target_id)
            q = q.where(User.default_stop_id.in_(select(RouteStop.stop_id).where(RouteStop.route_id.in_(route_ids))))
        users = db.scalars(q).all()
    return [u.id for u in users if wants(u.notification_prefs, n.category)]


def create_notification(db: Session, *, title: str, message: str, category: str = "announcement", priority: str = "Normal",
                        target_type: str = "all", target_id: int | None = None) -> dict:
    n = Notification(title=title, message=message, category=category, priority=priority, target_type=target_type, target_id=target_id)
    db.add(n)
    db.commit()
    ids = recipient_ids(db, n)
    pushed = 0
    try:  # a push failure must never undo or fail the in-app notification
        tokens = list(db.scalars(select(DeviceToken.token).where(DeviceToken.user_id.in_(ids))).all()) if ids else []
        pushed, dead = push.send(tokens, title, message, {"category": category, "notification_id": n.id})
        if dead:
            for t in db.scalars(select(DeviceToken).where(DeviceToken.token.in_(dead))).all():
                db.delete(t)
            db.commit()
    except Exception:
        log.exception("push failed")
    return {"id": n.id, "recipients": len(ids), "pushed": pushed}
