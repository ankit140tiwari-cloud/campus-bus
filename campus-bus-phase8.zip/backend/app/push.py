"""Firebase Cloud Messaging. Does nothing (and never raises) unless FIREBASE_CREDENTIALS points at a service-account file."""
import logging
import os

from . import config

log = logging.getLogger("push")
_app = None
_tried = False


def _init():
    global _app, _tried
    if _tried:
        return _app
    _tried = True
    path = config.FIREBASE_CREDENTIALS
    if not path or not os.path.exists(path):
        log.info("Push notifications disabled (FIREBASE_CREDENTIALS not set).")
        return None
    try:
        import firebase_admin
        from firebase_admin import credentials
        _app = firebase_admin.initialize_app(credentials.Certificate(path))
    except Exception:
        log.exception("Could not start Firebase; push disabled.")
    return _app


def send(tokens: list[str], title: str, body: str, data: dict | None = None) -> tuple[int, list[str]]:
    """Returns (delivered count, tokens Firebase says are dead). Data-only messages: the service worker shows them."""
    if not tokens or _init() is None:
        return 0, []
    from firebase_admin import messaging
    payload = {"title": title, "body": body, **{k: str(v) for k, v in (data or {}).items()}}
    sent, dead = 0, []
    for i in range(0, len(tokens), 500):
        chunk = tokens[i:i + 500]
        resp = messaging.send_each_for_multicast(messaging.MulticastMessage(tokens=chunk, data=payload))
        sent += resp.success_count
        for tok, r in zip(chunk, resp.responses):
            if not r.success and isinstance(r.exception, (messaging.UnregisteredError, messaging.SenderIdMismatchError)):
                dead.append(tok)
    return sent, dead
