from datetime import time

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import RouteStop


def hhmm(t: time | None) -> str:
    return t.strftime("%H:%M") if t else ""


def get_or_404(db: Session, model, obj_id: int, label: str):
    obj = db.get(model, obj_id)
    if obj is None:
        raise HTTPException(404, f"{label} not found.")
    return obj


def renumber_route(db: Session, route_id: int) -> None:
    links = db.scalars(select(RouteStop).where(RouteStop.route_id == route_id).order_by(RouteStop.stop_order, RouteStop.id)).all()
    for i, link in enumerate(links, 1):
        link.stop_order = i
