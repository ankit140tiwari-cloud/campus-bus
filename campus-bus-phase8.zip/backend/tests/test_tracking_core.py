"""Run with:  cd backend && python -m pytest   (or just: python tests/test_tracking_core.py)"""
import os
import sys
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from app.tracking_core import BusState, apply_location, current_delay, haversine_m, snapshot  # noqa: E402

STOPS = [{"name": "A", "lat": 23.2296, "lng": 77.4393, "minutes": 7 * 60 + 15},
         {"name": "B", "lat": 23.2332, "lng": 77.4344, "minutes": 7 * 60 + 25},
         {"name": "C", "lat": 23.2599, "lng": 77.4126, "minutes": 7 * 60 + 50}]
NOW = datetime.now(timezone.utc)


def bus() -> BusState:
    return BusState(1, "BUS-12", 1, "R", 1, [dict(s) for s in STOPS])


def test_reaching_a_stop_sets_current_and_next():
    s = bus(); apply_location(s, 23.2296, 77.4393, NOW, 7 * 60 + 16)
    sn = snapshot(s, NOW, 7 * 60 + 16)
    assert (sn["current_stop"], sn["next_stop"], sn["status"]) == ("A", "B", "On Time")
    assert sn["etas"]["B"] == 10 and "A" not in sn["etas"]  # 1 minute of delay is carried into the ETA


def test_late_arrival_is_delayed_and_carries_into_eta():
    s = bus(); apply_location(s, 23.2296, 77.4393, NOW, 7 * 60 + 27)
    sn = snapshot(s, NOW, 7 * 60 + 27)
    assert sn["status"] == "Delayed" and sn["delay_min"] == 12 and sn["etas"]["B"] == 10


def test_delay_is_fixed_while_travelling_then_grows_when_next_stop_overdue():
    s = bus(); apply_location(s, 23.2296, 77.4393, NOW, 7 * 60 + 27)
    assert current_delay(s, 7 * 60 + 30) == 12
    assert current_delay(s, 7 * 60 + 45) == 20


def test_stale_or_no_fix_is_offline():
    s = bus(); assert snapshot(s, NOW, 7 * 60)["status"] == "Offline"
    apply_location(s, 23.2296, 77.4393, NOW - timedelta(seconds=300), 7 * 60 + 16)
    assert snapshot(s, NOW, 7 * 60 + 16)["status"] == "Offline"


def test_skipped_stop_jumps_forward_and_never_goes_back():
    s = bus(); apply_location(s, 23.2599, 77.4126, NOW, 7 * 60 + 50)
    assert snapshot(s, NOW, 7 * 60 + 50)["current_stop"] == "C"
    apply_location(s, 23.2296, 77.4393, NOW, 7 * 60 + 51)
    assert s.visited_idx == 2


def test_early_bus_has_zero_delay_and_haversine_is_sane():
    s = bus(); apply_location(s, 23.2296, 77.4393, NOW, 7 * 60 + 5)
    assert snapshot(s, NOW, 7 * 60 + 5)["delay_min"] == 0
    assert 990 < haversine_m(23.0, 77.0, 23.009, 77.0) < 1010


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn(); print("PASS", name)
