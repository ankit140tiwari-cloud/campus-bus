import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from app.notify_core import disabled_categories, wants  # noqa: E402


def test_defaults_deliver_everything():
    assert all(wants(None, c) for c in ("departed", "delayed", "arriving", "route", "schedule", "emergency", "announcement", "complaint"))


def test_preferences_switch_off_their_categories_only():
    prefs = {"delayed": False, "changes": False}
    assert not wants(prefs, "delayed") and not wants(prefs, "route") and not wants(prefs, "schedule")
    assert wants(prefs, "departed") and wants(prefs, "arriving")


def test_emergencies_announcements_and_complaint_updates_cannot_be_switched_off():
    prefs = {"emergency": False, "delayed": False, "departed": False}
    assert wants(prefs, "emergency") and wants(prefs, "announcement") and wants(prefs, "complaint")


def test_disabled_categories_matches_wants():
    assert sorted(disabled_categories({"delayed": False, "changes": False})) == ["delayed", "route", "schedule"]


if __name__ == "__main__":
    for n, f in list(globals().items()):
        if n.startswith("test_"):
            f(); print("PASS", n)
